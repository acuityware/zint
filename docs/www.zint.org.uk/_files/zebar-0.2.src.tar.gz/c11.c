/*  Zebar - A barcode generating program using SDL
    Copyright (C) 2006 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <stdio.h>

int code_11_draw(char source, char dest[], int *j)
{ /* Table of Code 11 glyphs */
	int weight;

	switch(source)
	{
		case '0': 
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			weight = 0;
			break;
		case '1': 
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			weight = 1;
			break;
		case '2': 
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			weight = 2;
			break;
		case '3': 
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			weight = 3;
			break;
		case '4': 
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			weight = 4;
			break;
		case '5': 
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			weight = 5;
			break;
		case '6': 
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			weight = 6;
			break;
		case '7': 
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			weight = 7;
			break;
		case '8': 
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			weight = 8;
			break;
		case '9': 
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			weight = 9;
			break;
		case '-': 
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			weight = 10;
			break;
	}

	return weight;
}

void code_11(char source[], char dest[])
{ /* Non interlaced Code 2 of 5 */

	int i, j, c_digit, c_weight, c_count, k_digit, k_weight, k_count;
	int weight[1000];

	j = 0;
	c_weight = 1;
	c_count = 0;
	k_weight = 1;
	k_count = 0;

	/* start character */
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '2'; j++;
	dest[j] = '2'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;

	/* Draw main body of barcode */
	for(i = 0; i < strlen(source); i++)
	{
		weight[i] = code_11_draw(source[i], dest, &j);
	}

	/* Calculate C checksum */
	for(i = (strlen(source) - 1); i >= 0; i--)
	{
		c_count += (c_weight * weight[i]);
		c_weight++;

		if(c_weight > 10)
		{
			c_weight = 1;
		}
	}
	c_digit = c_count%11;

	/* Draw C checksum */
	switch(c_digit)
	{
		case 0:
			weight[strlen(source)] = code_11_draw('0', dest, &j);
			break;
		case 1:
			weight[strlen(source)] = code_11_draw('1', dest, &j);
			break;
		case 2:
			weight[strlen(source)] = code_11_draw('2', dest, &j);
			break;
		case 3:
			weight[strlen(source)] = code_11_draw('3', dest, &j);
			break;
		case 4:
			weight[strlen(source)] = code_11_draw('4', dest, &j);
			break;
		case 5:
			weight[strlen(source)] = code_11_draw('5', dest, &j);
			break;
		case 6:
			weight[strlen(source)] = code_11_draw('6', dest, &j);
			break;
		case 7:
			weight[strlen(source)] = code_11_draw('7', dest, &j);
			break;
		case 8:
			weight[strlen(source)] = code_11_draw('8', dest, &j);
			break;
		case 9:
			weight[strlen(source)] = code_11_draw('9', dest, &j);
			break;
		case 10:
			weight[strlen(source)] = code_11_draw('-', dest, &j);
			break;
	}

	/* Calculate K checksum */
	for(i = strlen(source); i >= 0; i--)
	{
		k_count += (k_weight * weight[i]);
		k_weight++;

		if(k_weight > 9)
		{
			k_weight = 1;
		}
	}
	k_digit = k_count%11;

	/* Draw K checksum */
	switch(k_digit)
	{
		case 0:
			weight[strlen(source)] = code_11_draw('0', dest, &j);
			break;
		case 1:
			weight[strlen(source)] = code_11_draw('1', dest, &j);
			break;
		case 2:
			weight[strlen(source)] = code_11_draw('2', dest, &j);
			break;
		case 3:
			weight[strlen(source)] = code_11_draw('3', dest, &j);
			break;
		case 4:
			weight[strlen(source)] = code_11_draw('4', dest, &j);
			break;
		case 5:
			weight[strlen(source)] = code_11_draw('5', dest, &j);
			break;
		case 6:
			weight[strlen(source)] = code_11_draw('6', dest, &j);
			break;
		case 7:
			weight[strlen(source)] = code_11_draw('7', dest, &j);
			break;
		case 8:
			weight[strlen(source)] = code_11_draw('8', dest, &j);
			break;
		case 9:
			weight[strlen(source)] = code_11_draw('9', dest, &j);
			break;
		case 10:
			weight[strlen(source)] = code_11_draw('-', dest, &j);
			break;
	}

	/* Stop character */
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '2'; j++;
	dest[j] = '2'; j++;
	dest[j] = '1'; j++;

	dest[j] = '\0';
}
