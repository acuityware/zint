/*  Zebar - A barcode generating program using SDL
    Copyright (C) 2006 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <stdio.h>

void c128_draw(int glyph, char dest[], int *j)
{
	switch(glyph)

	{
		case 0: /* SPACE SPACE 00 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 1: /* ! ! 01 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 2: /* " " 02 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 3: /* # # 03 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 4: /* $ $ 04 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 5: /* % % 05 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 6: /* & & 06 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 7: /* ' ' 07 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 8: /* ( ( 08 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 9: /* ) ) 09 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 10: /* * * 10 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 11: /* + + 11 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 12: /* , , 12 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 13: /* - - 13 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 14: /* . . 14 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 15: /* / / 15 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 16: /* 0 0 16 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 17: /* 1 1 17 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 18: /* 2 2 18 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 19: /* 3 3 19 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 20: /* 4 4 20 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 21: /* 5 5 21 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 22: /* 6 6 22 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 23: /* 7 7 23 */
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 24: /* 8 8 24 */
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 25: /* 9 9 25 */
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 26: /* : : 26 */
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 27: /* ; ; 27 */
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 28: /* < < 28 */
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 29: /* = = 29 */
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 30: /* > > 30 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 31: /* ? ? 31 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 32: /* @ @ 32 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 33: /* A A 33 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 34: /* B B 34 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 35: /* C C 35 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 36: /* D D 36 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 37: /* E E 37 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 38: /* F F 38 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 39: /* G G 39 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 40: /* H H 40 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 41: /* I I 41 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 42: /* J J 42 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 43: /* K K 43 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 44: /* L L 44 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 45: /* M M 45 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 46: /* N N 46 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 47: /* O O 47 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 48: /* P P 48 */
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 49: /* Q Q 49 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 50: /* R R 50 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 51: /* S S 51 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 52: /* T T 52 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 53: /* U U 53 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 54: /* V V 54 */
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 55: /* W W 55 */
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 56: /* X X 56 */
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 57: /* Y Y 57 */
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 58: /* Z Z 58 */
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 59: /* [ [ 59 */
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 60: /* \ \ 60 */
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 61: /* ] ] 61 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 62: /* ^ ^ 62 */
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 63: /* _ _ 63 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			break;
		case 64: /* NUL ` 64 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 65: /* SOH a 65 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			break;
		case 66: /* STX b 66 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 67: /* ETX c 67 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 68: /* EOT d 68 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 69: /* ENQ e 69 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			break;
		case 70: /* ACK f 70 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 71: /* BEL g 71 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			break;
		case 72: /* BS h 72 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 73: /* HT i 73 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 74: /* LF j 74 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 75: /* VT k 75 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 76: /* FF l 76 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			break;
		case 77: /* CR m 77 */
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 78: /* SO n 78 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 79: /* SI o 79 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 80: /* DLE p 80 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 81: /* DC1 q 81 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 82: /* DC2 r 82 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 83: /* DC3 s 83 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 84: /* DC4 t 84 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 85: /* NAK u 85 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 86: /* SYN v 86 */
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 87: /* ETB w 87 */
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 88: /* CAN x 88 */
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 89: /* EM y 89 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 90: /* SUB z 90 */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 91: /* ESC { 91 */
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 92: /* FS | 92 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 93: /* GS } 93 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 94: /* RS ~ 94 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 95: /* US DEL 95 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 96: /* FNC_3 FNC_3 96 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 97: /* FNC_2 FNC_2 97 */
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			break;
		case 98: /* SHIFT SHIFT 98 */
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 99: /* CODE_C CODE_C 99 */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 100: /* CODE_B FNC_4 CODE_B */
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 101: /* FNC_4 CODE_A CODE_A */
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 102: /* FNC_1 */
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			break;
		case 103: /* Start A */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 104: /* Start B */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			break;
		case 105: /* Start C */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
		case 106: /* Stop */
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			break;
	}
}

void c128_set_a(char source, char dest[], int *j, int values[], int *bar_chars)
{ /* Translate Code 128 Set A characters into barcodes */
  /* This set handles all control characters NULL to US */

	switch (source)
	{
		/* case 0: c128_draw(64, dest, j);
			values[(*bar_chars)] = 64;
			(*bar_chars)++;
			break; */
		case 1: c128_draw(65, dest, j);
			values[(*bar_chars)] = 65;
			(*bar_chars)++;
			break;
		case 2: c128_draw(66, dest, j);
			values[(*bar_chars)] = 66;
			(*bar_chars)++;
			break;
		case 3: c128_draw(67, dest, j);
			values[(*bar_chars)] = 67;
			(*bar_chars)++;
			break;
		case 4: c128_draw(68, dest, j);
			values[(*bar_chars)] = 68;
			(*bar_chars)++;
			break;
		case 5: c128_draw(69, dest, j);
			values[(*bar_chars)] = 69;
			(*bar_chars)++;
			break;
		case 6: c128_draw(70, dest, j);
			values[(*bar_chars)] = 70;
			(*bar_chars)++;
			break;
		case 7: c128_draw(71, dest, j);
			values[(*bar_chars)] = 71;
			(*bar_chars)++;
			break;
		case 8: c128_draw(72, dest, j);
			values[(*bar_chars)] = 72;
			(*bar_chars)++;
			break;
		case 9: c128_draw(73, dest, j);
			values[(*bar_chars)] = 73;
			(*bar_chars)++;
			break;
		case 10: c128_draw(74, dest, j);
			values[(*bar_chars)] = 74;
			(*bar_chars)++;
			break;
		case 11: c128_draw(75, dest, j);
			values[(*bar_chars)] = 75;
			(*bar_chars)++;
			break;
		case 12: c128_draw(76, dest, j);
			values[(*bar_chars)] = 76;
			(*bar_chars)++;
			break;
		case 13: c128_draw(77, dest, j);
			values[(*bar_chars)] = 77;
			(*bar_chars)++;
			break;
		case 14: c128_draw(78, dest, j);
			values[(*bar_chars)] = 78;
			(*bar_chars)++;
			break;
		case 15: c128_draw(79, dest, j);
			values[(*bar_chars)] = 79;
			(*bar_chars)++;
			break;
		case 16: c128_draw(80, dest, j);
			values[(*bar_chars)] = 80;
			(*bar_chars)++;
			break;
		case 17: c128_draw(81, dest, j);
			values[(*bar_chars)] = 81;
			(*bar_chars)++;
			break;
		case 18: c128_draw(82, dest, j);
			values[(*bar_chars)] = 82;
			(*bar_chars)++;
			break;
		case 19: c128_draw(83, dest, j);
			values[(*bar_chars)] = 83;
			(*bar_chars)++;
			break;
		case 20: c128_draw(84, dest, j);
			values[(*bar_chars)] = 84;
			(*bar_chars)++;
			break;
		case 21: c128_draw(85, dest, j);
			values[(*bar_chars)] = 85;
			(*bar_chars)++;
			break;
		case 22: c128_draw(86, dest, j);
			values[(*bar_chars)] = 86;
			(*bar_chars)++;
			break;
		case 23: c128_draw(87, dest, j);
			values[(*bar_chars)] = 87;
			(*bar_chars)++;
			break;
		case 24: c128_draw(88, dest, j);
			values[(*bar_chars)] = 88;
			(*bar_chars)++;
			break;
		case 25: c128_draw(89, dest, j);
			values[(*bar_chars)] = 89;
			(*bar_chars)++;
			break;
		case 26: c128_draw(90, dest, j);
			values[(*bar_chars)] = 90;
			(*bar_chars)++;
			break;
		case 27: c128_draw(91, dest, j);
			values[(*bar_chars)] = 91;
			(*bar_chars)++;
			break;
		case 28: c128_draw(92, dest, j);
			values[(*bar_chars)] = 92;
			(*bar_chars)++;
			break;
		case 29: c128_draw(93, dest, j);
			values[(*bar_chars)] = 93;
			(*bar_chars)++;
			break;
		case 30: c128_draw(94, dest, j);
			values[(*bar_chars)] = 94;
			(*bar_chars)++;
			break;
		case 31: c128_draw(95, dest, j);
			values[(*bar_chars)] = 95;
			(*bar_chars)++;
			break;
	}
}

void c128_set_b(char source, char dest[], int *j, int values[], int *bar_chars)
{ /* Translate Code 128 Set B characters into barcodes */
  /* This set handles all characters which are not part of long numbers and not control characters */

	switch(source)
	{
		case ' ': c128_draw(0, dest, j);
			values[(*bar_chars)] = 0;
			(*bar_chars)++;
			break;
		case '!': c128_draw(1, dest, j);
			values[(*bar_chars)] = 1;
			(*bar_chars)++;
			break;
		case '"': c128_draw(2, dest, j);
			values[(*bar_chars)] = 2;
			(*bar_chars)++;
			break;
		case '#': c128_draw(3, dest, j);
			values[(*bar_chars)] = 3;
			(*bar_chars)++;
			break;
		case '$': c128_draw(4, dest, j);
			values[(*bar_chars)] = 4;
			(*bar_chars)++;
			break;
		case '%': c128_draw(5, dest, j);
			values[(*bar_chars)] = 5;
			(*bar_chars)++;
			break;
		case '&': c128_draw(6, dest, j);
			values[(*bar_chars)] = 6;
			(*bar_chars)++;
			break;
		case '\'': c128_draw(7, dest, j);
			values[(*bar_chars)] = 7;
			(*bar_chars)++;
			break;
		case '(': c128_draw(8, dest, j);
			values[(*bar_chars)] = 8;
			(*bar_chars)++;
			break;
		case ')': c128_draw(9, dest, j);
			values[(*bar_chars)] = 9;
			(*bar_chars)++;
			break;
		case '*': c128_draw(10, dest, j);
			values[(*bar_chars)] = 10;
			(*bar_chars)++;
			break;
		case '+': c128_draw(11, dest, j);
			values[(*bar_chars)] = 11;
			(*bar_chars)++;
			break;
		case ',': c128_draw(12, dest, j);
			values[(*bar_chars)] = 12;
			(*bar_chars)++;
			break;
		case '-': c128_draw(13, dest, j);
			values[(*bar_chars)] = 13;
			(*bar_chars)++;
			break;
		case '.': c128_draw(14, dest, j);
			values[(*bar_chars)] = 14;
			(*bar_chars)++;
			break;
		case '/': c128_draw(15, dest, j);
			values[(*bar_chars)] = 15;
			(*bar_chars)++;
			break;
		case '0': c128_draw(16, dest, j);
			values[(*bar_chars)] = 16;
			(*bar_chars)++;
			break;
		case '1': c128_draw(17, dest, j);
			values[(*bar_chars)] = 17;
			(*bar_chars)++;
			break;
		case '2': c128_draw(18, dest, j);
			values[(*bar_chars)] = 18;
			(*bar_chars)++;
			break;
		case '3': c128_draw(19, dest, j);
			values[(*bar_chars)] = 19;
			(*bar_chars)++;
			break;
		case '4': c128_draw(20, dest, j);
			values[(*bar_chars)] = 20;
			(*bar_chars)++;
			break;
		case '5': c128_draw(21, dest, j);
			values[(*bar_chars)] = 21;
			(*bar_chars)++;
			break;
		case '6': c128_draw(22, dest, j);
			values[(*bar_chars)] = 22;
			(*bar_chars)++;
			break;
		case '7': c128_draw(23, dest, j);
			values[(*bar_chars)] = 23;
			(*bar_chars)++;
			break;
		case '8': c128_draw(24, dest, j);
			values[(*bar_chars)] = 24;
			(*bar_chars)++;
			break;
		case '9': c128_draw(25, dest, j);
			values[(*bar_chars)] = 25;
			(*bar_chars)++;
			break;
		case ':': c128_draw(26, dest, j);
			values[(*bar_chars)] = 26;
			(*bar_chars)++;
			break;
		case ';': c128_draw(27, dest, j);
			values[(*bar_chars)] = 27;
			(*bar_chars)++;
			break;
		case '<': c128_draw(28, dest, j);
			values[(*bar_chars)] = 28;
			(*bar_chars)++;
			break;
		case '=': c128_draw(29, dest, j);
			values[(*bar_chars)] = 29;
			(*bar_chars)++;
			break;
		case '>': c128_draw(30, dest, j);
			values[(*bar_chars)] = 30;
			(*bar_chars)++;
			break;
		case '?': c128_draw(31, dest, j);
			values[(*bar_chars)] = 31;
			(*bar_chars)++;
			break;
		case '@': c128_draw(32, dest, j);
			values[(*bar_chars)] = 32;
			(*bar_chars)++;
			break;
		case 'A': c128_draw(33, dest, j);
			values[(*bar_chars)] = 33;
			(*bar_chars)++;
			break;
		case 'B': c128_draw(34, dest, j);
			values[(*bar_chars)] = 34;
			(*bar_chars)++;
			break;
		case 'C': c128_draw(35, dest, j);
			values[(*bar_chars)] = 35;
			(*bar_chars)++;
			break;
		case 'D': c128_draw(36, dest, j);
			values[(*bar_chars)] = 36;
			(*bar_chars)++;
			break;
		case 'E': c128_draw(37, dest, j);
			values[(*bar_chars)] = 37;
			(*bar_chars)++;
			break;
		case 'F': c128_draw(38, dest, j);
			values[(*bar_chars)] = 38;
			(*bar_chars)++;
			break;
		case 'G': c128_draw(39, dest, j);
			values[(*bar_chars)] = 39;
			(*bar_chars)++;
			break;
		case 'H': c128_draw(40, dest, j);
			values[(*bar_chars)] = 40;
			(*bar_chars)++;
			break;
		case 'I': c128_draw(41, dest, j);
			values[(*bar_chars)] = 41;
			(*bar_chars)++;
			break;
		case 'J': c128_draw(42, dest, j);
			values[(*bar_chars)] = 42;
			(*bar_chars)++;
			break;
		case 'K': c128_draw(43, dest, j);
			values[(*bar_chars)] = 43;
			(*bar_chars)++;
			break;
		case 'L': c128_draw(44, dest, j);
			values[(*bar_chars)] = 44;
			(*bar_chars)++;
			break;
		case 'M': c128_draw(45, dest, j);
			values[(*bar_chars)] = 45;
			(*bar_chars)++;
			break;
		case 'N': c128_draw(46, dest, j);
			values[(*bar_chars)] = 46;
			(*bar_chars)++;
			break;
		case 'O': c128_draw(47, dest, j);
			values[(*bar_chars)] = 47;
			(*bar_chars)++;
			break;
		case 'P': c128_draw(48, dest, j);
			values[(*bar_chars)] = 48;
			(*bar_chars)++;
			break;
		case 'Q': c128_draw(49, dest, j);
			values[(*bar_chars)] = 49;
			(*bar_chars)++;
			break;
		case 'R': c128_draw(50, dest, j);
			values[(*bar_chars)] = 50;
			(*bar_chars)++;
			break;
		case 'S': c128_draw(51, dest, j);
			values[(*bar_chars)] = 51;
			(*bar_chars)++;
			break;
		case 'T': c128_draw(52, dest, j);
			values[(*bar_chars)] = 52;
			(*bar_chars)++;
			break;
		case 'U': c128_draw(53, dest, j);
			values[(*bar_chars)] = 53;
			(*bar_chars)++;
			break;
		case 'V': c128_draw(54, dest, j);
			values[(*bar_chars)] = 54;
			(*bar_chars)++;
			break;
		case 'W': c128_draw(55, dest, j);
			values[(*bar_chars)] = 55;
			(*bar_chars)++;
			break;
		case 'X': c128_draw(56, dest, j);
			values[(*bar_chars)] = 16;
			(*bar_chars)++;
			break;
		case 'Y': c128_draw(17, dest, j);
			values[(*bar_chars)] = 57;
			(*bar_chars)++;
			break;
		case 'Z': c128_draw(58, dest, j);
			values[(*bar_chars)] = 58;
			(*bar_chars)++;
			break;
		case '[': c128_draw(59, dest, j);
			values[(*bar_chars)] = 59;
			(*bar_chars)++;
			break;
		case '\\': c128_draw(60, dest, j);
			values[(*bar_chars)] = 60;
			(*bar_chars)++;
			break;
		case ']': c128_draw(61, dest, j);
			values[(*bar_chars)] = 61;
			(*bar_chars)++;
			break;
		case '^': c128_draw(62, dest, j);
			values[(*bar_chars)] = 62;
			(*bar_chars)++;
			break;
		case '_': c128_draw(63, dest, j);
			values[(*bar_chars)] = 63;
			(*bar_chars)++;
			break;
		case '`': c128_draw(64, dest, j);
			values[(*bar_chars)] = 64;
			(*bar_chars)++;
			break;
		case 'a': c128_draw(65, dest, j);
			values[(*bar_chars)] = 65;
			(*bar_chars)++;
			break;
		case 'b': c128_draw(66, dest, j);
			values[(*bar_chars)] = 66;
			(*bar_chars)++;
			break;
		case 'c': c128_draw(67, dest, j);
			values[(*bar_chars)] = 67;
			(*bar_chars)++;
			break;
		case 'd': c128_draw(68, dest, j);
			values[(*bar_chars)] = 68;
			(*bar_chars)++;
			break;
		case 'e': c128_draw(69, dest, j);
			values[(*bar_chars)] = 69;
			(*bar_chars)++;
			break;
		case 'f': c128_draw(70, dest, j);
			values[(*bar_chars)] = 70;
			(*bar_chars)++;
			break;
		case 'g': c128_draw(71, dest, j);
			values[(*bar_chars)] = 71;
			(*bar_chars)++;
			break;
		case 'h': c128_draw(72, dest, j);
			values[(*bar_chars)] = 72;
			(*bar_chars)++;
			break;
		case 'i': c128_draw(73, dest, j);
			values[(*bar_chars)] = 73;
			(*bar_chars)++;
			break;
		case 'j': c128_draw(74, dest, j);
			values[(*bar_chars)] = 74;
			(*bar_chars)++;
			break;
		case 'k': c128_draw(75, dest, j);
			values[(*bar_chars)] = 75;
			(*bar_chars)++;
			break;
		case 'l': c128_draw(76, dest, j);
			values[(*bar_chars)] = 76;
			(*bar_chars)++;
			break;
		case 'm': c128_draw(77, dest, j);
			values[(*bar_chars)] = 77;
			(*bar_chars)++;
			break;
		case 'n': c128_draw(78, dest, j);
			values[(*bar_chars)] = 78;
			(*bar_chars)++;
			break;
		case 'o': c128_draw(79, dest, j);
			values[(*bar_chars)] = 79;
			(*bar_chars)++;
			break;
		case 'p': c128_draw(80, dest, j);
			values[(*bar_chars)] = 80;
			(*bar_chars)++;
			break;
		case 'q': c128_draw(81, dest, j);
			values[(*bar_chars)] = 81;
			(*bar_chars)++;
			break;
		case 'r': c128_draw(82, dest, j);
			values[(*bar_chars)] = 82;
			(*bar_chars)++;
			break;
		case 's': c128_draw(83, dest, j);
			values[(*bar_chars)] = 83;
			(*bar_chars)++;
			break;
		case 't': c128_draw(84, dest, j);
			values[(*bar_chars)] = 84;
			(*bar_chars)++;
			break;
		case 'u': c128_draw(85, dest, j);
			values[(*bar_chars)] = 85;
			(*bar_chars)++;
			break;
		case 'v': c128_draw(86, dest, j);
			values[(*bar_chars)] = 86;
			(*bar_chars)++;
			break;
		case 'w': c128_draw(87, dest, j);
			values[(*bar_chars)] = 87;
			(*bar_chars)++;
			break;
		case 'x': c128_draw(88, dest, j);
			values[(*bar_chars)] = 88;
			(*bar_chars)++;
			break;
		case 'y': c128_draw(89, dest, j);
			values[(*bar_chars)] = 89;
			(*bar_chars)++;
			break;
		case 'z': c128_draw(90, dest, j);
			values[(*bar_chars)] = 90;
			(*bar_chars)++;
			break;
		case '{': c128_draw(91, dest, j);
			values[(*bar_chars)] = 91;
			(*bar_chars)++;
			break;
		case '|': c128_draw(92, dest, j);
			values[(*bar_chars)] = 92;
			(*bar_chars)++;
			break;
		case '}': c128_draw(93, dest, j);
			values[(*bar_chars)] = 93;
			(*bar_chars)++;
			break;
		case '~': c128_draw(94, dest, j);
			values[(*bar_chars)] = 94;
			(*bar_chars)++;
			break;
		case 127: c128_draw(95, dest, j);
			values[(*bar_chars)] = 95;
			(*bar_chars)++;
			break;
	}
}

void c128_set_c(char source_a, char source_b, char dest[], int *j, int values[], int *bar_chars)
{ /* Translate Code 128 Set C characters into barcodes */
  /* This set handles long numbers in a compressed form */
	int weight;

	switch(source_a)
	{
		case '0': weight = 0; break;
		case '1': weight = 10; break;
		case '2': weight = 20; break;
		case '3': weight = 30; break;
		case '4': weight = 40; break;
		case '5': weight = 50; break;
		case '6': weight = 60; break;
		case '7': weight = 70; break;
		case '8': weight = 80; break;
		case '9': weight = 90; break;
	}

	switch(source_b)
	{
		case '0': break;
		case '1': weight += 1; break;
		case '2': weight += 2; break;
		case '3': weight += 3; break;
		case '4': weight += 4; break;
		case '5': weight += 5; break;
		case '6': weight += 6; break;
		case '7': weight += 7; break;
		case '8': weight += 8; break;
		case '9': weight += 9; break;
	}

	c128_draw(weight, dest, j);
	values[(*bar_chars)] = weight;
	(*bar_chars)++;
}

void c128(char source[], char dest[])
{ /* Handle Code 128 barcodes */
	int i, j, k, e_count, values[200], bar_characters, read, total_sum;
	char set[200];

	j = 0;
	e_count = 0;
	bar_characters = 0;

	/* First figure out what code sets to use - there are three: A, B, and C */
	for(i = 0; i < strlen(source); i++)
	{

	/* In the following I have made Zebar use code set B whenever there is a choice
	   between using A or B. Whilst this doesn't always ensure the shortest and neatest
	   barcode, I think that code A is likely to be needed so rarely that this shortcut
	   is justified: The vast majority of barcodes will only need to use sets B and C. */

		if(source[i] < 32) {
			/* Everthing from NULL to US must be code set A */
			set[i] = 'A';
			if((e_count % 2) == 1) {
				/* If there are an odd number of numbers (0-9), the last one
				   cannot be set C */
				set[i - 1] = 'A';
			}
			e_count = 0;
		}
		if((source[i] > 31) && (source[i] < 48)) {
			/* Everything from SPACE to / can be code set A or B  - Use B */
			set[i] = 'B';
			if((e_count % 2) == 1) {
				set[i - 1] = 'B';
			}
			e_count = 0;
		}
		if((source[i] > 47) && (source[i] < 58)) {
			/* Numbers from 0 to 9 can be code set A, B or C */
			e_count ++;
			if(e_count > 5) {
				/* If there are more than six of them they should be C */
				if(i != (strlen(source) - 1)) {
					for(k = 5; k > 0; k--) {
						set[i - k] = 'C';
					}
					set[i] = 'C';
				}
				else
				{
					/* Ah! But be careful if it's the last character */
					if((e_count % 2) == 1) {
						set[i] = 'B';
					}
					else
					{
						for(k = 5; k > 0; k--) {
							set[i - k] = 'C';
						}
						set[i] = 'C';
					}
				}
			}
			else
			{
				/* Otherwise they can be A or B  - Use B */
				set[i] = 'B';
			}
		}
		if(source[i] > 57) {
			/* Everything from : to _ can be code set A or B - Use B
			   Everything from ` to DELETE must be code set B */
			set[i] = 'B';
			if((e_count % 2) == 1) {
				set[i - 1] = 'B';
			}
			e_count = 0;
		}
	}
	set[i] = '\0';

	/* So now we know what start character to use */
	switch(set[0])
	{
		case 'A': /* Start A */
			c128_draw(103, dest, &j);
			values[0] = 103;
			break;
		case 'B': /* Start B */
			c128_draw(104, dest, &j);
			values[0] = 104;
			break;
		case 'C': /* Start C */
			c128_draw(105, dest, &j);
			values[0] = 105;
			break;
	}
	bar_characters++;

	/* Deal with the gritty middle of the barcode ! */
	read = 0;
	do {

		if((read != 0) && (set[read] != set[read - 1]))
		{
			switch(set[read])
			{
				case 'A': c128_draw(101, dest, &j);
					values[bar_characters] = 101;
					bar_characters++;
					break;
				case 'B': c128_draw(100, dest, &j);
					values[bar_characters] = 100;
					bar_characters++;
					break;
				case 'C': c128_draw(99, dest, &j);
					values[bar_characters] = 99;
					bar_characters++;
					break;
			}
		}

		switch(set[read])
		{
			case 'A': c128_set_a(source[read], dest, &j, values, &bar_characters);
				read++;
				break;
			case 'B': c128_set_b(source[read], dest, &j, values, &bar_characters);
				read++;
				break;
			case 'C': c128_set_c(source[read], source[read + 1], dest, &j, values, &bar_characters);
				read += 2;
				break;
		}
	} while (read < strlen(source));

	/* Calculate check digit */
	total_sum = 0;
	for(i = 0; i < bar_characters; i++)
	{
		if(i > 0)
		{
			values[i] *= i;
		}
		total_sum += values[i];
	}

	/* Draw check digit */
	c128_draw((total_sum%103), dest, &j);
	printf("Drawing Code 128 with check digit %d\n", total_sum%103);

	/* Stop character */
	c128_draw(106, dest, &j);
	dest[j] = '\0';
}
