/*  Zebar - A barcode generating program using SDL
    Copyright (C) 2006 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <stdio.h>

void c39(char source[], char dest[])
{ /* The Code 39 barcode system consisting of a simple substitution cipher */
	int i, j;

	j = 0;

	printf("zebar: Drawing Code 39 \"%s\"\n", source);

	/* Start character */
	dest[j] = '1'; j++;
	dest[j] = '2'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '2'; j++;
	dest[j] = '1'; j++;
	dest[j] = '2'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;

	for(i = 0; i <= strlen(source); i++)
	{

		switch(source[i])
		{
			case '1': 
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				break;
			case '2': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				break;
			case '3': 
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case '4': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				break;
			case '5': 
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case '6': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case '7': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				break;
			case '8': 
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case '9': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case '0': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case 'A': 
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				break;
			case 'B': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				break;
			case 'C': 
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case 'D': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				break;
			case 'E': 
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case 'F': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case 'G': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				break;
			case 'H': 
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case 'I': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case 'J': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case 'K': 
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				break;
			case 'L': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				break;
			case 'M': 
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case 'N': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				break;
			case 'O': 
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case 'P': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case 'Q': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				break;
			case 'R': 
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case 'S': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case 'T': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case 'U': 
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				break;
			case 'V': 
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				break;
			case 'W': 
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case 'X': 
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				break;
			case 'Y': 
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case 'Z': 
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case '-':  /* dash */
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				break;
			case '.':  /* full stop */
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case ' ':  /* space */
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case '$':  /* dollar */
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case '/':  /* slash */
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case '+':  /* plus */
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case '%':  /* percent */
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			}
		}


	/* Stop character */
	dest[j] = '1'; j++;
	dest[j] = '2'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '2'; j++;
	dest[j] = '1'; j++;
	dest[j] = '2'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '\0';
}

void ec39(char source[], char dest[])
{ /* An extension to the Code 39 system which supports extra characters including lower case */
	char buffer[200];
	int i, j;

	i = 0;
	j = 0;

	/* Creates a buffer string and places the ciphered 'extra' characters into it */

	while(j < strlen(source))
	{
		switch(source[j])
		{
			/* case '\0':  Null > %U */
			/* This is also the string terminator, so can't be implemented */
			/*	buffer[i] = '%';
				buffer[i + 1] = 'U';
				i += 2;
				break; */
			case 1: /* Start of Heading > $A */
				buffer[i] = '$';
				buffer[i + 1] = 'A';
				i += 2;
				break;
			case 2: /* Start of Text > $B */
				buffer[i] = '$';
				buffer[i + 1] = 'B';
				i += 2;
				break;
			case 3: /* End of Text > $C*/
				buffer[i] = '$';
				buffer[i + 1] = 'C';
				i += 2;
				break;
			case 4: /* End of Transmission > $D */
				buffer[i] = '$';
				buffer[i + 1] = 'D';
				i += 2;
				break;
			case 5: /* Enquiry > $E */
				buffer[i] = '$';
				buffer[i + 1] = 'E';
				i += 2;
				break;
			case 6: /* Acknowledge > $F */
				buffer[i] = '$';
				buffer[i + 1] = 'F';
				i += 2;
				break;
			case 7: /* Bell > $G */
				buffer[i] = '$';
				buffer[i + 1] = 'G';
				i += 2;
				break;
			case '\b': /* Backspace > $H */
				buffer[i] = '$';
				buffer[i + 1] = 'H';
				i += 2;
				break;
			case '\t': /* Horizontal Tab > $I */
				buffer[i] = '$';
				buffer[i + 1] = 'I';
				i += 2;
				break;
			case '\n': /* Line Feed > $J */
				buffer[i] = '$';
				buffer[i + 1] = 'J';
				i += 2;
				break;
			case '\v': /* Vertical Tab > $K */
				buffer[i] = '$';
				buffer[i + 1] = 'K';
				i += 2;
				break;
			case '\f': /* Form Feed > $L */
				buffer[i] = '$';
				buffer[i + 1] = 'L';
				i += 2;
				break;
			case '\r': /* Carriage Return > $M */
				buffer[i] = '$';
				buffer[i + 1] = 'M';
				i += 2;
				break;
			case 14: /* Shift Out > $N */
				buffer[i] = '$';
				buffer[i + 1] = 'N';
				i += 2;
				break;
			case 15: /* Shift In > $O */
				buffer[i] = '$';
				buffer[i + 1] = 'O';
				i += 2;
				break;
			case 16: /* Data Link Escape > $P */
				buffer[i] = '$';
				buffer[i + 1] = 'P';
				i += 2;
				break;
			case 17: /* Device Control 1 > $Q */
				buffer[i] = '$';
				buffer[i + 1] = 'Q';
				i += 2;
				break;
			case 18: /* Device Control 2 > $R */
				buffer[i] = '$';
				buffer[i + 1] = 'R';
				i += 2;
				break;
			case 19: /* Device Control 3 > $S */
				buffer[i] = '$';
				buffer[i + 1] = 'S';
				i += 2;
				break;
			case 20: /* Device Control 4 > $T */
				buffer[i] = '$';
				buffer[i + 1] = 'T';
				i += 2;
				break;
			case 21: /* Negative Acknowledge > $U */
				buffer[i] = '$';
				buffer[i + 1] = 'U';
				i += 2;
				break;
			case 22: /* Synchronous Idle > $V */
				buffer[i] = '$';
				buffer[i + 1] = 'V';
				i += 2;
				break;
			case 23: /* End of Transmission Block > $W */
				buffer[i] = '$';
				buffer[i + 1] = 'W';
				i += 2;
				break;
			case 24: /* Cancel > $X */
				buffer[i] = '$';
				buffer[i + 1] = 'X';
				i += 2;
				break;
			case 25: /* End of Medium > $Y */
				buffer[i] = '$';
				buffer[i + 1] = 'Y';
				i += 2;
				break;
			case 26: /* Substitute > $Z */
				buffer[i] = '$';
				buffer[i + 1] = 'Z';
				i += 2;
				break;
			case 27: /* Escape > %A */
				buffer[i] = '%';
				buffer[i + 1] = 'A';
				i += 2;
				break;
			case 28: /* File Separator > %B */
				buffer[i] = '%';
				buffer[i + 1] = 'B';
				i += 2;
				break;
			case 29: /* Group Separator > %C */
				buffer[i] = '%';
				buffer[i + 1] = 'C';
				i += 2;
				break;
			case 30: /* Record Separator > %D */
				buffer[i] = '%';
				buffer[i + 1] = 'D';
				i += 2;
				break;
			case 31: /* Unit Separator > %E */
				buffer[i] = '%';
				buffer[i + 1] = 'E';
				i += 2;
				break;
			case '!': /* exclamation > /A */
				buffer[i] = '/';
				buffer[i + 1] = 'A';
				i += 2;
				break;
			case '\"': /* double quote > /B */
				buffer[i] = '/';
				buffer[i + 1] = 'B';
				i += 2;
				break;
			case '#': /* hash > /C */
				buffer[i] = '/';
				buffer[i + 1] = 'C';
				i += 2;
				break;
			case '$': /* dollar > /D */
				buffer[i] = '/';
				buffer[i + 1] = 'D';
				i += 2;
				break;
			case '%': /* percent > /E */
				buffer[i] = '/';
				buffer[i + 1] = 'E';
				i += 2;
				break;
			case '&': /* ampusand > /F */
				buffer[i] = '/';
				buffer[i + 1] = 'F';
				i += 2;
				break;
			case '\'': /* single quote > /G */
				buffer[i] = '/';
				buffer[i + 1] = 'G';
				i += 2;
				break;
			case '(': /* open bracket > /H */
				buffer[i] = '/';
				buffer[i + 1] = 'H';
				i += 2;
				break;
			case ')': /* close bracket > /I */
				buffer[i] = '/';
				buffer[i + 1] = 'I';
				i += 2;
				break;
			case '*': /* asterisk > /J */
				buffer[i] = '/';
				buffer[i + 1] = 'J';
				i += 2;
				break;
			case '+': /* plus > /K */
				buffer[i] = '/';
				buffer[i + 1] = 'K';
				i += 2;
				break;
			case ',': /* comma > /L */
				buffer[i] = '/';
				buffer[i + 1] = 'L';
				i += 2;
				break;
			case '/': /* forward slash > /O */
				buffer[i] = '/';
				buffer[i + 1] = 'O';
				i += 2;
				break;
			case ':': /* colon > /Z */
				buffer[i] = '/';
				buffer[i + 1] = 'Z';
				i += 2;
				break;
			case ';': /* semi-colon > %F */
				buffer[i] = '%';
				buffer[i + 1] = 'F';
				i += 2;
				break;
			case '<': /* less than > %G */
				buffer[i] = '%';
				buffer[i + 1] = 'G';
				i += 2;
				break;
			case '=': /* equals > %H */
				buffer[i] = '%';
				buffer[i + 1] = 'H';
				i += 2;
				break;
			case '>': /* greater than > %I */
				buffer[i] = '%';
				buffer[i + 1] = 'I';
				i += 2;
				break;
			case '?': /* question mark > %J */
				buffer[i] = '%';
				buffer[i + 1] = 'J';
				i += 2;
				break;
			case '@': /* at > %V */
				buffer[i] = '%';
				buffer[i + 1] = 'V';
				i += 2;
				break;
			case '[': /* open square bracket > %K */
				buffer[i] = '%';
				buffer[i + 1] = 'K';
				i += 2;
				break;
			case '\\': /* backslash > %L */
				buffer[i] = '%';
				buffer[i + 1] = 'L';
				i += 2;
				break;
			case ']': /* close square bracket > %M */
				buffer[i] = '%';
				buffer[i + 1] = 'M';
				i += 2;
				break;
			case '^': /* caret > %N */
				buffer[i] = '%';
				buffer[i + 1] = 'N';
				i += 2;
				break;
			case '_': /* underscore > %O */
				buffer[i] = '%';
				buffer[i + 1] = 'O';
				i += 2;
				break;
			case '`': /* acute accent > %W */
				buffer[i] = '%';
				buffer[i + 1] = 'W';
				i += 2;
				break;
			case 'a': /* lower A > +A */
				buffer[i] = '+';
				buffer[i + 1] = 'A';
				i += 2;
				break;
			case 'b': /* lower B > +B */
				buffer[i] = '+';
				buffer[i + 1] = 'B';
				i += 2;
				break;
			case 'c': /* lower C > +C */
				buffer[i] = '+';
				buffer[i + 1] = 'C';
				i += 2;
				break;
			case 'd': /* lower D > +D */
				buffer[i] = '+';
				buffer[i + 1] = 'D';
				i += 2;
				break;
			case 'e': /* lower E > +E */
				buffer[i] = '+';
				buffer[i + 1] = 'E';
				i += 2;
				break;
			case 'f': /* lower F > +F */
				buffer[i] = '+';
				buffer[i + 1] = 'F';
				i += 2;
				break;
			case 'g': /* lower G > +G */
				buffer[i] = '+';
				buffer[i + 1] = 'G';
				i += 2;
				break;
			case 'h': /* lower H > +H */
				buffer[i] = '+';
				buffer[i + 1] = 'H';
				i += 2;
				break;
			case 'i': /* lower I > +I */
				buffer[i] = '+';
				buffer[i + 1] = 'I';
				i += 2;
				break;
			case 'j': /* lower J > +J */
				buffer[i] = '+';
				buffer[i + 1] = 'J';
				i += 2;
				break;
			case 'k': /* lower K > +K */
				buffer[i] = '+';
				buffer[i + 1] = 'K';
				i += 2;
				break;
			case 'l': /* lower L > +L */
				buffer[i] = '+';
				buffer[i + 1] = 'L';
				i += 2;
				break;
			case 'm': /* lower M > +M */
				buffer[i] = '+';
				buffer[i + 1] = 'M';
				i += 2;
				break;
			case 'n': /* lower N > +N */
				buffer[i] = '+';
				buffer[i + 1] = 'N';
				i += 2;
				break;
			case 'o': /* lower O > +O */
				buffer[i] = '+';
				buffer[i + 1] = 'O';
				i += 2;
				break;
			case 'p': /* lower P > +P */
				buffer[i] = '+';
				buffer[i + 1] = 'P';
				i += 2;
				break;
			case 'q': /* lower Q > +Q */
				buffer[i] = '+';
				buffer[i + 1] = 'Q';
				i += 2;
				break;
			case 'r': /* lower R > +R */
				buffer[i] = '+';
				buffer[i + 1] = 'R';
				i += 2;
				break;
			case 's': /* lower S > +S */
				buffer[i] = '+';
				buffer[i + 1] = 'S';
				i += 2;
				break;
			case 't': /* lower T > +T */
				buffer[i] = '+';
				buffer[i + 1] = 'T';
				i += 2;
				break;
			case 'u': /* lower U > +U */
				buffer[i] = '+';
				buffer[i + 1] = 'U';
				i += 2;
				break;
			case 'v': /* lower V > +V */
				buffer[i] = '+';
				buffer[i + 1] = 'V';
				i += 2;
				break;
			case 'w': /* lower W > +W */
				buffer[i] = '+';
				buffer[i + 1] = 'W';
				i += 2;
				break;
			case 'x': /* lower X > +X */
				buffer[i] = '+';
				buffer[i + 1] = 'X';
				i += 2;
				break;
			case 'y': /* lower Y > +Y */
				buffer[i] = '+';
				buffer[i + 1] = 'Y';
				i += 2;
				break;
			case 'z': /* lower Z > +Z */
				buffer[i] = '+';
				buffer[i + 1] = 'Z';
				i += 2;
				break;
			case '{': /* open curly bracket > %P */
				buffer[i] = '%';
				buffer[i + 1] = 'P';
				i += 2;
				break;
			case '|': /* bar > %Q */
				buffer[i] = '%';
				buffer[i + 1] = 'Q';
				i += 2;
				break;
			case '}': /* close curly bracket > %R */
				buffer[i] = '%';
				buffer[i + 1] = 'R';
				i += 2;
				break;
			case '~': /* tilde > %S */
				buffer[i] = '%';
				buffer[i + 1] = 'S';
				i += 2;
				break;
			case 127: /* Delete > %T */
				buffer[i] = '%';
				buffer[i + 1] = 'T';
				i += 2;
				break;
			default: /* Anything else goes unaltered */
				buffer[i] = source[j];
				i++;
				break;
		}
		j++;
	}
	buffer[i] = '\0';

	/* Then sends the buffer to the C39 function */
	c39(source, dest);
}
