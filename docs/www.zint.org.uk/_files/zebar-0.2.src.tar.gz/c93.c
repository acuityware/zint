/*  Zebar - A barcode generating program using SDL
    Copyright (C) 2006 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <stdio.h>

void c93_char(char source, char dest[], int *j, int values[], int *bar_chars)
{ /* Translate characters into bar patterns */

	switch(source)
	{
		case '0':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			values[(*bar_chars)] = 0;
			(*bar_chars)++;
			break;
		case '1':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			values[(*bar_chars)] = 1;(*bar_chars)++;break;
		case '2':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			values[(*bar_chars)] = 2;(*bar_chars)++;break;
		case '3':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 3;(*bar_chars)++;break;
		case '4':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			values[(*bar_chars)] = 4;(*bar_chars)++;break;
		case '5':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			values[(*bar_chars)] = 5;(*bar_chars)++;break;
		case '6':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 6;(*bar_chars)++;break;
		case '7':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			values[(*bar_chars)] = 7;(*bar_chars)++;break;
		case '8':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 8;(*bar_chars)++;break;
		case '9':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '4'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 9;(*bar_chars)++;break;
		case 'A':
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			values[(*bar_chars)] = 10;(*bar_chars)++;break;
		case 'B':
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			values[(*bar_chars)] = 11;(*bar_chars)++;break;
		case 'C':
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 12;(*bar_chars)++;break;
		case 'D':
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			values[(*bar_chars)] = 13;(*bar_chars)++;break;
		case 'E':
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 14;(*bar_chars)++;break;
		case 'F':
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 15;(*bar_chars)++;break;
		case 'G':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			values[(*bar_chars)] = 16;(*bar_chars)++;break;
		case 'H':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			values[(*bar_chars)] = 17;(*bar_chars)++;break;
		case 'I':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 18;(*bar_chars)++;break;
		case 'J':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			values[(*bar_chars)] = 19;(*bar_chars)++;break;
		case 'K':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 20;(*bar_chars)++;break;
		case 'L':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			values[(*bar_chars)] = 21;(*bar_chars)++;break;
		case 'M':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			values[(*bar_chars)] = 22;(*bar_chars)++;break;
		case 'N':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 23;(*bar_chars)++;break;
		case 'O':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			values[(*bar_chars)] = 24;(*bar_chars)++;break;
		case 'P':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 25;(*bar_chars)++;break;
		case 'Q':
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			values[(*bar_chars)] = 26;(*bar_chars)++;break;
		case 'R':
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 27;(*bar_chars)++;break;
		case 'S':
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			values[(*bar_chars)] = 28;(*bar_chars)++;break;
		case 'T':
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 29;(*bar_chars)++;break;
		case 'U':
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 30;(*bar_chars)++;break;
		case 'V':
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 31;(*bar_chars)++;break;
		case 'W':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			values[(*bar_chars)] = 32;(*bar_chars)++;break;
		case 'X':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 33;(*bar_chars)++;break;
		case 'Y':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 34;(*bar_chars)++;break;
		case 'Z':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 35;(*bar_chars)++;break;
		case '-':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 36;(*bar_chars)++;break;
		case '.':
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			values[(*bar_chars)] = 37;(*bar_chars)++;break;
		case ' ':
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 38;(*bar_chars)++;break;
		case '$':
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 39;(*bar_chars)++;break;
		case '/':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 40;(*bar_chars)++;break;
		case '+':
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 41;(*bar_chars)++;break;
		case '%':
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 42;(*bar_chars)++;break;
	}
}

void c93_shift(int shift, char dest[], int *j, int *values, int *bar_chars)
{ /* Translate shift characters into bar patterns */
	switch(shift)
	{
		case 1:
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 43;(*bar_chars)++;break;
		case 2:
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 44;(*bar_chars)++;break;
		case 3:
			dest[(*j)] = '3'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 45;(*bar_chars)++;break;
		case 4:
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '2'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			dest[(*j)] = '1'; (*j)++;
			values[(*bar_chars)] = 46;(*bar_chars)++;break;
	}
}

void c93_check(int symbol, char dest[], int *j, int *values, int *bar_characters)
{
	switch(symbol)
	{
		case 0: c93_char('0', dest, j, values, bar_characters); printf("0"); break;
		case 1: c93_char('1', dest, j, values, bar_characters); printf("1"); break;
		case 2: c93_char('2', dest, j, values, bar_characters); printf("2"); break;
		case 3: c93_char('3', dest, j, values, bar_characters); printf("3"); break;
		case 4: c93_char('4', dest, j, values, bar_characters); printf("4"); break;
		case 5: c93_char('5', dest, j, values, bar_characters); printf("5"); break;
		case 6: c93_char('6', dest, j, values, bar_characters); printf("6"); break;
		case 7: c93_char('7', dest, j, values, bar_characters); printf("7"); break;
		case 8: c93_char('8', dest, j, values, bar_characters); printf("8"); break;
		case 9: c93_char('9', dest, j, values, bar_characters); printf("9"); break;
		case 10: c93_char('A', dest, j, values, bar_characters); printf("A"); break;
		case 11: c93_char('B', dest, j, values, bar_characters); printf("B"); break;
		case 12: c93_char('C', dest, j, values, bar_characters); printf("C"); break;
		case 13: c93_char('D', dest, j, values, bar_characters); printf("D"); break;
		case 14: c93_char('E', dest, j, values, bar_characters); printf("E"); break;
		case 15: c93_char('F', dest, j, values, bar_characters); printf("F"); break;
		case 16: c93_char('G', dest, j, values, bar_characters); printf("G"); break;
		case 17: c93_char('H', dest, j, values, bar_characters); printf("H"); break;
		case 18: c93_char('I', dest, j, values, bar_characters); printf("I"); break;
		case 19: c93_char('J', dest, j, values, bar_characters); printf("J"); break;
		case 20: c93_char('K', dest, j, values, bar_characters); printf("K"); break;
		case 21: c93_char('L', dest, j, values, bar_characters); printf("L"); break;
		case 22: c93_char('M', dest, j, values, bar_characters); printf("M"); break;
		case 23: c93_char('N', dest, j, values, bar_characters); printf("N"); break;
		case 24: c93_char('O', dest, j, values, bar_characters); printf("O"); break;
		case 25: c93_char('P', dest, j, values, bar_characters); printf("P"); break;
		case 26: c93_char('Q', dest, j, values, bar_characters); printf("Q"); break;
		case 27: c93_char('R', dest, j, values, bar_characters); printf("R"); break;
		case 28: c93_char('S', dest, j, values, bar_characters); printf("S"); break;
		case 29: c93_char('T', dest, j, values, bar_characters); printf("T"); break;
		case 30: c93_char('U', dest, j, values, bar_characters); printf("U"); break;
		case 31: c93_char('V', dest, j, values, bar_characters); printf("V"); break;
		case 32: c93_char('W', dest, j, values, bar_characters); printf("W"); break;
		case 33: c93_char('X', dest, j, values, bar_characters); printf("X"); break;
		case 34: c93_char('Y', dest, j, values, bar_characters); printf("Y"); break;
		case 35: c93_char('Z', dest, j, values, bar_characters); printf("Z"); break;
		case 36: c93_char('-', dest, j, values, bar_characters); printf("-"); break;
		case 37: c93_char('.', dest, j, values, bar_characters); printf("."); break;
		case 38: c93_char(' ', dest, j, values, bar_characters); printf("_"); break;
		case 39: c93_char('$', dest, j, values, bar_characters); printf("$"); break;
		case 40: c93_char('/', dest, j, values, bar_characters); printf("/"); break;
		case 41: c93_char('+', dest, j, values, bar_characters); printf("+"); break;
		case 42: c93_char('%', dest, j, values, bar_characters); printf("%%"); break;
		case 43: c93_shift(1, dest, j, values, bar_characters); printf("~1"); break;
		case 44: c93_shift(2, dest, j, values, bar_characters); printf("~2"); break;
		case 45: c93_shift(3, dest, j, values, bar_characters); printf("~3"); break;
		case 46: c93_shift(4, dest, j, values, bar_characters); printf("~4"); break;
	}
}

void c93(char source[], char dest[])
{ /* Code 93 is an advancement on Code 39+ */
	int i, j, weight, c, k, values[200], bar_characters;

	j = 0;

	/* Start character */
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '4'; j++;
	dest[j] = '1'; j++;
	bar_characters = 0;

	/* Message Content */
	for(i = 0; i < strlen(source); i++)
	{
		switch(source[i])
		{
		/*	case '\0': NUL - Can't be used with string input
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('U', dest, &j, values, &bar_characters);
				break; */
			case 1: /* SOH */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('A', dest, &j, values, &bar_characters);
				break;
			case 2: /* STX */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('B', dest, &j, values, &bar_characters);
				break;
			case 3: /* ETX */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('C', dest, &j, values, &bar_characters);
				break;
			case 4: /* EOT */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('D', dest, &j, values, &bar_characters);
				break;
			case 5: /* ENQ */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('E', dest, &j, values, &bar_characters);
				break;
			case 6: /* ACK */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('F', dest, &j, values, &bar_characters);
				break;
			case 7: /* BEL */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('G', dest, &j, values, &bar_characters);
				break;
			case 8: /* BS */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('H', dest, &j, values, &bar_characters);
				break;
			case 9: /* HT */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('I', dest, &j, values, &bar_characters);
				break;
			case 10: /* LF */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('J', dest, &j, values, &bar_characters);
				break;
			case 11: /* VT */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('K', dest, &j, values, &bar_characters);
				break;
			case 12: /* FF */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('L', dest, &j, values, &bar_characters);
				break;
			case 13: /* CR */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('M', dest, &j, values, &bar_characters);
				break;
			case 14: /* SO */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('N', dest, &j, values, &bar_characters);
				break;
			case 15: /* SI */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('O', dest, &j, values, &bar_characters);
				break;
			case 16: /* DLE */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('P', dest, &j, values, &bar_characters);
				break;
			case 17: /* DC1 */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('Q', dest, &j, values, &bar_characters);
				break;
			case 18: /* DC2 */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('R', dest, &j, values, &bar_characters);
				break;
			case 19: /* DC3 */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('S', dest, &j, values, &bar_characters);
				break;
			case 20: /* DC4 */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('T', dest, &j, values, &bar_characters);
				break;
			case 21: /* NAK */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('U', dest, &j, values, &bar_characters);
				break;
			case 22: /* SYN */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('V', dest, &j, values, &bar_characters);
				break;
			case 23: /* ETB */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('W', dest, &j, values, &bar_characters);
				break;
			case 24: /* CAN */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('X', dest, &j, values, &bar_characters);
				break;
			case 25: /* EM */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('Y', dest, &j, values, &bar_characters);
				break;
			case 26: /* SUB */
				c93_shift(1, dest, &j, values, &bar_characters);
				c93_char('Z', dest, &j, values, &bar_characters);
				break;
			case 27: /* ESC */
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('A', dest, &j, values, &bar_characters);
				break;
			case 28: /* FS */
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('B', dest, &j, values, &bar_characters);
				break;
			case 29: /* GS */
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('C', dest, &j, values, &bar_characters);
				break;
			case 30: /* RS */
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('D', dest, &j, values, &bar_characters);
				break;
			case 31: /* US */
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('E', dest, &j, values, &bar_characters);
				break;
			case '!':
				c93_shift(3, dest, &j, values, &bar_characters);
				c93_char('A', dest, &j, values, &bar_characters);
				break;
			case '"':
				c93_shift(3, dest, &j, values, &bar_characters);
				c93_char('B', dest, &j, values, &bar_characters);
				break;
			case '#':
				c93_shift(3, dest, &j, values, &bar_characters);
				c93_char('C', dest, &j, values, &bar_characters);
				break;
			case '&':
				c93_shift(3, dest, &j, values, &bar_characters);
				c93_char('F', dest, &j, values, &bar_characters);
				break;
			case '\'':
				c93_shift(3, dest, &j, values, &bar_characters);
				c93_char('G', dest, &j, values, &bar_characters);
				break;
			case '(':
				c93_shift(3, dest, &j, values, &bar_characters);
				c93_char('H', dest, &j, values, &bar_characters);
				break;
			case ')':
				c93_shift(3, dest, &j, values, &bar_characters);
				c93_char('I', dest, &j, values, &bar_characters);
				break;
			case '*':
				c93_shift(3, dest, &j, values, &bar_characters);
				c93_char('J', dest, &j, values, &bar_characters);
				break;
			case ',':
				c93_shift(3, dest, &j, values, &bar_characters);
				c93_char('L', dest, &j, values, &bar_characters);
				break;
			case ':':
				c93_shift(3, dest, &j, values, &bar_characters);
				c93_char('Z', dest, &j, values, &bar_characters);
				break;
			case ';':
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('F', dest, &j, values, &bar_characters);
				break;
			case '<':
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('G', dest, &j, values, &bar_characters);
				break;
			case '=':
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('H', dest, &j, values, &bar_characters);
				break;
			case '>':
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('I', dest, &j, values, &bar_characters);
				break;
			case '?':
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('J', dest, &j, values, &bar_characters);
				break;
			case '@':
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('V', dest, &j, values, &bar_characters);
				break;
			case '[':
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('K', dest, &j, values, &bar_characters);
				break;
			case '\\':
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('L', dest, &j, values, &bar_characters);
				break;
			case ']':
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('M', dest, &j, values, &bar_characters);
				break;
			case '^':
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('N', dest, &j, values, &bar_characters);
				break;
			case '_':
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('O', dest, &j, values, &bar_characters);
				break;
			case '`':
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('W', dest, &j, values, &bar_characters);
				break;
			case 'a':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('A', dest, &j, values, &bar_characters);
				break;
			case 'b':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('B', dest, &j, values, &bar_characters);
				break;
			case 'c':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('C', dest, &j, values, &bar_characters);
				break;
			case 'd':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('D', dest, &j, values, &bar_characters);
				break;
			case 'e':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('E', dest, &j, values, &bar_characters);
				break;
			case 'f':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('F', dest, &j, values, &bar_characters);
				break;
			case 'g':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('G', dest, &j, values, &bar_characters);
				break;
			case 'h':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('H', dest, &j, values, &bar_characters);
				break;
			case 'i':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('I', dest, &j, values, &bar_characters);
				break;
			case 'j':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('J', dest, &j, values, &bar_characters);
				break;
			case 'k':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('K', dest, &j, values, &bar_characters);
				break;
			case 'l':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('L', dest, &j, values, &bar_characters);
				break;
			case 'm':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('M', dest, &j, values, &bar_characters);
				break;
			case 'n':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('N', dest, &j, values, &bar_characters);
				break;
			case 'o':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('O', dest, &j, values, &bar_characters);
				break;
			case 'p':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('P', dest, &j, values, &bar_characters);
				break;
			case 'q':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('Q', dest, &j, values, &bar_characters);
				break;
			case 'r':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('R', dest, &j, values, &bar_characters);
				break;
			case 's':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('S', dest, &j, values, &bar_characters);
				break;
			case 't':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('T', dest, &j, values, &bar_characters);
				break;
			case 'u':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('U', dest, &j, values, &bar_characters);
				break;
			case 'v':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('V', dest, &j, values, &bar_characters);
				break;
			case 'w':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('W', dest, &j, values, &bar_characters);
				break;
			case 'x':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('X', dest, &j, values, &bar_characters);
				break;
			case 'y':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('Y', dest, &j, values, &bar_characters);
				break;
			case 'z':
				c93_shift(4, dest, &j, values, &bar_characters);
				c93_char('Z', dest, &j, values, &bar_characters);
				break;
			case '{':
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('P', dest, &j, values, &bar_characters);
				break;
			case '|':
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('Q', dest, &j, values, &bar_characters);
				break;
			case '}':
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('R', dest, &j, values, &bar_characters);
				break;
			case '~':
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('S', dest, &j, values, &bar_characters);
				break;
			case 127:
				c93_shift(2, dest, &j, values, &bar_characters);
				c93_char('T', dest, &j, values, &bar_characters);
				break;
			default:
				c93_char(source[i], dest, &j, values, &bar_characters);
				break;
		}
	}

	/* Check digit C */

	printf("zebar: Drawing Code 93 with check digits \""); /* Characters output from c93_check */

	c = 0;
	weight = 1;
	for(i = bar_characters - 1; i >= 0; i--)
	{
		c += values[i] * weight;
		weight ++;
		if(weight == 21)
		{
			weight = 1;
		}
	}
	c = c % 47;
	c93_check(c, dest, &j, values, &bar_characters);

	/* Check digit K */

	k = 0;
	weight = 1;
	for(i = bar_characters - 1; i >= 0; i--)
	{
		k += values[i] * weight;
		weight ++;
		if(weight == 16)
		{
			weight = 1;
		}
	}
	k = k % 47;
	c93_check(k, dest, &j, values, &bar_characters);

	printf("\"\n");

	/* Stop character */
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '4'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '\0';	
}
