/*  Zebar - A barcode generating program using SDL
    Copyright (C) 2006 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

char ean_check(char source[])
{ /* Calculate the correct check digit for a EAN-13 barcode */
	int i, count, check_digit;
	char temp[2];

	count = 0;
	temp[1] = '\0';

	for (i = strlen(source) - 1; i >= 0; i--)
	{
		temp[0] = source[i];
		count += atoi(temp);

		if (!((i%2) == 0))
		{
			count += 2 * (atoi(temp));
		}
	}

	check_digit = 10 - (count%10);

	switch(check_digit)
	{
		case 1: return '1'; break;
		case 2: return '2'; break;
		case 3: return '3'; break;
		case 4: return '4'; break;
		case 5: return '5'; break;
		case 6: return '6'; break;
		case 7: return '7'; break;
		case 8: return '8'; break;
		case 9: return '9'; break;
		default: return '0'; break;
	}

	return '0'; /* Shut up compiler error */

}

void ean13(char source[], char dest[])
{
	int length, i, j, half_way;
	char parity[6];

	if (strlen(source) != 12)
	{
		printf("zebar: Invalid EAN-13\n");
		exit(0);
	}

	/* Add the appropriate check digit */
	length = strlen(source);
	source[length] = ean_check(source);
	source[length + 1] = '\0';
	printf("zebar: Drawing EAN-13 \"%s\"\n", source);

	switch(source[0]) /* Parity dependant on first digit of country code */
	{
		case '1': strcpy(parity, "OEOEE"); break;
		case '2': strcpy(parity, "OEEOE"); break;
		case '3': strcpy(parity, "OEEEO"); break;
		case '4': strcpy(parity, "EOOEE"); break;
		case '5': strcpy(parity, "EEOOE"); break;
		case '6': strcpy(parity, "EEEOO"); break;
		case '7': strcpy(parity, "EOEOE"); break;
		case '8': strcpy(parity, "EOEEO"); break;
		case '9': strcpy(parity, "EEOEO"); break;
		default: strcpy(parity, "OOOOO"); break;
	}

	/* Now get on with the cipher */

	j = 0;
	half_way = 7;

	/* start character */
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;

	for(i = 1; i <= strlen(source); i++)
	{
		if (i == half_way)
		{
			/* middle character - separates manufacturer no. from product no. */
			/* also inverses right hand characters */
			dest[j] = '1'; j++;
			dest[j] = '1'; j++;
			dest[j] = '1'; j++;
			dest[j] = '1'; j++;
			dest[j] = '1'; j++;
		}

		if(((i > 1) && (i < 7)) && (parity[i - 2] == 'E'))
		{
			switch(source[i])
			{
				case '0': 
					dest[j] = '1'; j++;
					dest[j] = '1'; j++;
					dest[j] = '2'; j++;
					dest[j] = '3'; j++;
					break;
				case '1': 
					dest[j] = '1'; j++;
					dest[j] = '2'; j++;
					dest[j] = '2'; j++;
					dest[j] = '2'; j++;
					break;
				case '2': 
					dest[j] = '2'; j++;
					dest[j] = '2'; j++;
					dest[j] = '1'; j++;
					dest[j] = '2'; j++;
					break;
				case '3': 
					dest[j] = '1'; j++;
					dest[j] = '1'; j++;
					dest[j] = '4'; j++;
					dest[j] = '1'; j++;
					break;
				case '4': 
					dest[j] = '2'; j++;
					dest[j] = '3'; j++;
					dest[j] = '1'; j++;
					dest[j] = '1'; j++;
					break;
				case '5': 
					dest[j] = '1'; j++;
					dest[j] = '3'; j++;
					dest[j] = '2'; j++;
					dest[j] = '1'; j++;
					break;
				case '6': 
					dest[j] = '4'; j++;
					dest[j] = '1'; j++;
					dest[j] = '1'; j++;
					dest[j] = '1'; j++;
					break;
				case '7': 
					dest[j] = '2'; j++;
					dest[j] = '1'; j++;
					dest[j] = '3'; j++;
					dest[j] = '1'; j++;
					break;
				case '8': 
					dest[j] = '3'; j++;
					dest[j] = '1'; j++;
					dest[j] = '2'; j++;
					dest[j] = '1'; j++;
					break;
				case '9': 
					dest[j] = '2'; j++;
					dest[j] = '1'; j++;
					dest[j] = '1'; j++;
					dest[j] = '3'; j++;
					break;
			}
		}
		else
		{
			switch(source[i])
			{
				case '0': 
					dest[j] = '3'; j++;
					dest[j] = '2'; j++;
					dest[j] = '1'; j++;
					dest[j] = '1'; j++;
					break;
				case '1': 
					dest[j] = '2'; j++;
					dest[j] = '2'; j++;
					dest[j] = '2'; j++;
					dest[j] = '1'; j++;
					break;
				case '2': 
					dest[j] = '2'; j++;
					dest[j] = '1'; j++;
					dest[j] = '2'; j++;
					dest[j] = '2'; j++;
					break;
				case '3': 
					dest[j] = '1'; j++;
					dest[j] = '4'; j++;
					dest[j] = '1'; j++;
					dest[j] = '1'; j++;
					break;
				case '4': 
					dest[j] = '1'; j++;
					dest[j] = '1'; j++;
					dest[j] = '3'; j++;
					dest[j] = '2'; j++;
					break;
				case '5': 
					dest[j] = '1'; j++;
					dest[j] = '2'; j++;
					dest[j] = '3'; j++;
					dest[j] = '1'; j++;
					break;
				case '6': 
					dest[j] = '1'; j++;
					dest[j] = '1'; j++;
					dest[j] = '1'; j++;
					dest[j] = '4'; j++;
					break;
				case '7': 
					dest[j] = '1'; j++;
					dest[j] = '3'; j++;
					dest[j] = '1'; j++;
					dest[j] = '2'; j++;
					break;
				case '8': 
					dest[j] = '1'; j++;
					dest[j] = '2'; j++;
					dest[j] = '1'; j++;
					dest[j] = '3'; j++;
					break;
				case '9': 
					dest[j] = '3'; j++;
					dest[j] = '1'; j++;
					dest[j] = '1'; j++;
					dest[j] = '2'; j++;
					break;
			}
		}
	}

	/* stop character */
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '\0';
}

char isbn13_check(char source[]) /* For ISBN(13) only */
{
	int i, j, weight, sum, check;
	char temp[2];

	sum = 0;
	temp[1] = '\0';
	weight = 1;
	for(i = 0; i < (strlen(source) - 1); i++)
	{
		temp[0] = source[i];
		j = atoi(temp);
		sum += j * weight;
		if(weight == 1) weight = 3; else weight = 1;
	}

	check = sum % 10;

	check = 10 - check;

	switch(check)
	{
		case 1: return '1'; break;
		case 2: return '2'; break;
		case 3: return '3'; break;
		case 4: return '4'; break;
		case 5: return '5'; break;
		case 6: return '6'; break;
		case 7: return '7'; break;
		case 8: return '8'; break;
		case 9: return '9'; break;
		default: return '0'; break;
	}

	return '0'; /* Shut up compiler error */
}

char isbn_check(char source[]) /* For ISBN(10) and SBN only */
{
	int i, j, weight, sum, check;
	char temp[2];

	sum = 0;
	temp[1] = '\0';
	weight = 1;
	for(i = 0; i < (strlen(source) - 1); i++)
	{
		temp[0] = source[i];
		j = atoi(temp);
		sum += j * weight;
		weight++;
	}

	check = sum % 11;

	switch(check)
	{
		case 1: return '1'; break;
		case 2: return '2'; break;
		case 3: return '3'; break;
		case 4: return '4'; break;
		case 5: return '5'; break;
		case 6: return '6'; break;
		case 7: return '7'; break;
		case 8: return '8'; break;
		case 9: return '9'; break;
		case 10: return 'X'; break;
		default: return '0'; break;
	}

	return '0'; /* Shut up compiler error */
}

void isbn(char source[], char dest[]) /* Make an EAN-13 barcode from an SBN or ISBN */
{
	int i;
	char check_digit;

	/* Input must be 9, 10 or 13 characters */
	if(((strlen(source) < 9) || (strlen(source) > 13)) || ((strlen(source) > 10) && (strlen(source) < 13)))
	{
		printf("zebar: Invalid SBN or ISBN\n");
		exit(0);
	}

	/* Catch lower case X in input */
	if(source[strlen(source) - 1] == 'x')
	{
		source[strlen(source) - 1] = 'X';
	}

	if(strlen(source) == 13) /* Using 13 character ISBN */
	{
		if(!(((source[0] == '9') && (source[1] == '7')) &&
		((source[2] == '8') || (source[2] == '9'))))
		{
			printf("zebar: Invalid ISBN\n");
			exit(0);
		}

		check_digit = isbn13_check(source);
		if (source[strlen(source) - 1] != check_digit)
		{
			printf("zebar: Invalid ISBN\n");
			exit(0);
		}
		source[12] = '\0';

		ean13(source, dest);
	}

	if(strlen(source) == 10) /* Using 10 digit ISBN */
	{
		check_digit = isbn_check(source);
		if(check_digit != source[strlen(source) - 1])
		{
			printf("zebar: Invalid ISBN\n");
			exit(0);
		}
		for(i = 13; i > 0; i--)
		{
			source[i] = source[i - 3];
		}
		source[0] = '9';
		source[1] = '7';
		source[2] = '8';
		source[12] = '\0';

		ean13(source, dest);
	}

	if(strlen(source) == 9) /* Using 9 digit SBN */
	{
		/* Add leading zero */
		for(i = 10; i > 0; i--)
		{
			source[i] = source[i - 1];
		}
		source[0] = '0';

		/* Verify check digit */
		check_digit = isbn_check(source);
		if(check_digit != source[strlen(source) - 1])
		{
			printf("zebar: Invalid SBN\n");
			exit(0);
		}

		/* Convert to EAN-13 number */
		for(i = 13; i > 0; i--)
		{
			source[i] = source[i - 3];
		}
		source[0] = '9';
		source[1] = '7';
		source[2] = '8';
		source[12] = '\0';

		ean13(source, dest);
	}

}
