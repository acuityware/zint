/*  Zebar - A barcode generating program using SDL
    Copyright (C) 2006 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <stdio.h>
#include <string.h>

#define	EAN2	2
#define	EAN5	5

void add_on(char source[], char dest[], int mode)
{
	char parity[6];
	int i, j, code_type;

	/* If an add-on then append with space */
	if (mode == 0)
	{
		j = 0;
	}
	else
	{
		j = (strlen(dest));
		dest[j] = '9'; j++;
	}

	/* Start character */
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '2'; j++;

	/* Determine EAN2 or EAN5 add-on */
	if(strlen(source) == 2)
	{
		code_type = EAN2;
	}
	else
	{
		code_type = EAN5;
	}

	/* Calculate parity for EAN2 */
	if(code_type == EAN2)
	{
		int code_value, parity_bit;

		switch(source[0])
		{
			case '0': code_value = 0; break;
			case '1': code_value = 10; break;
			case '2': code_value = 20; break;
			case '3': code_value = 30; break;
			case '4': code_value = 40; break;
			case '5': code_value = 50; break;
			case '6': code_value = 60; break;
			case '7': code_value = 70; break;
			case '8': code_value = 80; break;
			case '9': code_value = 90; break;
		}
	
		switch(source[1])
		{
			case '0': break;
			case '1': code_value += 1; break;
			case '2': code_value += 2; break;
			case '3': code_value += 3; break;
			case '4': code_value += 4; break;
			case '5': code_value += 5; break;
			case '6': code_value += 6; break;
			case '7': code_value += 7; break;
			case '8': code_value += 8; break;
			case '9': code_value += 9; break;
		}

		parity_bit = code_value%4;

		switch(parity_bit)
		{
			case 0: strcpy(parity, "OO"); break;
			case 1: strcpy(parity, "OE"); break;
			case 2: strcpy(parity, "EO"); break;
			case 3: strcpy(parity, "EE"); break;
		}

	}

	if(code_type == EAN5)
	{
		int values[6], parity_sum, parity_bit;

		for(i = 0; i < 6; i++)
		{
			switch(source[i])
			{
				case '0': values[i] = 0; break;
				case '1': values[i] = 1; break;
				case '2': values[i] = 2; break;
				case '3': values[i] = 3; break;
				case '4': values[i] = 4; break;
				case '5': values[i] = 5; break;
				case '6': values[i] = 6; break;
				case '7': values[i] = 7; break;
				case '8': values[i] = 8; break;
				case '9': values[i] = 9; break;
			}
		}

		parity_sum = (3 * (values[0] + values[2] + values[4]));
		parity_sum += (9 * (values[1] + values[3]));

		parity_bit = parity_sum%10;

		switch(parity_bit)
		{
			case 0: strcpy(parity, "EEOOO"); break;
			case 1: strcpy(parity, "EOEOO"); break;
			case 2: strcpy(parity, "EOOEO"); break;
			case 3: strcpy(parity, "EOOOE"); break;
			case 4: strcpy(parity, "OEEOO"); break;
			case 5: strcpy(parity, "OOEEO"); break;
			case 6: strcpy(parity, "OOOEE"); break;
			case 7: strcpy(parity, "OEOEO"); break;
			case 8: strcpy(parity, "OEOOE"); break;
			case 9: strcpy(parity, "OOEOE"); break;
		}
	}

	for(i = 0; i < strlen(source); i++)
	{
		switch(parity[i])
		{
			case 'O':
				switch(source[i])
				{
					case '0': 
						dest[j] = '3'; j++;
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						break;
					case '1': 
						dest[j] = '2'; j++;
						dest[j] = '2'; j++;
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						break;
					case '2': 
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						dest[j] = '2'; j++;
						break;
					case '3': 
						dest[j] = '1'; j++;
						dest[j] = '4'; j++;
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						break;
					case '4': 
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						dest[j] = '3'; j++;
						dest[j] = '2'; j++;
						break;
					case '5': 
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						dest[j] = '3'; j++;
						dest[j] = '1'; j++;
						break;
					case '6': 
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						dest[j] = '4'; j++;
						break;
					case '7': 
						dest[j] = '1'; j++;
						dest[j] = '3'; j++;
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						break;
					case '8': 
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						dest[j] = '3'; j++;
						break;
					case '9': 
						dest[j] = '3'; j++;
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						break;
				}
				break;
			case 'E':
				switch(source[i])
				{
					case '0': 
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						dest[j] = '3'; j++;
						break;
					case '1': 
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						dest[j] = '2'; j++;
						dest[j] = '2'; j++;
						break;
					case '2': 
						dest[j] = '2'; j++;
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						break;
					case '3': 
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						dest[j] = '4'; j++;
						dest[j] = '1'; j++;
						break;
					case '4': 
						dest[j] = '2'; j++;
						dest[j] = '3'; j++;
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						break;
					case '5': 
						dest[j] = '1'; j++;
						dest[j] = '3'; j++;
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						break;
					case '6': 
						dest[j] = '4'; j++;
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						break;
					case '7': 
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						dest[j] = '3'; j++;
						dest[j] = '1'; j++;
						break;
					case '8': 
						dest[j] = '3'; j++;
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						break;
					case '9': 
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						dest[j] = '3'; j++;
						break;
				}
				break;
		}

		/* Glyph separator */
		if(i != (strlen(source) - 1))
		{
			dest[j] = '1'; j++;
			dest[j] = '1'; j++;
		}
	}

	dest[j] = '\0';
}
