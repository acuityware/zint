/*  Zebar - A barcode generating program using SDL
    Copyright (C) 2006 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

char get_check(char source[])
{ /* Calculate the correct check digit for a UPC barcode */
	int i, count, check_digit;
	char temp[2];

	count = 0;
	temp[1] = '\0';

	for (i = 0; i < strlen(source); i++)
	{
		temp[0] = source[i];
		count += atoi(temp);

		if ((i%2) == 0)
		{
			count += 2 * (atoi(temp));
		}
	}

	check_digit = 10 - (count%10);

	switch(check_digit)
	{
		case 1: return '1'; break;
		case 2: return '2'; break;
		case 3: return '3'; break;
		case 4: return '4'; break;
		case 5: return '5'; break;
		case 6: return '6'; break;
		case 7: return '7'; break;
		case 8: return '8'; break;
		case 9: return '9'; break;
		default: return '0'; break;
	}

	return '0'; /* Shut up compiler error */

}

void upca_draw(char source[], char dest[])
{ /* UPC A is usually used for 12 digit numbers, but this function takes a source of any length */
	int i, j;
	int half_way;

	/* Now get on with the cipher */

	j = 0;
	half_way = strlen(source) / 2;

	/* start character */
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;

	for(i = 0; i <= strlen(source); i++)
	{
		if (i == half_way)
		{
			/* middle character - separates manufacturer no. from product no. */
			/* also inverses right hand characters */
			dest[j] = '1'; j++;
			dest[j] = '1'; j++;
			dest[j] = '1'; j++;
			dest[j] = '1'; j++;
			dest[j] = '1'; j++;
		}

		switch(source[i])
		{
			case '0': 
				dest[j] = '3'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case '1': 
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				break;
			case '2': 
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '2'; j++;
				break;
			case '3': 
				dest[j] = '1'; j++;
				dest[j] = '4'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				break;
			case '4': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '3'; j++;
				dest[j] = '2'; j++;
				break;
			case '5': 
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '3'; j++;
				dest[j] = '1'; j++;
				break;
			case '6': 
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '4'; j++;
				break;
			case '7': 
				dest[j] = '1'; j++;
				dest[j] = '3'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				break;
			case '8': 
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				dest[j] = '1'; j++;
				dest[j] = '3'; j++;
				break;
			case '9': 
				dest[j] = '3'; j++;
				dest[j] = '1'; j++;
				dest[j] = '1'; j++;
				dest[j] = '2'; j++;
				break;
		}
	}

	/* stop character */
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '\0';
}

void ean8(char source[], char dest[])
{ /* Make a UPC A barcode when we haven't been given the check digit */
	int length;

	length = strlen(source);
	if(length != 7)
	{
		printf("zebar: Invalid EAN-8\n");
		exit(0);
	}
	printf("zebar: Drawing EAN-8 \"%s%c\"\n", source, get_check(source));
	source[length] = get_check(source);
	source[length + 1] = '\0';
	upca_draw(source, dest);
}

void upca(char source[], char dest[])
{ /* Make a UPC A barcode when we haven't been given the check digit */
	int length;

	length = strlen(source);
	if(length != 11)
	{
		printf("zebar: Invalid UPC-A\n");
		exit(0);
	}
	printf("zebar: Drawing UPC-A \"%s%c\"\n", source, get_check(source));
	source[length] = get_check(source);
	source[length + 1] = '\0';
	upca_draw(source, dest);
}

void upce(char source[], char dest[])
{ /* UPC E is a zero-compressed version of UPC A */
	int i, j, num_system;
	char emode, equivalent[12], check_digit, parity[8], temp[8];

	if((strlen(source) != 6) && (strlen(source) != 7))
	{
		printf("zebar: Invalid UPC-E\n");
		exit(0);
	}

	/* Two number systems can be used - system 0 and system 1 */

	if(strlen(source) == 7)
	{
		switch(source[0])
		{
			case '0':
				num_system = 0;
				break;
			case '1':
				num_system = 1;
				break;
			default:
				num_system = 0;
				printf("zebar: Number system %c not supported - using system 0 instead\n", source[0]);
				break;
		}
		strcpy(temp, source);
		for(i = 1; i <= 7; i++)
		{
			source[i - 1] = temp[i];
		}
	}
	else
		num_system = 0;

	/* Expand the zero-compressed UPCE code to make a UPCA equivalent */

	emode = source[5];
	for(i = 0; i < 11; i++)
	{
		equivalent[i] = '0';
	}
	equivalent[1] = source[0];
	equivalent[2] = source[1];
	equivalent[11] = '\0';

	switch(emode)
	{
		case '0':
		case '1':
		case '2':
			equivalent[3] = emode;
			equivalent[8] = source[2];
			equivalent[9] = source[3];
			equivalent[10] = source[4];
			break;
		case '3':
			equivalent[3] = source[2];
			equivalent[9] = source[3];
			equivalent[10] = source[4];
			break;
		case '4':
			equivalent[3] = source[2];
			equivalent[4] = source[3];
			equivalent[10] = source[4];
			break;
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
			equivalent[3] = source[2];
			equivalent[4] = source[3];
			equivalent[5] = source[4];
			equivalent[10] = emode;
			break;
	}

	/* Get the check digit from the expanded UPCA code */

	check_digit = get_check(equivalent);
	printf("zebar: Drawing UPC-E \"%d%s%c\"\n", num_system, source, check_digit);

	/* Use the number system and check digit information to choose a parity scheme */

	switch(num_system)
	{
		case 1:
			switch(check_digit)
			{
				case '0':
					strcpy(parity, "OOOEEE");
					break;
				case '1':
					strcpy(parity, "OOEOEE");
					break;
				case '2':
					strcpy(parity, "OOEEOE");
					break;
				case '3':
					strcpy(parity, "OOEEEO");
					break;
				case '4':
					strcpy(parity, "OEOOEE");
					break;
				case '5':
					strcpy(parity, "OEEOOE");
					break;
				case '6':
					strcpy(parity, "OEEEOO");
					break;
				case '7':
					strcpy(parity, "OEOEOE");
					break;
				case '8':
					strcpy(parity, "OEOEEO");
					break;
				case '9':
					strcpy(parity, "OEEOEO");
					break;
			}
			break;

		case 0:
		default:
			switch(check_digit)
			{
				case '0':
					strcpy(parity, "EEEOOO");
					break;
				case '1':
					strcpy(parity, "EEOEOO");
					break;
				case '2':
					strcpy(parity, "EEOOEO");
					break;
				case '3':
					strcpy(parity, "EEOOOE");
					break;
				case '4':
					strcpy(parity, "EOEEOO");
					break;
				case '5':
					strcpy(parity, "EOOEEO");
					break;
				case '6':
					strcpy(parity, "EOOOEE");
					break;
				case '7':
					strcpy(parity, "EOEOEO");
					break;
				case '8':
					strcpy(parity, "EOEOOE");
					break;
				case '9':
					strcpy(parity, "EOOEOE");
					break;
			}
			break;
	}

	/* Take all this information and make the barcode pattern */

	j = 0;

	/* start character */
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;

	for(i = 0; i <= strlen(source); i++)
	{

		switch(parity[i])
		{

			case 'E':

				switch(source[i])
				{
					case '0': 
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						dest[j] = '3'; j++;
						break;
					case '1': 
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						dest[j] = '2'; j++;
						dest[j] = '2'; j++;
						break;
					case '2': 
						dest[j] = '2'; j++;
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						break;
					case '3': 
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						dest[j] = '4'; j++;
						dest[j] = '1'; j++;
						break;
					case '4': 
						dest[j] = '2'; j++;
						dest[j] = '3'; j++;
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						break;
					case '5': 
						dest[j] = '1'; j++;
						dest[j] = '3'; j++;
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						break;
					case '6': 
						dest[j] = '4'; j++;
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						break;
					case '7': 
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						dest[j] = '3'; j++;
						dest[j] = '1'; j++;
						break;
					case '8': 
						dest[j] = '3'; j++;
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						break;
					case '9': 
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						dest[j] = '3'; j++;
						break;
				}
				break;

			case 'O':
				switch(source[i])
				{
					case '0': 
						dest[j] = '3'; j++;
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						break;
					case '1': 
						dest[j] = '2'; j++;
						dest[j] = '2'; j++;
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						break;
					case '2': 
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						dest[j] = '2'; j++;
						break;
					case '3': 
						dest[j] = '1'; j++;
						dest[j] = '4'; j++;
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						break;
					case '4': 
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						dest[j] = '3'; j++;
						dest[j] = '2'; j++;
						break;
					case '5': 
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						dest[j] = '3'; j++;
						dest[j] = '1'; j++;
						break;
					case '6': 
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						dest[j] = '4'; j++;
						break;
					case '7': 
						dest[j] = '1'; j++;
						dest[j] = '3'; j++;
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						break;
					case '8': 
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						dest[j] = '1'; j++;
						dest[j] = '3'; j++;
						break;
					case '9': 
						dest[j] = '3'; j++;
						dest[j] = '1'; j++;
						dest[j] = '1'; j++;
						dest[j] = '2'; j++;
						break;
				}
				break;
		}
	}

	/* stop character */
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '1'; j++;
	dest[j] = '\0';
}
