#include <string.h>
#include <stdio.h>

void twelve_of_five(char source[], char dest[])
{ /* The 12 of 5 barcode system uses interlaced numerical characters */

	int i, j, k;
	char bars[7], spaces[7];

	/* Input must be an even number of characters for 12 of 5 to work */
	if ((strlen(source)%2) != 0)
	{
		int length;
		char temp[200];

		length = strlen(source);

		strcpy(temp, source);
		source[0] = '0';

		for(i = 0; i <= length; i++)
		{
			source[i + 1] = temp[i];
		}
	}

	printf("zebar: Drawing 12of5 \"%s\"\n", source);

	k = 0;

	/* start character */
	dest[k] = '1'; k++;
	dest[k] = '1'; k++;
	dest[k] = '1'; k++;
	dest[k] = '1'; k++;

	for(i = 0; i < strlen(source); i+=2 )
	{
		j = 0;
		switch(source[i])
		{
			case '0': 
				bars[j] = '1'; j++;
				bars[j] = '1'; j++;
				bars[j] = '2'; j++;
				bars[j] = '2'; j++;
				bars[j] = '1'; j++;
				break;
			case '1': 
				bars[j] = '2'; j++;
				bars[j] = '1'; j++;
				bars[j] = '1'; j++;
				bars[j] = '1'; j++;
				bars[j] = '2'; j++;
				break;
			case '2': 
				bars[j] = '1'; j++;
				bars[j] = '2'; j++;
				bars[j] = '1'; j++;
				bars[j] = '1'; j++;
				bars[j] = '2'; j++;
				break;
			case '3': 
				bars[j] = '2'; j++;
				bars[j] = '2'; j++;
				bars[j] = '1'; j++;
				bars[j] = '1'; j++;
				bars[j] = '1'; j++;
				break;
			case '4': 
				bars[j] = '1'; j++;
				bars[j] = '1'; j++;
				bars[j] = '2'; j++;
				bars[j] = '1'; j++;
				bars[j] = '2'; j++;
				break;
			case '5': 
				bars[j] = '2'; j++;
				bars[j] = '1'; j++;
				bars[j] = '2'; j++;
				bars[j] = '1'; j++;
				bars[j] = '1'; j++;
				break;
			case '6': 
				bars[j] = '1'; j++;
				bars[j] = '2'; j++;
				bars[j] = '2'; j++;
				bars[j] = '1'; j++;
				bars[j] = '1'; j++;
				break;
			case '7': 
				bars[j] = '1'; j++;
				bars[j] = '1'; j++;
				bars[j] = '1'; j++;
				bars[j] = '2'; j++;
				bars[j] = '2'; j++;
				break;
			case '8': 
				bars[j] = '2'; j++;
				bars[j] = '1'; j++;
				bars[j] = '1'; j++;
				bars[j] = '2'; j++;
				bars[j] = '1'; j++;
				break;
			case '9':
				bars[j] = '1'; j++;
				bars[j] = '2'; j++;
				bars[j] = '1'; j++;
				bars[j] = '2'; j++;
				bars[j] = '1'; j++;
				break;
		}
		bars[j] = '\0';
		j = 0;
		switch(source[i + 1])
		{
			case '0': 
				spaces[j] = '1'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '2'; j++;
				spaces[j] = '2'; j++;
				spaces[j] = '1'; j++;
				break;
			case '1': 
				spaces[j] = '2'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '2'; j++;
				break;
			case '2': 
				spaces[j] = '1'; j++;
				spaces[j] = '2'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '2'; j++;
				break;
			case '3': 
				spaces[j] = '2'; j++;
				spaces[j] = '2'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '1'; j++;
				break;
			case '4': 
				spaces[j] = '1'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '2'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '2'; j++;
				break;
			case '5': 
				spaces[j] = '2'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '2'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '1'; j++;
				break;
			case '6': 
				spaces[j] = '1'; j++;
				spaces[j] = '2'; j++;
				spaces[j] = '2'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '1'; j++;
				break;
			case '7': 
				spaces[j] = '1'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '2'; j++;
				spaces[j] = '2'; j++;
				break;
			case '8': 
				spaces[j] = '2'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '2'; j++;
				spaces[j] = '1'; j++;
				break;
			case '9':
				spaces[j] = '1'; j++;
				spaces[j] = '2'; j++;
				spaces[j] = '1'; j++;
				spaces[j] = '2'; j++;
				spaces[j] = '1'; j++;
				break;
		}
		spaces[j] = '\0';

		for(j = 0; j <= 4; j++)
		{
			dest[k] = bars[j]; k++;
			dest[k] = spaces[j]; k++;
		}
	}

	/* Stop character */
	dest[k] = '2'; k++;
	dest[k] = '1'; k++;
	dest[k] = '1'; k++;
	dest[k] = '\0';

}
