/*  Zebar - A barcode generating program using SDL
    Copyright (C) 2006 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <SDL/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define UPCA		1
#define UPCE		2
#define EAN2		3
#define EAN5		4
#define CODABAR		5
#define EAN8		8
#define MSI		9
#define ISBN		10
#define CODE11		11
#define I2OF5		12
#define EAN13		13
#define CODE25		25
#define CODE39		39
#define EXCODE39	40
#define CODE93		93
#define CODE128		128

void ean8(char source[], char dest[]); /* EAN 8 - Similar to UPCA and EAN13 */
void upca(char source[], char dest[]); /* Universal Product Code */
void upce(char source[], char dest[]); /* A zero compressed version of UPC A for small packages */
void c39(char source[], char dest[]); /* Code 3 from 9 (or Code 39) */
void ec39(char source[], char dest[]); /* Extended Code 3 from 9 (or Code 39+) */
void codabar(char source[], char dest[]); /* Codabar - a simple substitution cipher */
void two_of_five(char source[], char dest[]); /* Interlaced 2 of 5 */
void c93(char source[], char dest[]); /* Code 93 - a re-working of Code 39+, generates 2 check digits */
void ean13(char source[], char dest[]); /* EAN 13 - Used on products manufactured outside the US */
void isbn(char source[], char dest[]); /* International Standard Book Number > EAN 13 */
void add_on(char source[], char dest[], int mode); /* Add-on EAN-2 or EAN-5 */
void c128(char source[], char dest[]); /* Code 128 */
void code_two_of_five(char source[], char dest []); /* Code 2 of 5 (Non-Interlaced) */
void code_11(char source[], char dest[]); /* Code 11 */
void msi_plessey(char source[], char dest[]); /* MSI Plessey ^^NO CHECK DIGIT^^ */

Uint16 CreateHicolorPixel(SDL_PixelFormat * fmt, Uint8 red, Uint8 green,
			  Uint8 blue)
{
    Uint16 value;

    value = ((red >> fmt->Rloss) << fmt->Rshift) +
	((green >> fmt->Gloss) << fmt->Gshift) +
	((blue >> fmt->Bloss) << fmt->Bshift);

    return value;
}

void plot(char code[], char template[])
/* 'plots' the barcode into a template string where X is a bar and _ is a blank */
{
	int status = 1; /* 1 for black, 0 for white */
	int i, j, k;
	char extract[2];
	int bar_width;

	extract[1] = '\0';
	k = 0;

	for(i = 0; i <= strlen(code); i++)
	{
		extract[0] = code[i];
		bar_width = atoi(extract);
		if(bar_width == 9) { bar_width = 15; }
		for(j = 0; j < bar_width; j++)
		{
			if(status == 1) { template[k] = 'X'; } else { template[k] = '_'; }
			k++;
		}
		if(status == 1) { status = 0; } else { status = 1; }
	}
	template[k] = '\0';
}

void scale(int multiple, char source[], char dest[])
{
/* calculates how large the barcode can be - i.e. if more than one pixel can be used per unit width */
	int i, j, k;

	j = 0;

	for(i = 0; i < strlen(source); i++)
	{
		for(k = 0; k < multiple; k++)
		{
			dest[j] = source[i];
			j++;
		}
	}

	dest[j] = '\0';
}

int main(int argc, char *argv[])
{
	char code[10000];
	char template[100000];
	char scaled_template[100000];

    SDL_Surface *screen;
	SDL_Event event;
    Uint16 *raw_pixels;
    int x, y, userwidth, calcwidth, calcheight, addon;
	int i, unitsize, borderwidth, mode, data;

	userwidth = 256;

    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
	printf("Unable to initialize SDL: %s\n", SDL_GetError());
	return 1;
    }

	addon = 0;
    atexit(SDL_Quit);
	mode = CODE128; /* Sets the default */

	for (i = 0; i < argc; i++) {
		if (!strcmp(argv[i], "--upca")) {
			mode = UPCA;
		}
		if (!strcmp(argv[i], "--ean8")) {
			mode = EAN8;
		}
		if (!strcmp(argv[1], "--upce")) {
			mode = UPCE;
		}
		if (!strcmp(argv[i], "--c39")) {
			mode = CODE39;
		}
		if (!strcmp(argv[i], "--ec39")) {
			mode = EXCODE39;
		}
		if (!strcmp(argv[i], "--codabar")) {
			mode = CODABAR;
		}
		if (!strcmp(argv[i], "--i25")) {
			mode = I2OF5;
		}
		if (!strcmp(argv[i], "--c93")) {
			mode = CODE93;
		}
		if (!strcmp(argv[i], "--ean13")) {
			mode = EAN13;
		}
		if (!strcmp(argv[i], "--isbn")) {
			mode = ISBN;
		}
		if (!strcmp(argv[i], "--c128")) {
			mode = CODE128;
		}
		if (!strcmp(argv[i], "--c25")) {
			mode = CODE25;
		}
		if (!strcmp(argv[i], "--c11")) {
			mode = CODE11;
		}
		if (!strcmp(argv[i], "--msi")) {
			mode = MSI;
		}
		if (!strcmp(argv[i], "--ean2")) {
			mode = EAN2;
		}
		if (!strcmp(argv[i], "--ean5")) {
			mode = EAN5;
		}
		if (!strcmp(argv[i], "--addon")) {
			addon = i + 1;
		}

	}

	data = argc - 1;

	switch (mode)
	{
		case UPCA: upca(argv[data], code);
			break;
		case EAN8: ean8(argv[data], code);
			break;
		case UPCE: upce(argv[data], code);
			break;
		case CODE39: c39(argv[data], code);
			break;
		case EXCODE39: ec39(argv[data], code);
			break;
		case CODABAR: codabar(argv[data], code);
			break;
		case I2OF5: two_of_five(argv[data], code);
			break;
		case CODE93: c93(argv[data], code);
			break;
		case EAN13: ean13(argv[data], code);
			break;
		case ISBN: isbn(argv[data], code);
			break;
		case CODE128: c128(argv[data], code);
			break;
		case CODE25: code_two_of_five(argv[data], code);
			break;
		case CODE11: code_11(argv[data], code);
			break;
		case MSI: msi_plessey(argv[data], code);
			break;
		case EAN2: add_on(argv[data], code, 0);
			break;
		case EAN5: add_on(argv[data], code, 0);
			break;
		default: c128(argv[data], code);
			break;
	}

	if (addon != 0)
	{
		add_on(argv[addon], code, 1);
	}

	plot(code, template);

	calcwidth = strlen(template);
	if(userwidth > calcwidth) calcwidth = userwidth;
	calcheight = (calcwidth * 3) / 4;
	unitsize = calcheight / strlen(template);
	if (unitsize == 0) unitsize = 1;
	scale(unitsize, template, scaled_template);
	borderwidth = (calcwidth - strlen(scaled_template)) / 2;

    screen = SDL_SetVideoMode(calcwidth, calcheight, 16, 0);
    if (screen == NULL) {
	printf("Unable to set video mode: %s\n", SDL_GetError());
	return 1;
    }

    SDL_LockSurface(screen);
    raw_pixels = (Uint16 *) screen->pixels;

    for (x = 0; x < calcwidth; x++) {
	for (y = 0; y < calcheight; y++) {
	    Uint16 pixel_color;
	    int offset;
	    if(x >= borderwidth) {
	    	if(scaled_template[(x - borderwidth)] == 'X') { pixel_color = CreateHicolorPixel(screen->format, 0, 0, 0); }
	    	else { pixel_color = CreateHicolorPixel(screen->format, 255, 255, 255); }
	    }
	    else pixel_color = CreateHicolorPixel(screen->format, 255, 255, 255);
	    offset = (screen->pitch / 2 * y + x);
	    raw_pixels[offset] = pixel_color;
	}
    }

    SDL_UnlockSurface(screen);
    SDL_UpdateRect(screen, 0, 0, 0, 0);

	while (SDL_WaitEvent(&event) != 0)
	{
		if(event.type == SDL_QUIT) exit(0);
	}

    return 0;

}
