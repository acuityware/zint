/* codex.c - Handles Code 11, 25, 39, 39+, 93 and 128 */
/* (Does not require Tony Robinson!) */

/*  Zebar - A barcode generating program using SDL
    Copyright (C) 2006 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <stdio.h>

void concat(char dest[], char source[]);
int ctoi(char source);
int itoc(int source);


/* *********************** CODE 11 ******************** */

void code_11_draw(char source, char dest[])
{ /* Table of Code 11 glyphs */

	switch(source)
	{
		case '0': concat (dest, "111121"); break;
		case '1': concat (dest, "211121"); break;
		case '2': concat (dest, "121121"); break;
		case '3': concat (dest, "221111"); break;
		case '4': concat (dest, "112121"); break;
		case '5': concat (dest, "212111"); break;
		case '6': concat (dest, "122111"); break;
		case '7': concat (dest, "111221"); break;
		case '8': concat (dest, "211211"); break;
		case '9': concat (dest, "211111"); break;
		case '-': concat (dest, "112111"); break;
	}
}

void code_11(char source[], char dest[])
{ /* Code 11 */

	unsigned int i;
	int h, c_digit, c_weight, c_count, k_digit, k_weight, k_count;
	int weight[1000];

	c_weight = 1;
	c_count = 0;
	k_weight = 1;
	k_count = 0;

	/* start character */
	concat (dest, "112211");

	/* Draw main body of barcode */
	for(i = 0; i < strlen(source); i++)
	{
		code_11_draw(source[i], dest);
		weight[i] = ctoi(source[i]);
	}

	/* Calculate C checksum */
	for(h = (strlen(source) - 1); h >= 0; h--)
	{
		c_count += (c_weight * weight[h]);
		c_weight++;

		if(c_weight > 10)
		{
			c_weight = 1;
		}
	}
	c_digit = c_count%11;

	/* Draw C checksum */
	code_11_draw(itoc(c_digit), dest);
	weight[strlen(source)] = c_digit;

	/* Calculate K checksum */
	for(h = strlen(source); h >= 0; h--)
	{
		k_count += (k_weight * weight[h]);
		k_weight++;

		if(k_weight > 9)
		{
			k_weight = 1;
		}
	}
	k_digit = k_count%11;

	/* Draw K checksum */
	code_11_draw(itoc(k_digit), dest);

	/* Stop character */
	concat (dest, "11221");
}


/* **************** CODE 2 OF 5 ********************** */

void code_two_of_five(char source[], char dest[])
{ /* Non interlaced Code 2 of 5 */

	unsigned int i;

	/* start character */
	concat (dest, "212111");

	for(i = 0; i <= strlen(source); i++)
	{
		switch(source[i])
		{
			case '0': concat (dest, "1111212111"); break;
			case '1': concat (dest, "2111111121"); break;
			case '2': concat (dest, "1121111121"); break;
			case '3': concat (dest, "2121111111"); break;
			case '4': concat (dest, "1111211121"); break;
			case '5': concat (dest, "2111211111"); break;
			case '6': concat (dest, "1121211111"); break;
			case '7': concat (dest, "1111112121"); break;
			case '8': concat (dest, "2111112111"); break;
			case '9': concat (dest, "1121112111"); break;
		}
	}

	/* Stop character */
	concat (dest, "21112");
}


/* *************** CODE 39 ********************** */

void c39(char source[], char dest[])
{ /* The Code 39 barcode system consisting of a simple substitution cipher */
	unsigned int i;

	printf("zebar: Drawing Code 39 \"%s\"\n", source);

	/* Start character */
	concat(dest, "1211212111");

	for(i = 0; i <= strlen(source); i++)
	{

		switch(source[i])
		{
			case '1': concat (dest, "2112111121"); break;
			case '2': concat (dest, "1122111121"); break;
			case '3': concat (dest, "2122111111"); break;
			case '4': concat (dest, "1112211121"); break;
			case '5': concat (dest, "2112211111"); break;
			case '6': concat (dest, "1122211111"); break;
			case '7': concat (dest, "1112112121"); break;
			case '8': concat (dest, "2112112111"); break;
			case '9': concat (dest, "1122112111"); break;
			case '0': concat (dest, "1112212111"); break;
			case 'A': concat (dest, "2111121121"); break;
			case 'B': concat (dest, "1121121121"); break;
			case 'C': concat (dest, "2121121111"); break;
			case 'D': concat (dest, "1111221121"); break;
			case 'E': concat (dest, "2111221111"); break;
			case 'F': concat (dest, "1121221111"); break;
			case 'G': concat (dest, "1111122121"); break;
			case 'H': concat (dest, "2111122111"); break;
			case 'I': concat (dest, "1121122111"); break;
			case 'J': concat (dest, "1111222111"); break;
			case 'K': concat (dest, "2111111221"); break;
			case 'L': concat (dest, "1121111221"); break;
			case 'M': concat (dest, "2121111211"); break;
			case 'N': concat (dest, "1111211221"); break;
			case 'O': concat (dest, "2111211211"); break;
			case 'P': concat (dest, "1121211211"); break;
			case 'Q': concat (dest, "1111112221"); break;
			case 'R': concat (dest, "2111112211"); break;
			case 'S': concat (dest, "1121112211"); break;
			case 'T': concat (dest, "1111212211"); break;
			case 'U': concat (dest, "2211111121"); break;
			case 'V': concat (dest, "1221111121"); break;
			case 'W': concat (dest, "2221111111"); break;
			case 'X': concat (dest, "1211211121"); break;
			case 'Y': concat (dest, "2211211111"); break;
			case 'Z': concat (dest, "1221211111"); break;
			case '-': concat (dest, "1211112121"); break;
			case '.': concat (dest, "2211112111"); break;
			case ' ': concat (dest, "1221112111"); break;
			case '$': concat (dest, "1212121111"); break;
			case '/': concat (dest, "1212111211"); break;
			case '+': concat (dest, "1211121211"); break;
			case '%': concat (dest, "1112121211"); break;
			}
		}


	/* Stop character */
	concat (dest, "121121211");
}


/* ************** EXTENDED CODE 39 *************** */

void ec39(char source[], char dest[])
{ /* An extension to the Code 39 system which supports extra characters including lower case */
	char buffer[200];
	unsigned int i, j;

	i = 0;
	j = 0;

	/* Creates a buffer string and places the ciphered 'extra' characters into it */

	while(j < strlen(source))
	{
		switch(source[j])
		{
			/* case '\0':  Null > %U */
			/* This is also the string terminator, so can't be implemented */
			/*	buffer[i] = '%';
				buffer[i + 1] = 'U';
				i += 2;
				break; */
			case 1: /* Start of Heading > $A */
				buffer[i] = '$';
				buffer[i + 1] = 'A';
				i += 2;
				break;
			case 2: /* Start of Text > $B */
				buffer[i] = '$';
				buffer[i + 1] = 'B';
				i += 2;
				break;
			case 3: /* End of Text > $C*/
				buffer[i] = '$';
				buffer[i + 1] = 'C';
				i += 2;
				break;
			case 4: /* End of Transmission > $D */
				buffer[i] = '$';
				buffer[i + 1] = 'D';
				i += 2;
				break;
			case 5: /* Enquiry > $E */
				buffer[i] = '$';
				buffer[i + 1] = 'E';
				i += 2;
				break;
			case 6: /* Acknowledge > $F */
				buffer[i] = '$';
				buffer[i + 1] = 'F';
				i += 2;
				break;
			case 7: /* Bell > $G */
				buffer[i] = '$';
				buffer[i + 1] = 'G';
				i += 2;
				break;
			case '\b': /* Backspace > $H */
				buffer[i] = '$';
				buffer[i + 1] = 'H';
				i += 2;
				break;
			case '\t': /* Horizontal Tab > $I */
				buffer[i] = '$';
				buffer[i + 1] = 'I';
				i += 2;
				break;
			case '\n': /* Line Feed > $J */
				buffer[i] = '$';
				buffer[i + 1] = 'J';
				i += 2;
				break;
			case '\v': /* Vertical Tab > $K */
				buffer[i] = '$';
				buffer[i + 1] = 'K';
				i += 2;
				break;
			case '\f': /* Form Feed > $L */
				buffer[i] = '$';
				buffer[i + 1] = 'L';
				i += 2;
				break;
			case '\r': /* Carriage Return > $M */
				buffer[i] = '$';
				buffer[i + 1] = 'M';
				i += 2;
				break;
			case 14: /* Shift Out > $N */
				buffer[i] = '$';
				buffer[i + 1] = 'N';
				i += 2;
				break;
			case 15: /* Shift In > $O */
				buffer[i] = '$';
				buffer[i + 1] = 'O';
				i += 2;
				break;
			case 16: /* Data Link Escape > $P */
				buffer[i] = '$';
				buffer[i + 1] = 'P';
				i += 2;
				break;
			case 17: /* Device Control 1 > $Q */
				buffer[i] = '$';
				buffer[i + 1] = 'Q';
				i += 2;
				break;
			case 18: /* Device Control 2 > $R */
				buffer[i] = '$';
				buffer[i + 1] = 'R';
				i += 2;
				break;
			case 19: /* Device Control 3 > $S */
				buffer[i] = '$';
				buffer[i + 1] = 'S';
				i += 2;
				break;
			case 20: /* Device Control 4 > $T */
				buffer[i] = '$';
				buffer[i + 1] = 'T';
				i += 2;
				break;
			case 21: /* Negative Acknowledge > $U */
				buffer[i] = '$';
				buffer[i + 1] = 'U';
				i += 2;
				break;
			case 22: /* Synchronous Idle > $V */
				buffer[i] = '$';
				buffer[i + 1] = 'V';
				i += 2;
				break;
			case 23: /* End of Transmission Block > $W */
				buffer[i] = '$';
				buffer[i + 1] = 'W';
				i += 2;
				break;
			case 24: /* Cancel > $X */
				buffer[i] = '$';
				buffer[i + 1] = 'X';
				i += 2;
				break;
			case 25: /* End of Medium > $Y */
				buffer[i] = '$';
				buffer[i + 1] = 'Y';
				i += 2;
				break;
			case 26: /* Substitute > $Z */
				buffer[i] = '$';
				buffer[i + 1] = 'Z';
				i += 2;
				break;
			case 27: /* Escape > %A */
				buffer[i] = '%';
				buffer[i + 1] = 'A';
				i += 2;
				break;
			case 28: /* File Separator > %B */
				buffer[i] = '%';
				buffer[i + 1] = 'B';
				i += 2;
				break;
			case 29: /* Group Separator > %C */
				buffer[i] = '%';
				buffer[i + 1] = 'C';
				i += 2;
				break;
			case 30: /* Record Separator > %D */
				buffer[i] = '%';
				buffer[i + 1] = 'D';
				i += 2;
				break;
			case 31: /* Unit Separator > %E */
				buffer[i] = '%';
				buffer[i + 1] = 'E';
				i += 2;
				break;
			case '!': /* exclamation > /A */
				buffer[i] = '/';
				buffer[i + 1] = 'A';
				i += 2;
				break;
			case '\"': /* double quote > /B */
				buffer[i] = '/';
				buffer[i + 1] = 'B';
				i += 2;
				break;
			case '#': /* hash > /C */
				buffer[i] = '/';
				buffer[i + 1] = 'C';
				i += 2;
				break;
			case '$': /* dollar > /D */
				buffer[i] = '/';
				buffer[i + 1] = 'D';
				i += 2;
				break;
			case '%': /* percent > /E */
				buffer[i] = '/';
				buffer[i + 1] = 'E';
				i += 2;
				break;
			case '&': /* ampusand > /F */
				buffer[i] = '/';
				buffer[i + 1] = 'F';
				i += 2;
				break;
			case '\'': /* single quote > /G */
				buffer[i] = '/';
				buffer[i + 1] = 'G';
				i += 2;
				break;
			case '(': /* open bracket > /H */
				buffer[i] = '/';
				buffer[i + 1] = 'H';
				i += 2;
				break;
			case ')': /* close bracket > /I */
				buffer[i] = '/';
				buffer[i + 1] = 'I';
				i += 2;
				break;
			case '*': /* asterisk > /J */
				buffer[i] = '/';
				buffer[i + 1] = 'J';
				i += 2;
				break;
			case '+': /* plus > /K */
				buffer[i] = '/';
				buffer[i + 1] = 'K';
				i += 2;
				break;
			case ',': /* comma > /L */
				buffer[i] = '/';
				buffer[i + 1] = 'L';
				i += 2;
				break;
			case '/': /* forward slash > /O */
				buffer[i] = '/';
				buffer[i + 1] = 'O';
				i += 2;
				break;
			case ':': /* colon > /Z */
				buffer[i] = '/';
				buffer[i + 1] = 'Z';
				i += 2;
				break;
			case ';': /* semi-colon > %F */
				buffer[i] = '%';
				buffer[i + 1] = 'F';
				i += 2;
				break;
			case '<': /* less than > %G */
				buffer[i] = '%';
				buffer[i + 1] = 'G';
				i += 2;
				break;
			case '=': /* equals > %H */
				buffer[i] = '%';
				buffer[i + 1] = 'H';
				i += 2;
				break;
			case '>': /* greater than > %I */
				buffer[i] = '%';
				buffer[i + 1] = 'I';
				i += 2;
				break;
			case '?': /* question mark > %J */
				buffer[i] = '%';
				buffer[i + 1] = 'J';
				i += 2;
				break;
			case '@': /* at > %V */
				buffer[i] = '%';
				buffer[i + 1] = 'V';
				i += 2;
				break;
			case '[': /* open square bracket > %K */
				buffer[i] = '%';
				buffer[i + 1] = 'K';
				i += 2;
				break;
			case '\\': /* backslash > %L */
				buffer[i] = '%';
				buffer[i + 1] = 'L';
				i += 2;
				break;
			case ']': /* close square bracket > %M */
				buffer[i] = '%';
				buffer[i + 1] = 'M';
				i += 2;
				break;
			case '^': /* caret > %N */
				buffer[i] = '%';
				buffer[i + 1] = 'N';
				i += 2;
				break;
			case '_': /* underscore > %O */
				buffer[i] = '%';
				buffer[i + 1] = 'O';
				i += 2;
				break;
			case '`': /* acute accent > %W */
				buffer[i] = '%';
				buffer[i + 1] = 'W';
				i += 2;
				break;
			case 'a': /* lower A > +A */
				buffer[i] = '+';
				buffer[i + 1] = 'A';
				i += 2;
				break;
			case 'b': /* lower B > +B */
				buffer[i] = '+';
				buffer[i + 1] = 'B';
				i += 2;
				break;
			case 'c': /* lower C > +C */
				buffer[i] = '+';
				buffer[i + 1] = 'C';
				i += 2;
				break;
			case 'd': /* lower D > +D */
				buffer[i] = '+';
				buffer[i + 1] = 'D';
				i += 2;
				break;
			case 'e': /* lower E > +E */
				buffer[i] = '+';
				buffer[i + 1] = 'E';
				i += 2;
				break;
			case 'f': /* lower F > +F */
				buffer[i] = '+';
				buffer[i + 1] = 'F';
				i += 2;
				break;
			case 'g': /* lower G > +G */
				buffer[i] = '+';
				buffer[i + 1] = 'G';
				i += 2;
				break;
			case 'h': /* lower H > +H */
				buffer[i] = '+';
				buffer[i + 1] = 'H';
				i += 2;
				break;
			case 'i': /* lower I > +I */
				buffer[i] = '+';
				buffer[i + 1] = 'I';
				i += 2;
				break;
			case 'j': /* lower J > +J */
				buffer[i] = '+';
				buffer[i + 1] = 'J';
				i += 2;
				break;
			case 'k': /* lower K > +K */
				buffer[i] = '+';
				buffer[i + 1] = 'K';
				i += 2;
				break;
			case 'l': /* lower L > +L */
				buffer[i] = '+';
				buffer[i + 1] = 'L';
				i += 2;
				break;
			case 'm': /* lower M > +M */
				buffer[i] = '+';
				buffer[i + 1] = 'M';
				i += 2;
				break;
			case 'n': /* lower N > +N */
				buffer[i] = '+';
				buffer[i + 1] = 'N';
				i += 2;
				break;
			case 'o': /* lower O > +O */
				buffer[i] = '+';
				buffer[i + 1] = 'O';
				i += 2;
				break;
			case 'p': /* lower P > +P */
				buffer[i] = '+';
				buffer[i + 1] = 'P';
				i += 2;
				break;
			case 'q': /* lower Q > +Q */
				buffer[i] = '+';
				buffer[i + 1] = 'Q';
				i += 2;
				break;
			case 'r': /* lower R > +R */
				buffer[i] = '+';
				buffer[i + 1] = 'R';
				i += 2;
				break;
			case 's': /* lower S > +S */
				buffer[i] = '+';
				buffer[i + 1] = 'S';
				i += 2;
				break;
			case 't': /* lower T > +T */
				buffer[i] = '+';
				buffer[i + 1] = 'T';
				i += 2;
				break;
			case 'u': /* lower U > +U */
				buffer[i] = '+';
				buffer[i + 1] = 'U';
				i += 2;
				break;
			case 'v': /* lower V > +V */
				buffer[i] = '+';
				buffer[i + 1] = 'V';
				i += 2;
				break;
			case 'w': /* lower W > +W */
				buffer[i] = '+';
				buffer[i + 1] = 'W';
				i += 2;
				break;
			case 'x': /* lower X > +X */
				buffer[i] = '+';
				buffer[i + 1] = 'X';
				i += 2;
				break;
			case 'y': /* lower Y > +Y */
				buffer[i] = '+';
				buffer[i + 1] = 'Y';
				i += 2;
				break;
			case 'z': /* lower Z > +Z */
				buffer[i] = '+';
				buffer[i + 1] = 'Z';
				i += 2;
				break;
			case '{': /* open curly bracket > %P */
				buffer[i] = '%';
				buffer[i + 1] = 'P';
				i += 2;
				break;
			case '|': /* bar > %Q */
				buffer[i] = '%';
				buffer[i + 1] = 'Q';
				i += 2;
				break;
			case '}': /* close curly bracket > %R */
				buffer[i] = '%';
				buffer[i + 1] = 'R';
				i += 2;
				break;
			case '~': /* tilde > %S */
				buffer[i] = '%';
				buffer[i + 1] = 'S';
				i += 2;
				break;
			case 127: /* Delete > %T */
				buffer[i] = '%';
				buffer[i + 1] = 'T';
				i += 2;
				break;
			default: /* Anything else goes unaltered */
				buffer[i] = source[j];
				i++;
				break;
		}
		j++;
	}
	buffer[i] = '\0';

	/* Then sends the buffer to the C39 function */
	c39(source, dest);
}


/* ******************** CODE 93 ******************* */

void c93_char(char source, char dest[], int values[], int *bar_chars)
{ /* Translate characters into bar patterns */

	switch(source)
	{
		case '0': concat (dest, "131112");
			values[(*bar_chars)] = 0; (*bar_chars)++; break;
		case '1': concat (dest, "111213");
			values[(*bar_chars)] = 1; (*bar_chars)++; break;
		case '2': concat (dest, "111312");
			values[(*bar_chars)] = 2; (*bar_chars)++; break;
		case '3': concat (dest, "111411");
			values[(*bar_chars)] = 3; (*bar_chars)++; break;
		case '4': concat (dest, "121113");
			values[(*bar_chars)] = 4; (*bar_chars)++; break;
		case '5': concat (dest, "121212");
			values[(*bar_chars)] = 5; (*bar_chars)++; break;
		case '6': concat (dest, "121311");
			values[(*bar_chars)] = 6; (*bar_chars)++; break;
		case '7': concat (dest, "111114");
			values[(*bar_chars)] = 7; (*bar_chars)++; break;
		case '8': concat (dest, "131211");
			values[(*bar_chars)] = 8; (*bar_chars)++; break;
		case '9': concat (dest, "141111");
 			values[(*bar_chars)] = 9; (*bar_chars)++; break;
		case 'A': concat (dest, "211113");
			values[(*bar_chars)] = 10; (*bar_chars)++; break;
		case 'B': concat (dest, "211212");
			values[(*bar_chars)] = 11; (*bar_chars)++; break;
		case 'C': concat (dest, "211311");
			values[(*bar_chars)] = 12; (*bar_chars)++; break;
		case 'D': concat (dest, "221112");
 			values[(*bar_chars)] = 13; (*bar_chars)++; break;
		case 'E': concat (dest, "221211");
			values[(*bar_chars)] = 14; (*bar_chars)++; break;
		case 'F': concat (dest, "231111");
			values[(*bar_chars)] = 15; (*bar_chars)++; break;
		case 'G': concat (dest, "112113");
			values[(*bar_chars)] = 16; (*bar_chars)++; break;
		case 'H': concat (dest, "112212");
			values[(*bar_chars)] = 17; (*bar_chars)++; break;
		case 'I': concat (dest, "112311");
			values[(*bar_chars)] = 18; (*bar_chars)++; break;
		case 'J': concat (dest, "122112");
			values[(*bar_chars)] = 19; (*bar_chars)++; break;
		case 'K': concat (dest, "132111");
			values[(*bar_chars)] = 20; (*bar_chars)++; break;
		case 'L': concat (dest, "111123");
			values[(*bar_chars)] = 21; (*bar_chars)++; break;
		case 'M': concat (dest, "111222");
			values[(*bar_chars)] = 22; (*bar_chars)++; break;
		case 'N': concat (dest, "111321");
			values[(*bar_chars)] = 23; (*bar_chars)++; break;
		case 'O': concat (dest, "121122");
			values[(*bar_chars)] = 24; (*bar_chars)++; break;
		case 'P': concat (dest, "131121");
			values[(*bar_chars)] = 25; (*bar_chars)++; break;
		case 'Q': concat (dest, "212112");
			values[(*bar_chars)] = 26; (*bar_chars)++; break;
		case 'R': concat (dest, "212211");
			values[(*bar_chars)] = 27; (*bar_chars)++; break;
		case 'S': concat (dest, "211122");
			values[(*bar_chars)] = 28; (*bar_chars)++; break;
		case 'T': concat (dest, "211221");
			values[(*bar_chars)] = 29; (*bar_chars)++; break;
		case 'U': concat (dest, "221121");
			values[(*bar_chars)] = 30; (*bar_chars)++; break;
		case 'V': concat (dest, "222111");
			values[(*bar_chars)] = 31; (*bar_chars)++; break;
		case 'W': concat (dest, "112122");
			values[(*bar_chars)] = 32; (*bar_chars)++; break;
		case 'X': concat (dest, "112221");
			values[(*bar_chars)] = 33; (*bar_chars)++; break;
		case 'Y': concat (dest, "122121");
			values[(*bar_chars)] = 34; (*bar_chars)++; break;
		case 'Z': concat (dest, "123111");
			values[(*bar_chars)] = 35; (*bar_chars)++; break;
		case '-': concat (dest, "121131");
			values[(*bar_chars)] = 36; (*bar_chars)++; break;
		case '.': concat (dest, "311112");
			values[(*bar_chars)] = 37; (*bar_chars)++; break;
		case ' ': concat (dest, "311211");
			values[(*bar_chars)] = 38; (*bar_chars)++; break;
		case '$': concat (dest, "321111");
			values[(*bar_chars)] = 39; (*bar_chars)++; break;
		case '/': concat (dest, "112131");
			values[(*bar_chars)] = 40; (*bar_chars)++; break;
		case '+': concat (dest, "113121");
			values[(*bar_chars)] = 41; (*bar_chars)++; break;
		case '%': concat (dest, "211131");
			values[(*bar_chars)] = 42; (*bar_chars)++; break;
	}
}

void c93_shift(int shift, char dest[], int *values, int *bar_chars)
{ /* Translate shift characters into bar patterns */
	switch(shift)
	{
		case 1: concat (dest, "121221");
			values[(*bar_chars)] = 43; (*bar_chars)++; break;
		case 2: concat (dest, "312111");
			values[(*bar_chars)] = 44; (*bar_chars)++; break;
		case 3: concat (dest, "311121");
			values[(*bar_chars)] = 45; (*bar_chars)++; break;
		case 4: concat (dest, "122211");
			values[(*bar_chars)] = 46; (*bar_chars)++; break;
	}
}

void c93_check(int symbol, char dest[], int *values, int *bar_characters)
{
	switch(symbol)
	{
		case 0: c93_char('0', dest, values, bar_characters); printf("0"); break;
		case 1: c93_char('1', dest, values, bar_characters); printf("1"); break;
		case 2: c93_char('2', dest, values, bar_characters); printf("2"); break;
		case 3: c93_char('3', dest, values, bar_characters); printf("3"); break;
		case 4: c93_char('4', dest, values, bar_characters); printf("4"); break;
		case 5: c93_char('5', dest, values, bar_characters); printf("5"); break;
		case 6: c93_char('6', dest, values, bar_characters); printf("6"); break;
		case 7: c93_char('7', dest, values, bar_characters); printf("7"); break;
		case 8: c93_char('8', dest, values, bar_characters); printf("8"); break;
		case 9: c93_char('9', dest, values, bar_characters); printf("9"); break;
		case 10: c93_char('A', dest, values, bar_characters); printf("A"); break;
		case 11: c93_char('B', dest, values, bar_characters); printf("B"); break;
		case 12: c93_char('C', dest, values, bar_characters); printf("C"); break;
		case 13: c93_char('D', dest, values, bar_characters); printf("D"); break;
		case 14: c93_char('E', dest, values, bar_characters); printf("E"); break;
		case 15: c93_char('F', dest, values, bar_characters); printf("F"); break;
		case 16: c93_char('G', dest, values, bar_characters); printf("G"); break;
		case 17: c93_char('H', dest, values, bar_characters); printf("H"); break;
		case 18: c93_char('I', dest, values, bar_characters); printf("I"); break;
		case 19: c93_char('J', dest, values, bar_characters); printf("J"); break;
		case 20: c93_char('K', dest, values, bar_characters); printf("K"); break;
		case 21: c93_char('L', dest, values, bar_characters); printf("L"); break;
		case 22: c93_char('M', dest, values, bar_characters); printf("M"); break;
		case 23: c93_char('N', dest, values, bar_characters); printf("N"); break;
		case 24: c93_char('O', dest, values, bar_characters); printf("O"); break;
		case 25: c93_char('P', dest, values, bar_characters); printf("P"); break;
		case 26: c93_char('Q', dest, values, bar_characters); printf("Q"); break;
		case 27: c93_char('R', dest, values, bar_characters); printf("R"); break;
		case 28: c93_char('S', dest, values, bar_characters); printf("S"); break;
		case 29: c93_char('T', dest, values, bar_characters); printf("T"); break;
		case 30: c93_char('U', dest, values, bar_characters); printf("U"); break;
		case 31: c93_char('V', dest, values, bar_characters); printf("V"); break;
		case 32: c93_char('W', dest, values, bar_characters); printf("W"); break;
		case 33: c93_char('X', dest, values, bar_characters); printf("X"); break;
		case 34: c93_char('Y', dest, values, bar_characters); printf("Y"); break;
		case 35: c93_char('Z', dest, values, bar_characters); printf("Z"); break;
		case 36: c93_char('-', dest, values, bar_characters); printf("-"); break;
		case 37: c93_char('.', dest, values, bar_characters); printf("."); break;
		case 38: c93_char(' ', dest, values, bar_characters); printf("_"); break;
		case 39: c93_char('$', dest, values, bar_characters); printf("$"); break;
		case 40: c93_char('/', dest, values, bar_characters); printf("/"); break;
		case 41: c93_char('+', dest, values, bar_characters); printf("+"); break;
		case 42: c93_char('%', dest, values, bar_characters); printf("%%"); break;
		case 43: c93_shift(1, dest, values, bar_characters); printf("~1"); break;
		case 44: c93_shift(2, dest, values, bar_characters); printf("~2"); break;
		case 45: c93_shift(3, dest, values, bar_characters); printf("~3"); break;
		case 46: c93_shift(4, dest, values, bar_characters); printf("~4"); break;
	}
}

void c93(char source[], char dest[])
{ /* Code 93 is an advancement on Code 39+ */
	unsigned int i;
	int h, weight, c, k, values[200], bar_characters;

	/* Start character */
	concat(dest, "111141");
	bar_characters = 0;

	/* Message Content */
	for(i = 0; i < strlen(source); i++)
	{
		switch(source[i])
		{
		/*	case '\0': NUL - Can't be used with string input
				c93_shift(2, dest, values, &bar_characters);
				c93_char('U', dest, values, &bar_characters);
				break; */
			case 1: /* SOH */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('A', dest, values, &bar_characters);
				break;
			case 2: /* STX */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('B', dest, values, &bar_characters);
				break;
			case 3: /* ETX */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('C', dest, values, &bar_characters);
				break;
			case 4: /* EOT */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('D', dest, values, &bar_characters);
				break;
			case 5: /* ENQ */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('E', dest, values, &bar_characters);
				break;
			case 6: /* ACK */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('F', dest, values, &bar_characters);
				break;
			case 7: /* BEL */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('G', dest, values, &bar_characters);
				break;
			case 8: /* BS */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('H', dest, values, &bar_characters);
				break;
			case 9: /* HT */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('I', dest, values, &bar_characters);
				break;
			case 10: /* LF */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('J', dest, values, &bar_characters);
				break;
			case 11: /* VT */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('K', dest, values, &bar_characters);
				break;
			case 12: /* FF */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('L', dest, values, &bar_characters);
				break;
			case 13: /* CR */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('M', dest, values, &bar_characters);
				break;
			case 14: /* SO */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('N', dest, values, &bar_characters);
				break;
			case 15: /* SI */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('O', dest, values, &bar_characters);
				break;
			case 16: /* DLE */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('P', dest, values, &bar_characters);
				break;
			case 17: /* DC1 */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('Q', dest, values, &bar_characters);
				break;
			case 18: /* DC2 */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('R', dest, values, &bar_characters);
				break;
			case 19: /* DC3 */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('S', dest, values, &bar_characters);
				break;
			case 20: /* DC4 */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('T', dest, values, &bar_characters);
				break;
			case 21: /* NAK */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('U', dest, values, &bar_characters);
				break;
			case 22: /* SYN */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('V', dest, values, &bar_characters);
				break;
			case 23: /* ETB */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('W', dest, values, &bar_characters);
				break;
			case 24: /* CAN */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('X', dest, values, &bar_characters);
				break;
			case 25: /* EM */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('Y', dest, values, &bar_characters);
				break;
			case 26: /* SUB */
				c93_shift(1, dest, values, &bar_characters);
				c93_char('Z', dest, values, &bar_characters);
				break;
			case 27: /* ESC */
				c93_shift(2, dest, values, &bar_characters);
				c93_char('A', dest, values, &bar_characters);
				break;
			case 28: /* FS */
				c93_shift(2, dest, values, &bar_characters);
				c93_char('B', dest, values, &bar_characters);
				break;
			case 29: /* GS */
				c93_shift(2, dest, values, &bar_characters);
				c93_char('C', dest, values, &bar_characters);
				break;
			case 30: /* RS */
				c93_shift(2, dest, values, &bar_characters);
				c93_char('D', dest, values, &bar_characters);
				break;
			case 31: /* US */
				c93_shift(2, dest, values, &bar_characters);
				c93_char('E', dest, values, &bar_characters);
				break;
			case '!':
				c93_shift(3, dest, values, &bar_characters);
				c93_char('A', dest, values, &bar_characters);
				break;
			case '"':
				c93_shift(3, dest, values, &bar_characters);
				c93_char('B', dest, values, &bar_characters);
				break;
			case '#':
				c93_shift(3, dest, values, &bar_characters);
				c93_char('C', dest, values, &bar_characters);
				break;
			case '&':
				c93_shift(3, dest, values, &bar_characters);
				c93_char('F', dest, values, &bar_characters);
				break;
			case '\'':
				c93_shift(3, dest, values, &bar_characters);
				c93_char('G', dest, values, &bar_characters);
				break;
			case '(':
				c93_shift(3, dest, values, &bar_characters);
				c93_char('H', dest, values, &bar_characters);
				break;
			case ')':
				c93_shift(3, dest, values, &bar_characters);
				c93_char('I', dest, values, &bar_characters);
				break;
			case '*':
				c93_shift(3, dest, values, &bar_characters);
				c93_char('J', dest, values, &bar_characters);
				break;
			case ',':
				c93_shift(3, dest, values, &bar_characters);
				c93_char('L', dest, values, &bar_characters);
				break;
			case ':':
				c93_shift(3, dest, values, &bar_characters);
				c93_char('Z', dest, values, &bar_characters);
				break;
			case ';':
				c93_shift(2, dest, values, &bar_characters);
				c93_char('F', dest, values, &bar_characters);
				break;
			case '<':
				c93_shift(2, dest, values, &bar_characters);
				c93_char('G', dest, values, &bar_characters);
				break;
			case '=':
				c93_shift(2, dest, values, &bar_characters);
				c93_char('H', dest, values, &bar_characters);
				break;
			case '>':
				c93_shift(2, dest, values, &bar_characters);
				c93_char('I', dest, values, &bar_characters);
				break;
			case '?':
				c93_shift(2, dest, values, &bar_characters);
				c93_char('J', dest, values, &bar_characters);
				break;
			case '@':
				c93_shift(2, dest, values, &bar_characters);
				c93_char('V', dest, values, &bar_characters);
				break;
			case '[':
				c93_shift(2, dest, values, &bar_characters);
				c93_char('K', dest, values, &bar_characters);
				break;
			case '\\':
				c93_shift(2, dest, values, &bar_characters);
				c93_char('L', dest, values, &bar_characters);
				break;
			case ']':
				c93_shift(2, dest, values, &bar_characters);
				c93_char('M', dest, values, &bar_characters);
				break;
			case '^':
				c93_shift(2, dest, values, &bar_characters);
				c93_char('N', dest, values, &bar_characters);
				break;
			case '_':
				c93_shift(2, dest, values, &bar_characters);
				c93_char('O', dest, values, &bar_characters);
				break;
			case '`':
				c93_shift(2, dest, values, &bar_characters);
				c93_char('W', dest, values, &bar_characters);
				break;
			case 'a':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('A', dest, values, &bar_characters);
				break;
			case 'b':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('B', dest, values, &bar_characters);
				break;
			case 'c':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('C', dest, values, &bar_characters);
				break;
			case 'd':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('D', dest, values, &bar_characters);
				break;
			case 'e':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('E', dest, values, &bar_characters);
				break;
			case 'f':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('F', dest, values, &bar_characters);
				break;
			case 'g':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('G', dest, values, &bar_characters);
				break;
			case 'h':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('H', dest, values, &bar_characters);
				break;
			case 'i':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('I', dest, values, &bar_characters);
				break;
			case 'j':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('J', dest, values, &bar_characters);
				break;
			case 'k':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('K', dest, values, &bar_characters);
				break;
			case 'l':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('L', dest, values, &bar_characters);
				break;
			case 'm':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('M', dest, values, &bar_characters);
				break;
			case 'n':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('N', dest, values, &bar_characters);
				break;
			case 'o':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('O', dest, values, &bar_characters);
				break;
			case 'p':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('P', dest, values, &bar_characters);
				break;
			case 'q':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('Q', dest, values, &bar_characters);
				break;
			case 'r':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('R', dest, values, &bar_characters);
				break;
			case 's':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('S', dest, values, &bar_characters);
				break;
			case 't':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('T', dest, values, &bar_characters);
				break;
			case 'u':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('U', dest, values, &bar_characters);
				break;
			case 'v':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('V', dest, values, &bar_characters);
				break;
			case 'w':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('W', dest, values, &bar_characters);
				break;
			case 'x':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('X', dest, values, &bar_characters);
				break;
			case 'y':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('Y', dest, values, &bar_characters);
				break;
			case 'z':
				c93_shift(4, dest, values, &bar_characters);
				c93_char('Z', dest, values, &bar_characters);
				break;
			case '{':
				c93_shift(2, dest, values, &bar_characters);
				c93_char('P', dest, values, &bar_characters);
				break;
			case '|':
				c93_shift(2, dest, values, &bar_characters);
				c93_char('Q', dest, values, &bar_characters);
				break;
			case '}':
				c93_shift(2, dest, values, &bar_characters);
				c93_char('R', dest, values, &bar_characters);
				break;
			case '~':
				c93_shift(2, dest, values, &bar_characters);
				c93_char('S', dest, values, &bar_characters);
				break;
			case 127:
				c93_shift(2, dest, values, &bar_characters);
				c93_char('T', dest, values, &bar_characters);
				break;
			default:
				c93_char(source[i], dest, values, &bar_characters);
				break;
		}
	}

	/* Check digit C */

	printf("zebar: Drawing Code 93 with check digits \""); /* Characters output from c93_check */

	c = 0;
	weight = 1;
	for(h = bar_characters - 1; h >= 0; h--)
	{
		c += values[h] * weight;
		weight ++;
		if(weight == 21)
		{
			weight = 1;
		}
	}
	c = c % 47;
	c93_check(c, dest, values, &bar_characters);

	/* Check digit K */

	k = 0;
	weight = 1;
	for(h = bar_characters - 1; h >= 0; h--)
	{
		k += values[h] * weight;
		weight ++;
		if(weight == 16)
		{
			weight = 1;
		}
	}
	k = k % 47;
	c93_check(k, dest, values, &bar_characters);

	printf("\"\n");

	/* Stop character */
	concat(dest, "1111411");
}


/* ******************* CODE 128 ********************** */

void c128_draw(int glyph, char dest[])
{
	switch(glyph)

	{
		case 0: concat(dest, "212222"); break;
		case 1: concat(dest, "222122"); break;
		case 2: concat(dest, "222221"); break;
		case 3: concat(dest, "121223"); break;
		case 4: concat(dest, "121322"); break;
		case 5: concat(dest, "131222"); break;
		case 6: concat(dest, "122213"); break;
		case 7: concat(dest, "122312"); break;
		case 8: concat(dest, "132212"); break;
		case 9: concat(dest, "221213"); break;
		case 10: concat(dest, "221312"); break;
		case 11: concat(dest, "231212"); break;
		case 12: concat(dest, "112232"); break;
		case 13: concat(dest, "122312"); break;
		case 14: concat(dest, "122231"); break;
		case 15: concat(dest, "113222"); break;
		case 16: concat(dest, "123122"); break;
		case 17: concat(dest, "123221"); break;
		case 18: concat(dest, "223211"); break;
		case 19: concat(dest, "221132"); break;
		case 20: concat(dest, "221231"); break;
		case 21: concat(dest, "213212"); break;
		case 22: concat(dest, "223112"); break;
		case 23: concat(dest, "312131"); break;
		case 24: concat(dest, "311222"); break;
		case 25: concat(dest, "321122"); break;
		case 26: concat(dest, "321221"); break;
		case 27: concat(dest, "312212"); break;
		case 28: concat(dest, "322112"); break;
		case 29: concat(dest, "322211"); break;
		case 30: concat(dest, "212123"); break;
		case 31: concat(dest, "213321"); break;
		case 32: concat(dest, "232121"); break;
		case 33: concat(dest, "111323"); break;
		case 34: concat(dest, "131123"); break;
		case 35: concat(dest, "131321"); break;
		case 36: concat(dest, "112313"); break;
		case 37: concat(dest, "132113"); break;
		case 38: concat(dest, "132311"); break;
		case 39: concat(dest, "211313"); break;
		case 40: concat(dest, "231113"); break;
		case 41: concat(dest, "231311"); break;
		case 42: concat(dest, "112133"); break;
		case 43: concat(dest, "112331"); break;
		case 44: concat(dest, "132131"); break;
		case 45: concat(dest, "113123"); break;
		case 46: concat(dest, "113321"); break;
		case 47: concat(dest, "133121"); break;
		case 48: concat(dest, "313121"); break;
		case 49: concat(dest, "211331"); break;
		case 50: concat(dest, "231131"); break;
		case 51: concat(dest, "213113"); break;
		case 52: concat(dest, "213311"); break;
		case 53: concat(dest, "213131"); break;
		case 54: concat(dest, "311123"); break;
		case 55: concat(dest, "311321"); break;
		case 56: concat(dest, "331121"); break;
		case 57: concat(dest, "312113"); break;
		case 58: concat(dest, "312311"); break;
		case 59: concat(dest, "332111"); break;
		case 60: concat(dest, "314111"); break;
		case 61: concat(dest, "221411"); break;
		case 62: concat(dest, "431111"); break;
		case 63: concat(dest, "111224"); break;
		case 64: concat(dest, "111422"); break;
		case 65: concat(dest, "121124"); break;
		case 66: concat(dest, "121421"); break;
		case 67: concat(dest, "141122"); break;
		case 68: concat(dest, "141221"); break;
		case 69: concat(dest, "112214"); break;
		case 70: concat(dest, "112412"); break;
		case 71: concat(dest, "122114"); break;
		case 72: concat(dest, "122411"); break;
		case 73: concat(dest, "142112"); break;
		case 74: concat(dest, "142211"); break;
		case 75: concat(dest, "241211"); break;
		case 76: concat(dest, "221114"); break;
		case 77: concat(dest, "413111"); break;
		case 78: concat(dest, "241112"); break;
		case 79: concat(dest, "134111"); break;
		case 80: concat(dest, "111242"); break;
		case 81: concat(dest, "121142"); break;
		case 82: concat(dest, "121241"); break;
		case 83: concat(dest, "114212"); break;
		case 84: concat(dest, "124112"); break;
		case 85: concat(dest, "124211"); break;
		case 86: concat(dest, "411212"); break;
		case 87: concat(dest, "421112"); break;
		case 88: concat(dest, "421211"); break;
		case 89: concat(dest, "212141"); break;
		case 90: concat(dest, "214121"); break;
		case 91: concat(dest, "412121"); break;
		case 92: concat(dest, "111143"); break;
		case 93: concat(dest, "111341"); break;
		case 94: concat(dest, "131141"); break;
		case 95: concat(dest, "114113"); break;
		case 96: concat(dest, "114311"); break;
		case 97: concat(dest, "411113"); break;
		case 98: concat(dest, "411311"); break;
		case 99: concat(dest, "113141"); break;
		case 100: concat(dest, "114131"); break;
		case 101: concat(dest, "311141"); break;
		case 102: concat(dest, "411131"); break;
		case 103: concat(dest, "211412"); break;
		case 104: concat(dest, "211214"); break;
		case 105: concat(dest, "211232"); break;
		case 106: concat(dest, "2331112");break;
	}
}

void c128_set_a(char source, char dest[], unsigned int values[], unsigned int *bar_chars)
{ /* Translate Code 128 Set A characters into barcodes */
  /* This set handles all control characters NULL to US */

	c128_draw((source + 64), dest);
	values[(*bar_chars)] = source + 64;
	(*bar_chars)++;
}

void c128_set_b(char source, char dest[], unsigned int values[], unsigned int *bar_chars)
{ /* Translate Code 128 Set B characters into barcodes */
  /* This set handles all characters which are not part of long numbers and not control characters */

	c128_draw((source - 32), dest);
	values[(*bar_chars)] = source - 32;
	(*bar_chars)++;
}

void c128_set_c(char source_a, char source_b, char dest[], unsigned int values[], unsigned int *bar_chars)
{ /* Translate Code 128 Set C characters into barcodes */
  /* This set handles long numbers in a compressed form */
	int weight;

	weight = (10 * ctoi(source_a)) + ctoi(source_b);
	c128_draw(weight, dest);
	values[(*bar_chars)] = weight;
	(*bar_chars)++;
}

void c128(char source[], char dest[])
{ /* Handle Code 128 barcodes */
	unsigned int i, j, k, e_count, values[200], bar_characters, read, total_sum;
	char set[200];

	j = 0;
	e_count = 0;
	bar_characters = 0;

	/* First figure out what code sets to use - there are three: A, B, and C */
	for(i = 0; i < strlen(source); i++)
	{

	/* In the following I have made Zebar use code set B whenever there is a choice
	   between using A or B. Whilst this doesn't always ensure the shortest and neatest
	   barcode, I think that code A is likely to be needed so rarely that this shortcut
	   is justified: The vast majority of barcodes will only need to use sets B and C. */

		if(source[i] < 32) {
			/* Everthing from NULL to US must be code set A */
			set[i] = 'A';
			if((e_count % 2) == 1) {
				/* If there are an odd number of numbers (0-9), the last one
				   cannot be set C */
				set[i - 1] = 'A';
			}
			e_count = 0;
		}
		if((source[i] > 31) && (source[i] < 48)) {
			/* Everything from SPACE to / can be code set A or B  - Use B */
			set[i] = 'B';
			if((e_count % 2) == 1) {
				set[i - 1] = 'B';
			}
			e_count = 0;
		}
		if((source[i] > 47) && (source[i] < 58)) {
			/* Numbers from 0 to 9 can be code set A, B or C */
			e_count ++;
			if(e_count > 5) {
				/* If there are more than six of them they should be C */
				if(i != (strlen(source) - 1)) {
					for(k = 5; k > 0; k--) {
						set[i - k] = 'C';
					}
					set[i] = 'C';
				}
				else
				{
					/* Ah! But be careful if it's the last character */
					if((e_count % 2) == 1) {
						set[i] = 'B';
					}
					else
					{
						for(k = 5; k > 0; k--) {
							set[i - k] = 'C';
						}
						set[i] = 'C';
					}
				}
			}
			else
			{
				/* Otherwise they can be A or B  - Use B */
				set[i] = 'B';
			}
		}
		if(source[i] > 57) {
			/* Everything from : to _ can be code set A or B - Use B
			   Everything from ` to DELETE must be code set B */
			set[i] = 'B';
			if((e_count % 2) == 1) {
				set[i - 1] = 'B';
			}
			e_count = 0;
		}
	}
	set[i] = '\0';

	/* So now we know what start character to use */
	switch(set[0])
	{
		case 'A': /* Start A */
			c128_draw(103, dest);
			values[0] = 103;
			break;
		case 'B': /* Start B */
			c128_draw(104, dest);
			values[0] = 104;
			break;
		case 'C': /* Start C */
			c128_draw(105, dest);
			values[0] = 105;
			break;
	}
	bar_characters++;

	/* Deal with the gritty middle of the barcode ! */
	read = 0;
	do {

		if((read != 0) && (set[read] != set[read - 1]))
		{
			switch(set[read])
			{
				case 'A': c128_draw(101, dest);
					values[bar_characters] = 101;
					bar_characters++;
					break;
				case 'B': c128_draw(100, dest);
					values[bar_characters] = 100;
					bar_characters++;
					break;
				case 'C': c128_draw(99, dest);
					values[bar_characters] = 99;
					bar_characters++;
					break;
			}
		}

		switch(set[read])
		{
			case 'A': c128_set_a(source[read], dest, values, &bar_characters);
				read++;
				break;
			case 'B': c128_set_b(source[read], dest, values, &bar_characters);
				read++;
				break;
			case 'C': c128_set_c(source[read], source[read + 1], dest, values, &bar_characters);
				read += 2;
				break;
		}
	} while (read < strlen(source));

	/* Calculate check digit */
	total_sum = 0;
	for(i = 0; i < bar_characters; i++)
	{
		if(i > 0)
		{
			values[i] *= i;
		}
		total_sum += values[i];
	}

	/* Draw check digit */
	c128_draw((total_sum%103), dest);
	printf("Drawing Code 128 with check digit %d\n", total_sum%103);

	/* Stop character */
	c128_draw(106, dest);
}
