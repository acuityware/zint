/* ean.c - Handles EAN-2, 5, 8 and 13, UPC-A and E, SBN, ISBN and ISBN-13 */

/*  Zebar - A barcode generating program using SDL
    Copyright (C) 2006 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define	EAN2	2
#define	EAN5	5

void concat(char dest[], char source[]);
int ctoi(char source);
char itoc(int source);

/* ********************** EAN-2 AND EAN-5 **************** */

void add_on(char source[], char dest[], int mode)
{
	char parity[6];
	unsigned int i, code_type;

	/* If an add-on then append with space */
	if (mode != 0)
	{
		concat(dest, "9");
	}

	/* Start character */
	concat (dest, "112");

	/* Determine EAN2 or EAN5 add-on */
	if(strlen(source) == 2)
	{
		code_type = EAN2;
	}
	else
	{
		code_type = EAN5;
	}

	/* Calculate parity for EAN2 */
	if(code_type == EAN2)
	{
		int code_value, parity_bit;

		code_value = (10 * ctoi(source[0])) + ctoi(source[1]);
		parity_bit = code_value%4;

		switch(parity_bit)
		{
			case 0: strcpy(parity, "OO"); break;
			case 1: strcpy(parity, "OE"); break;
			case 2: strcpy(parity, "EO"); break;
			case 3: strcpy(parity, "EE"); break;
		}

	}

	if(code_type == EAN5)
	{
		int values[6], parity_sum, parity_bit;

		for(i = 0; i < 6; i++)
		{
			values[i] = ctoi(source[i]);
		}

		parity_sum = (3 * (values[0] + values[2] + values[4]));
		parity_sum += (9 * (values[1] + values[3]));

		parity_bit = parity_sum%10;

		switch(parity_bit)
		{
			case 0: strcpy(parity, "EEOOO"); break;
			case 1: strcpy(parity, "EOEOO"); break;
			case 2: strcpy(parity, "EOOEO"); break;
			case 3: strcpy(parity, "EOOOE"); break;
			case 4: strcpy(parity, "OEEOO"); break;
			case 5: strcpy(parity, "OOEEO"); break;
			case 6: strcpy(parity, "OOOEE"); break;
			case 7: strcpy(parity, "OEOEO"); break;
			case 8: strcpy(parity, "OEOOE"); break;
			case 9: strcpy(parity, "OOEOE"); break;
		}
	}

	for(i = 0; i < strlen(source); i++)
	{
		switch(parity[i])
		{
			case 'O':
				switch(source[i])
				{
					case '0': concat (dest, "3211"); break;
					case '1': concat (dest, "3221"); break;
					case '2': concat (dest, "2122"); break;
					case '3': concat (dest, "1411"); break;
					case '4': concat (dest, "1132"); break;
					case '5': concat (dest, "1231"); break;
					case '6': concat (dest, "1114"); break;
					case '7': concat (dest, "1312"); break;
					case '8': concat (dest, "1213"); break;
					case '9': concat (dest, "3112"); break;
				}
				break;
			case 'E':
				switch(source[i])
				{
					case '0': concat (dest, "1123"); break;
					case '1': concat (dest, "1222"); break;
					case '2': concat (dest, "2212"); break;
					case '3': concat (dest, "1141"); break;
					case '4': concat (dest, "2311"); break;
					case '5': concat (dest, "1321"); break;
					case '6': concat (dest, "4111"); break;
					case '7': concat (dest, "2131"); break;
					case '8': concat (dest, "3121"); break;
					case '9': concat (dest, "2113"); break;
				}
				break;
		}

		/* Glyph separator */
		if(i != (strlen(source) - 1))
		{
			concat (dest, "11");
		}
	}
}


/* ************************ EAN-13 ****************** */

char ean_check(char source[])
{ /* Calculate the correct check digit for a EAN-13 barcode */
	int i;
	unsigned int h, count, check_digit;

	count = 0;

	h = strlen(source);
	for (i = h - 1; i >= 0; i--)
	{
		count += ctoi(source[i]);

		if (!((i%2) == 0))
		{
			count += 2 * ctoi(source[i]);
		}
	}
	check_digit = 10 - (count%10);
	return itoc(check_digit);
}

void ean13(char source[], char dest[])
{
	unsigned int length, i, half_way;
	char parity[6];

	if (strlen(source) != 12)
	{
		printf("zebar: Invalid EAN-13\n");
		exit(0);
	}

	/* Add the appropriate check digit */
	length = strlen(source);
	source[length] = ean_check(source);
	source[length + 1] = '\0';
	printf("zebar: Drawing EAN-13 \"%s\"\n", source);

	switch(source[0]) /* Parity dependant on first digit of country code */
	{
		case '1': strcpy(parity, "OEOEE"); break;
		case '2': strcpy(parity, "OEEOE"); break;
		case '3': strcpy(parity, "OEEEO"); break;
		case '4': strcpy(parity, "EOOEE"); break;
		case '5': strcpy(parity, "EEOOE"); break;
		case '6': strcpy(parity, "EEEOO"); break;
		case '7': strcpy(parity, "EOEOE"); break;
		case '8': strcpy(parity, "EOEEO"); break;
		case '9': strcpy(parity, "EEOEO"); break;
		default: strcpy(parity, "OOOOO"); break;
	}

	/* Now get on with the cipher */

	half_way = 7;

	/* start character */
	concat (dest, "111");

	for(i = 1; i <= strlen(source); i++)
	{
		if (i == half_way)
		{
			/* middle character - separates manufacturer no. from product no. */
			/* also inverses right hand characters */
			concat (dest, "11111");
		}

		if(((i > 1) && (i < 7)) && (parity[i - 2] == 'E'))
		{
			switch(source[i])
			{
				case '0': concat (dest, "1123"); break;
				case '1': concat (dest, "1222"); break;
				case '2': concat (dest, "2212"); break;
				case '3': concat (dest, "1141"); break;
				case '4': concat (dest, "2311"); break;
				case '5': concat (dest, "1321"); break;
				case '6': concat (dest, "4111"); break;
				case '7': concat (dest, "2131"); break;
				case '8': concat (dest, "3121"); break;
				case '9': concat (dest, "2113"); break;
			}
		}
		else
		{
			switch(source[i])
			{
				case '0': concat (dest, "3211"); break;
				case '1': concat (dest, "2221"); break;
				case '2': concat (dest, "2122"); break;
				case '3': concat (dest, "1411"); break;
				case '4': concat (dest, "1132"); break;
				case '5': concat (dest, "1231"); break;
				case '6': concat (dest, "1114"); break;
				case '7': concat (dest, "1312"); break;
				case '8': concat (dest, "1213"); break;
				case '9': concat (dest, "3112"); break;
			}
		}
	}

	/* stop character */
	concat (dest, "111");
}

/* ********************* SBN, ISBN AND ISBN-13 ***************** */

char isbn13_check(char source[]) /* For ISBN(13) only */
{
	unsigned int i, weight, sum, check;

	sum = 0;
	weight = 1;

	for(i = 0; i < (strlen(source) - 1); i++)
	{
		sum += ctoi(source[i]) * weight;
		if(weight == 1) weight = 3; else weight = 1;
	}

	check = sum % 10;
	check = 10 - check;
	return itoc(check);
}

char isbn_check(char source[]) /* For ISBN(10) and SBN only */
{
	unsigned int i, weight, sum, check;

	sum = 0;
	weight = 1;
	for(i = 0; i < (strlen(source) - 1); i++)
	{
		sum += ctoi(source[i]) * weight;
		weight++;
	}

	check = sum % 11;
	return itoc(check);
}

void isbn(char source[], char dest[]) /* Make an EAN-13 barcode from an SBN or ISBN */
{
	int i;
	char check_digit;

	/* Input must be 9, 10 or 13 characters */
	if(((strlen(source) < 9) || (strlen(source) > 13)) || ((strlen(source) > 10) && (strlen(source) < 13)))
	{
		printf("zebar: Invalid SBN or ISBN\n");
		exit(0);
	}

	/* Catch lower case X in input */
	if(source[strlen(source) - 1] == 'x')
	{
		source[strlen(source) - 1] = 'X';
	}

	if(strlen(source) == 13) /* Using 13 character ISBN */
	{
		if(!(((source[0] == '9') && (source[1] == '7')) &&
		((source[2] == '8') || (source[2] == '9'))))
		{
			printf("zebar: Invalid ISBN\n");
			exit(0);
		}

		check_digit = isbn13_check(source);
		if (source[strlen(source) - 1] != check_digit)
		{
			printf("zebar: Invalid ISBN\n");
			exit(0);
		}
		source[12] = '\0';

		ean13(source, dest);
	}

	if(strlen(source) == 10) /* Using 10 digit ISBN */
	{
		check_digit = isbn_check(source);
		if(check_digit != source[strlen(source) - 1])
		{
			printf("zebar: Invalid ISBN\n");
			exit(0);
		}
		for(i = 13; i > 0; i--)
		{
			source[i] = source[i - 3];
		}
		source[0] = '9';
		source[1] = '7';
		source[2] = '8';
		source[12] = '\0';

		ean13(source, dest);
	}

	if(strlen(source) == 9) /* Using 9 digit SBN */
	{
		/* Add leading zero */
		for(i = 10; i > 0; i--)
		{
			source[i] = source[i - 1];
		}
		source[0] = '0';

		/* Verify check digit */
		check_digit = isbn_check(source);
		if(check_digit != source[strlen(source) - 1])
		{
			printf("zebar: Invalid SBN\n");
			exit(0);
		}

		/* Convert to EAN-13 number */
		for(i = 13; i > 0; i--)
		{
			source[i] = source[i - 3];
		}
		source[0] = '9';
		source[1] = '7';
		source[2] = '8';
		source[12] = '\0';

		ean13(source, dest);
	}

}

/* ****************** UPC-A UPC-E EAN-8 ************** */

char get_check(char source[])
{ /* Calculate the correct check digit for a UPC barcode */
	unsigned int i, count, check_digit;

	count = 0;

	for (i = 0; i < strlen(source); i++)
	{
		count += ctoi(source[i]);

		if ((i%2) == 0)
		{
			count += 2 * (ctoi(source[i]));
		}
	}

	check_digit = 10 - (count%10);
	return itoc(check_digit);
}

void upca_draw(char source[], char dest[])
{ /* UPC A is usually used for 12 digit numbers, but this function takes a source of any length */
	unsigned int i, half_way;

	half_way = strlen(source) / 2;

	/* start character */
	concat (dest, "111");

	for(i = 0; i <= strlen(source); i++)
	{
		if (i == half_way)
		{
			/* middle character - separates manufacturer no. from product no. */
			/* also inverses right hand characters */
			concat(dest, "11111");
		}

		switch(source[i])
		{
			case '0': concat (dest, "3211"); break;
			case '1': concat (dest, "2221"); break;
			case '2': concat (dest, "2122"); break;
			case '3': concat (dest, "1411"); break;
			case '4': concat (dest, "1132"); break;
			case '5': concat (dest, "1231"); break;
			case '6': concat (dest, "1114"); break;
			case '7': concat (dest, "1312"); break;
			case '8': concat (dest, "1213"); break;
			case '9': concat (dest, "3112"); break;
		}
	}

	/* stop character */
	concat (dest, "111");
}

void ean8(char source[], char dest[])
{ /* Make a UPC A barcode when we haven't been given the check digit */
	int length;

	length = strlen(source);
	if(length != 7)
	{
		printf("zebar: Invalid EAN-8\n");
		exit(0);
	}
	printf("zebar: Drawing EAN-8 \"%s%c\"\n", source, get_check(source));
	source[length] = get_check(source);
	source[length + 1] = '\0';
	upca_draw(source, dest);
}

void upca(char source[], char dest[])
{ /* Make a UPC A barcode when we haven't been given the check digit */
	int length;

	length = strlen(source);
	if(length != 11)
	{
		printf("zebar: Invalid UPC-A\n");
		exit(0);
	}
	printf("zebar: Drawing UPC-A \"%s%c\"\n", source, get_check(source));
	source[length] = get_check(source);
	source[length + 1] = '\0';
	upca_draw(source, dest);
}

void upce(char source[], char dest[])
{ /* UPC E is a zero-compressed version of UPC A */
	unsigned int i, num_system;
	char emode, equivalent[12], check_digit, parity[8], temp[8];

	if((strlen(source) != 6) && (strlen(source) != 7))
	{
		printf("zebar: Invalid UPC-E\n");
		exit(0);
	}

	/* Two number systems can be used - system 0 and system 1 */

	if(strlen(source) == 7)
	{
		switch(source[0])
		{
			case '0':
				num_system = 0;
				break;
			case '1':
				num_system = 1;
				break;
			default:
				num_system = 0;
				printf("zebar: Number system %c not supported - using system 0 instead\n", source[0]);
				break;
		}
		strcpy(temp, source);
		for(i = 1; i <= 7; i++)
		{
			source[i - 1] = temp[i];
		}
	}
	else
		num_system = 0;

	/* Expand the zero-compressed UPCE code to make a UPCA equivalent */

	emode = source[5];
	for(i = 0; i < 11; i++)
	{
		equivalent[i] = '0';
	}
	equivalent[1] = source[0];
	equivalent[2] = source[1];
	equivalent[11] = '\0';

	switch(emode)
	{
		case '0':
		case '1':
		case '2':
			equivalent[3] = emode;
			equivalent[8] = source[2];
			equivalent[9] = source[3];
			equivalent[10] = source[4];
			break;
		case '3':
			equivalent[3] = source[2];
			equivalent[9] = source[3];
			equivalent[10] = source[4];
			break;
		case '4':
			equivalent[3] = source[2];
			equivalent[4] = source[3];
			equivalent[10] = source[4];
			break;
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
			equivalent[3] = source[2];
			equivalent[4] = source[3];
			equivalent[5] = source[4];
			equivalent[10] = emode;
			break;
	}

	/* Get the check digit from the expanded UPCA code */

	check_digit = get_check(equivalent);
	printf("zebar: Drawing UPC-E \"%d%s%c\"\n", num_system, source, check_digit);

	/* Use the number system and check digit information to choose a parity scheme */

	switch(num_system)
	{
		case 1:
			switch(check_digit)
			{
				case '0': strcpy(parity, "OOOEEE"); break;
				case '1': strcpy(parity, "OOEOEE"); break;
				case '2': strcpy(parity, "OOEEOE"); break;
				case '3': strcpy(parity, "OOEEEO"); break;
				case '4': strcpy(parity, "OEOOEE"); break;
				case '5': strcpy(parity, "OEEOOE"); break;
				case '6': strcpy(parity, "OEEEOO"); break;
				case '7': strcpy(parity, "OEOEOE"); break;
				case '8': strcpy(parity, "OEOEEO"); break;
				case '9': strcpy(parity, "OEEOEO"); break;
			}
			break;

		case 0:
		default:
			switch(check_digit)
			{
				case '0': strcpy(parity, "EEEOOO"); break;
				case '1': strcpy(parity, "EEOEOO"); break;
				case '2': strcpy(parity, "EEOOEO"); break;
				case '3': strcpy(parity, "EEOOOE"); break;
				case '4': strcpy(parity, "EOEEOO"); break;
				case '5': strcpy(parity, "EOOEEO"); break;
				case '6': strcpy(parity, "EOOOEE"); break;
				case '7': strcpy(parity, "EOEOEO"); break;
				case '8': strcpy(parity, "EOEOOE"); break;
				case '9': strcpy(parity, "EOOEOE"); break;
			}
			break;
	}

	/* Take all this information and make the barcode pattern */


	/* start character */
	concat (dest, "111");

	for(i = 0; i <= strlen(source); i++)
	{
		switch(parity[i])
		{
			case 'E':
				switch(source[i])
				{
					case '0': concat (dest, "1123"); break;
					case '1': concat (dest, "1222"); break;
					case '2': concat (dest, "2212"); break;
					case '3': concat (dest, "1141"); break;
					case '4': concat (dest, "2311"); break;
					case '5': concat (dest, "1321"); break;
					case '6': concat (dest, "4111"); break;
					case '7': concat (dest, "2131"); break;
					case '8': concat (dest, "3121"); break;
					case '9': concat (dest, "2113"); break;
				}
				break;
			case 'O':
				switch(source[i])
				{
					case '0': concat (dest, "3211"); break;
					case '1': concat (dest, "2221"); break;
					case '2': concat (dest, "2122"); break;
					case '3': concat (dest, "1411"); break;
					case '4': concat (dest, "1132"); break;
					case '5': concat (dest, "1231"); break;
					case '6': concat (dest, "1114"); break;
					case '7': concat (dest, "1312"); break;
					case '8': concat (dest, "1213"); break;
					case '9': concat (dest, "3112"); break;
				}
				break;
		}
	}

	/* stop character */
	concat (dest, "111111");
}
