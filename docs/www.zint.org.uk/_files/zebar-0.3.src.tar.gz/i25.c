/*  Zebar - A barcode generating program using SDL
    Copyright (C) 2006 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <stdio.h>

void concat(char dest[], char source[]);

void two_of_five(char source[], char dest[])
{ /* Interlaced 2 of 5 */

	unsigned int i, j, k;
	char bars[7], spaces[7], mixed[14];

	/* Input must be an even number of characters for Interlaced 2 of 5 to work */
	if ((strlen(source)%2) != 0)
	{
		unsigned int length;
		char temp[200];

		length = strlen(source);

		strcpy(temp, source);
		source[0] = '0';

		for(i = 0; i <= length; i++)
		{
			source[i + 1] = temp[i];
		}
	}

	printf("zebar: Drawing I2of5 \"%s\"\n", source);

	/* start character */
	concat(dest, "1111");

	for(i = 0; i < strlen(source); i+=2 )
	{
		strcpy(bars, "");
		switch(source[i])
		{
			case '0': concat (bars, "11221"); break;
			case '1': concat (bars, "21112"); break;
			case '2': concat (bars, "12112"); break;
			case '3': concat (bars, "22111"); break;
			case '4': concat (bars, "11212"); break;
			case '5': concat (bars, "21211"); break;
			case '6': concat (bars, "12211"); break;
			case '7': concat (bars, "11122"); break;
			case '8': concat (bars, "21121"); break;
			case '9': concat (bars, "12121"); break;
		}
		strcpy(spaces, "");
		switch(source[i + 1])
		{
			case '0': concat (spaces, "11221"); break;
			case '1': concat (spaces, "21112"); break;
			case '2': concat (spaces, "12112"); break;
			case '3': concat (spaces, "22111"); break;
			case '4': concat (spaces, "11212"); break;
			case '5': concat (spaces, "21211"); break;
			case '6': concat (spaces, "12211"); break;
			case '7': concat (spaces, "11122"); break;
			case '8': concat (spaces, "21121"); break;
			case '9': concat (spaces, "12121"); break;
		}

		k = 0;
		for(j = 0; j <= 4; j++)
		{
			mixed[k] = bars[j]; k++;
			mixed[k] = spaces[j]; k++;
		}
		mixed[k] = '\0';
		concat (dest, mixed);
	}

	/* Stop character */
	concat (dest, "211");

}
