/*  Zebar - A barcode generating program using SDL
    Copyright (C) 2006 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <SDL/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define UPCA		1
#define UPCE		2
#define EAN2		3
#define EAN5		4
#define CODABAR		5
#define EAN8		8
#define MSI		9
#define MSI10		100
#define MSI1010		101
#define MSI11		110
#define MSI1110		111
#define ISBN		10
#define CODE11		11
#define I2OF5		12
#define EAN13		13
#define TELEPEN		20
#define TELENUM		21
#define CODE25		25
#define CODE39		39
#define EXCODE39	40
#define CODE93		93
#define CODE128		128
#define POSTNET		200
#define RM4SCC		210

void ean8(char source[], char dest[]); /* EAN 8 - Similar to UPCA and EAN13 */
void upca(char source[], char dest[]); /* Universal Product Code */
void upce(char source[], char dest[]); /* A zero compressed version of UPC A for small packages */
void c39(char source[], char dest[]); /* Code 3 from 9 (or Code 39) */
void ec39(char source[], char dest[]); /* Extended Code 3 from 9 (or Code 39+) */
void codabar(char source[], char dest[]); /* Codabar - a simple substitution cipher */
void two_of_five(char source[], char dest[]); /* Interlaced 2 of 5 */
void c93(char source[], char dest[]); /* Code 93 - a re-working of Code 39+, generates 2 check digits */
void ean13(char source[], char dest[]); /* EAN 13 - Used on products manufactured outside the US */
void isbn(char source[], char dest[]); /* International Standard Book Number > EAN 13 */
void add_on(char source[], char dest[], int mode); /* Add-on EAN-2 or EAN-5 */
void c128(char source[], char dest[]); /* Code 128 */
void code_two_of_five(char source[], char dest []); /* Code 2 of 5 (Non-Interlaced) */
void code_11(char source[], char dest[]); /* Code 11 */
void msi_plessey(char source[], char dest[]); /* MSI Plessey without check digit */
void msi_plessey_mod10(char source[], char dest[]);
void msi_plessey_mod1010(char source[], char dest[]);
void msi_plessey_mod11(char source[], char dest[]);
void msi_plessey_mod1110(char source[], char dest[]);
void telepen(char source[], char dest[]); /* Telepen ASCII */
void telepen_num(char source[], char dest[]); /* Telepen Numeric */
void postnet(char source[], char dest[]); /* Postnet as used in the US */
void rm4scc(char source[], char dest[]); /* Royal Mail system used in the UK */
int ctoi(char source);

Uint16 CreateHicolorPixel(SDL_PixelFormat * fmt, Uint8 red, Uint8 green,
			  Uint8 blue)
{
    Uint16 value;

    value = ((red >> fmt->Rloss) << fmt->Rshift) +
	((green >> fmt->Gloss) << fmt->Gshift) +
	((blue >> fmt->Bloss) << fmt->Bshift);

    return value;
}

void one_d_plot(char code[], char template[])
/* 'plots' the barcode into a template string where 1 is a bar and 0 is a blank */
{
	int status = 1; /* 1 for black, 0 for white */
	unsigned int i, j, k, bar_width;

	k = 0;
	for(i = 0; i < strlen(code); i++)
	{
		bar_width = ctoi(code[i]);
		if(bar_width == 9) { bar_width = 10; }
		for(j = 0; j < bar_width; j++)
		{
			if(status == 1) {
				template[k] = '1';
				template[k + 1] = '1';
			}
			else {
				template[k] = '0';
				template[k + 1] = '0';
			}
			k += 2;
		}
		if(status == 1) { status = 0; } else { status = 1; }
	}
	template[k] = '\0';
}

void post_plot(char code[], char template[])
/* 'plots' the barcode into a template string where 1 is a bar and 0 is a blank */
/* Postnet plotting - Top half only - bottom half is constant */
{
	unsigned int i, k;

	k = 0;
	for(i = 0; i < strlen(code); i++)
	{
		if(code[i] == 'L') {
			template[k] = '1';
			template[k + 1] = '1';
		}
		else {
			template[k] = '0';
			template[k + 1] = '0';
		}
		template[k + 2] = '0';
		template[k + 3] = '0';
		k += 4;
	}
	template[k - 1] = '\0';
}

void rm_upper(char code[], char template[])
/* 'plots' the barcode into a template string where 1 is a bar and 0 is a blank */
/* Royal Mail plotting - top half */
{
	unsigned int i, k;

	k = 0;
	for(i = 0; i < strlen(code); i++)
	{
		if((code[i] == '2')||(code[i] == '3')) {
			template[k] = '1';
			template[k + 1] = '1';
		}
		else {
			template[k] = '0';
			template[k + 1] = '0';
		}
		template[k + 2] = '0';
		template[k + 3] = '0';
		k += 4;
	}
	template[k - 1] = '\0';
}

void rm_lower(char code[], char template[])
/* 'plots' the barcode into a template string where 1 is a bar and 0 is a blank */
/* Royal Mail plotting - bottom half */
{
	unsigned int i, k;

	k = 0;
	for(i = 0; i < strlen(code); i++)
	{
		if((code[i] == '1')||(code[i] == '3')) {
			template[k] = '1';
			template[k + 1] = '1';
		}
		else {
			template[k] = '0';
			template[k + 1] = '0';
		}
		template[k + 2] = '0';
		template[k + 3] = '0';
		k += 4;
	}
	template[k - 1] = '\0';
}


int main(int argc, char *argv[])
{
	char code[10000];
	char template[100000];

    SDL_Surface *screen;
	SDL_Event event;
    Uint16 *raw_pixels;
    int x, y, calcwidth, calcheight, addon;
	int i, k, border, mode, data, bind;
			Uint16 pixel_color;
			int offset;
	unsigned int l;

	border = 10;

    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
	printf("Unable to initialize SDL: %s\n", SDL_GetError());
	return 1;
    }

	bind = 0;
	addon = 0;
    atexit(SDL_Quit);
	mode = CODE128; /* Sets the default */

	for (i = 0; i < argc; i++) {
		if (!strcmp(argv[i], "--upca")) {
			mode = UPCA;
		}
		if (!strcmp(argv[i], "--ean8")) {
			mode = EAN8;
		}
		if (!strcmp(argv[1], "--upce")) {
			mode = UPCE;
		}
		if (!strcmp(argv[i], "--c39")) {
			mode = CODE39;
		}
		if (!strcmp(argv[i], "--ec39")) {
			mode = EXCODE39;
		}
		if (!strcmp(argv[i], "--codabar")) {
			mode = CODABAR;
		}
		if (!strcmp(argv[i], "--i25")) {
			mode = I2OF5;
		}
		if (!strcmp(argv[i], "--c93")) {
			mode = CODE93;
		}
		if (!strcmp(argv[i], "--ean13")) {
			mode = EAN13;
		}
		if (!strcmp(argv[i], "--isbn")) {
			mode = ISBN;
		}
		if (!strcmp(argv[i], "--c128")) {
			mode = CODE128;
		}
		if (!strcmp(argv[i], "--c25")) {
			mode = CODE25;
		}
		if (!strcmp(argv[i], "--c11")) {
			mode = CODE11;
		}
		if (!strcmp(argv[i], "--msi")) {
			mode = MSI;
		}
		if (!strcmp(argv[i], "--msi10")) {
			mode = MSI10;
		}
		if (!strcmp(argv[i], "--msi1010")) {
			mode = MSI1010;
		}
		if (!strcmp(argv[i], "--msi11")) {
			mode = MSI11;
		}
		if (!strcmp(argv[i], "--msi1110")) {
			mode = MSI1110;
		}
		if (!strcmp(argv[i], "--ean2")) {
			mode = EAN2;
		}
		if (!strcmp(argv[i], "--ean5")) {
			mode = EAN5;
		}
		if (!strcmp(argv[i], "--telepen")) {
			mode = TELEPEN;
		}
		if (!strcmp(argv[i], "--telenum")) {
			mode = TELENUM;
		}
		if (!strcmp(argv[i], "--postnet")) {
			mode = POSTNET;
		}
		if (!strcmp(argv[i], "--royal")) {
			mode = RM4SCC;
		}
		if (!strcmp(argv[i], "--addon")) {
			addon = i + 1;
		}
		if (!strcmp(argv[i], "--bind")) {
			bind = i + 1;
		}

	}

	data = argc - 1;

	switch (mode)
	{
		case UPCA: upca(argv[data], code);
			break;
		case EAN8: ean8(argv[data], code);
			break;
		case UPCE: upce(argv[data], code);
			break;
		case CODE39: c39(argv[data], code);
			break;
		case EXCODE39: ec39(argv[data], code);
			break;
		case CODABAR: codabar(argv[data], code);
			break;
		case I2OF5: two_of_five(argv[data], code);
			break;
		case CODE93: c93(argv[data], code);
			break;
		case EAN13: ean13(argv[data], code);
			break;
		case ISBN: isbn(argv[data], code);
			break;
		case CODE128: c128(argv[data], code);
			break;
		case CODE25: code_two_of_five(argv[data], code);
			break;
		case CODE11: code_11(argv[data], code);
			break;
		case MSI: msi_plessey(argv[data], code);
			break;
		case MSI10: msi_plessey_mod10(argv[data], code);
			break;
		case MSI1010: msi_plessey_mod1010(argv[data], code);
			break;
		case MSI11: msi_plessey_mod11(argv[data], code);
			break;
		case MSI1110: msi_plessey_mod1110(argv[data], code);
			break;
		case EAN2: add_on(argv[data], code, 0);
			break;
		case EAN5: add_on(argv[data], code, 0);
			break;
		case TELEPEN: telepen(argv[data], code);
			break;
		case TELENUM: telepen_num(argv[data], code);
			break;
		case POSTNET: postnet(argv[data], code);
			break;
		case RM4SCC: rm4scc(argv[data], code);
			break;
		default: c128(argv[data], code);
			break;
	}

	if (addon != 0)
	{
		add_on(argv[addon], code, 1);
	}

	switch(mode)
	{
		case UPCA:
		case EAN8:
		case UPCE:
		case CODE39:
		case EXCODE39:
		case CODABAR:
		case I2OF5:
		case CODE93:
		case EAN13:
		case ISBN:
		case CODE128:
		case CODE25:
		case CODE11:
		case MSI:
		case MSI10:
		case MSI1010:
		case MSI11:
		case MSI1110:
		case EAN2:
		case EAN5:
		case TELEPEN:
		case TELENUM:
		default:
			one_d_plot(code, template);
			calcwidth = (strlen(template) + (border * 2));
			calcheight = 200;
	
			screen = SDL_SetVideoMode(calcwidth, calcheight, 16, 0);
			if (screen == NULL) {
				printf("Unable to set video mode: %s\n", SDL_GetError());
				return 1;
			}
			SDL_WM_SetCaption("Zebar", "");
			SDL_LockSurface(screen);
			raw_pixels = (Uint16 *) screen->pixels;
			pixel_color = CreateHicolorPixel(screen->format, 255, 255, 255);
	
			/* Set a blank screen to start from */
			for (y = 0; y < calcheight; y++) {
				for (x = 0; x < calcwidth; x++) {
					offset = (screen->pitch / 2 * y + x);
					raw_pixels[offset] = pixel_color;
				}
			}
	
			pixel_color = CreateHicolorPixel(screen->format, 0, 0, 0);
	
			/* Draw the pattern on the background */
			for (y = border; y < (calcheight - border); y++) {
				for (x = border; x <= (calcwidth - border); x++) {
					if(template[(x - border)] == '1') {
						offset = (screen->pitch / 2 * y + x);
						raw_pixels[offset] = pixel_color;
					}
				}
			}
	
			/* bind if necessary */
			if (bind)
			{
				for (y = 0; y < (border * 2); y++) {
					for (x = 0; x < calcwidth; x++) {
						offset = (screen->pitch / 2 * y + x);
						raw_pixels[offset] = pixel_color;
					}
				}
				for (y = calcheight - (border * 2); y < calcheight; y++) {
					for (x = 0; x < calcwidth; x++) {
						offset = (screen->pitch / 2 * y + x);
						raw_pixels[offset] = pixel_color;
					}
				}
			}
		break;

		case POSTNET:

			post_plot(code, template);
			calcwidth = (strlen(template) + 20);
			calcheight = 50;
	
			screen = SDL_SetVideoMode(calcwidth, calcheight, 16, 0);
			if (screen == NULL) {
				printf("Unable to set video mode: %s\n", SDL_GetError());
				return 1;
			}
			SDL_WM_SetCaption("Zebar", "");
			SDL_LockSurface(screen);
			raw_pixels = (Uint16 *) screen->pixels;
			pixel_color = CreateHicolorPixel(screen->format, 255, 255, 255);
	
			/* Set a blank screen to start from */
			for (y = 0; y < calcheight; y++) {
				for (x = 0; x < calcwidth; x++) {
					offset = (screen->pitch / 2 * y + x);
					raw_pixels[offset] = pixel_color;
				}
			}
	
			pixel_color = CreateHicolorPixel(screen->format, 0, 0, 0);
	
			/* Draw top pattern on the background */
			for (y = border; y < (calcheight / 2); y++) {
				for (x = border; x <= (calcwidth - border); x++) {
					if(template[(x - border)] == '1') {
						offset = (screen->pitch / 2 * y + x);
						raw_pixels[offset] = pixel_color;
					}
				}
			}
	
	
			/* Draw bottom pattern on background */
			k = 0;
			for(l = 0; l < strlen(code); l++)
			{
				template[k] = '1';
				template[k + 1] = '1';
				template[k + 2] = '0';
				template[k + 3] = '0';
				k += 4;
			}
			template[k - 1] = '\0';
			for (y = (calcheight / 2); y < (calcheight - border); y++) {
				for (x = border; x <= (calcwidth - border); x++) {
					if(template[(x - border)] == '1') {
						offset = (screen->pitch / 2 * y + x);
						raw_pixels[offset] = pixel_color;
					}
				}
			}
		break;

		case RM4SCC:

			rm_upper(code, template);
			calcwidth = (strlen(template) + 20);
			calcheight = 70;
	
			screen = SDL_SetVideoMode(calcwidth, calcheight, 16, 0);
			if (screen == NULL) {
				printf("Unable to set video mode: %s\n", SDL_GetError());
				return 1;
			}
			SDL_WM_SetCaption("Zebar", "");
			SDL_LockSurface(screen);
			raw_pixels = (Uint16 *) screen->pixels;
			pixel_color = CreateHicolorPixel(screen->format, 255, 255, 255);
	
			/* Set a blank screen to start from */
			for (y = 0; y < calcheight; y++) {
				for (x = 0; x < calcwidth; x++) {
					offset = (screen->pitch / 2 * y + x);
					raw_pixels[offset] = pixel_color;
				}
			}
	
			pixel_color = CreateHicolorPixel(screen->format, 0, 0, 0);
	
			/* Draw top pattern on the background */
			for (y = 10; y < 30; y++) {
				for (x = border; x <= (calcwidth - border); x++) {
					if(template[(x - border)] == '1') {
						offset = (screen->pitch / 2 * y + x);
						raw_pixels[offset] = pixel_color;
					}
				}
			}
	
	
			/* Draw middle pattern on background */
			k = 0;
			for(l = 0; l < strlen(code); l++)
			{
				template[k] = '1';
				template[k + 1] = '1';
				template[k + 2] = '0';
				template[k + 3] = '0';
				k += 4;
			}
			template[k - 1] = '\0';
			for (y = 30; y < 40; y++) {
				for (x = border; x <= (calcwidth - border); x++) {
					if(template[(x - border)] == '1') {
						offset = (screen->pitch / 2 * y + x);
						raw_pixels[offset] = pixel_color;
					}
				}
			}

			rm_lower(code, template);

			/* Draw bottom pattern on the background */
			for (y = 40; y < 60; y++) {
				for (x = border; x <= (calcwidth - border); x++) {
					if(template[(x - border)] == '1') {
						offset = (screen->pitch / 2 * y + x);
						raw_pixels[offset] = pixel_color;
					}
				}
			}

		break;

	}

	SDL_UnlockSurface(screen);
	SDL_UpdateRect(screen, 0, 0, 0, 0);

	while (SDL_WaitEvent(&event) != 0) {
		if(event.type == SDL_QUIT) exit(0);
	}

	return 0;

}
