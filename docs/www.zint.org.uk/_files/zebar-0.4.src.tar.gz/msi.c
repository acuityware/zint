/* msi.c - Handles MSI/Plessey with various check options */
/* In which Saesneg -> Cymraeg */

/*  Zebar - A barcode generating program using SDL
    Copyright (C) 2006 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/* Mod11 (as shown on Barcode Island) is not included because it simply doesn't work -
   if you take any number and %11 you will get an answer from 0 to 10 but there are only
   symbols for 0 - 9 so what are you supposed to do with the extra one?
   When I tried to contact Barcode Island I found that their forum doesn't work and that
   my e-mail messages were rejected as spam. I shouldn't bother buying any software from them! */

void concat(char dest[], char source[]);
int ctoi(char source);
char itoc(int source);

void msi_plessey_draw(char dest[], char source)
{
	switch(source)
	{
		case '0': concat (dest, "12121212"); break;
		case '1': concat (dest, "12121221"); break;
		case '2': concat (dest, "12122112"); break;
		case '3': concat (dest, "12122121"); break;
		case '4': concat (dest, "12211212"); break;
		case '5': concat (dest, "12211221"); break;
		case '6': concat (dest, "12212112"); break;
		case '7': concat (dest, "12212121"); break;
		case '8': concat (dest, "21121212"); break;
		case '9': concat (dest, "21121221"); break;
	}
}

void msi_plessey(char source[], char dest[])
{ /* Plain MSI Plessey - does not calculate any check character */

	unsigned int i;

	/* start character */
	concat (dest, "21");

	for(i = 0; i <= strlen(source); i++)
	{
		msi_plessey_draw(dest, source[i]);
	}

	/* Stop character */
	concat (dest, "121");
}

void msi_plessey_mod10(char source[], char dest[])
{ /* MSI Plessey with Modulo 10 check digit */

	unsigned int i, wright, dau, pedwar, pump;
	char un[200], tri[200];

	/* start character */
	concat (dest, "21");

	/* draw data section */
	for(i = 0; i < strlen(source); i++)
	{
		msi_plessey_draw(dest, source[i]);
	}

	/* caluculate check digit */
	wright = 0;
	if((strlen(source)%2) == 0)
	{
		for(i = 1; i < strlen(source); i+=2)
		{
			un[wright] = source[i];
			wright ++;
		}
	}
	else
	{
		for(i = 0; i < strlen(source); i+=2)
		{
			un[wright] = source[i];
			wright ++;
		}
	}
	un[wright] = '\0';

	dau = atoi(un);
	dau *= 2;

	sprintf(tri,"%d",dau);

	pedwar = 0;
	for(i = 0; i < strlen(tri); i++)
	{
		pedwar += ctoi(tri[i]);
	}


	if((strlen(source)%2) == 0)
	{
		for(i = 0; i < strlen(source); i+=2)
		{
			pedwar += ctoi(source[i]);
		}
	}
	else
	{
		for(i = 1; i < strlen(source); i+=2)
		{
			pedwar += ctoi(source[i]);
		}
	}

	pump = (10 - pedwar%10);
	if(pump == 10)
	{
		pump = 0;
	}

	/* draw check digit */
	printf("MSI check digit '%c'\n", itoc(pump));
	msi_plessey_draw(dest, itoc(pump));

	/* Stop character */
	concat (dest, "121");
}

void msi_plessey_mod1010(char source[], char dest[])
{ /* MSI Plessey with two Modulo 10 check digits */

	unsigned int i, wright, dau, pedwar, pump, chwech;
	char un[200], tri[200];

	/* start character */
	concat (dest, "21");

	/* draw data section */
	for(i = 0; i < strlen(source); i++)
	{
		msi_plessey_draw(dest, source[i]);
	}

	/* calculate first check digit */
	wright = 0;
	if((strlen(source)%2) == 0)
	{
		for(i = 1; i < strlen(source); i+=2)
		{
			un[wright] = source[i];
			wright ++;
		}
	}
	else
	{
		for(i = 0; i < strlen(source); i+=2)
		{
			un[wright] = source[i];
			wright ++;
		}
	}
	un[wright] = '\0';

	dau = atoi(un);
	dau *= 2;

	sprintf(tri,"%d",dau);

	pedwar = 0;
	for(i = 0; i < strlen(tri); i++)
	{
		pedwar += ctoi(tri[i]);
	}


	if((strlen(source)%2) == 0)
	{
		for(i = 0; i < strlen(source); i+=2)
		{
			pedwar += ctoi(source[i]);
		}
	}
	else
	{
		for(i = 1; i < strlen(source); i+=2)
		{
			pedwar += ctoi(source[i]);
		}
	}

	pump = (10 - pedwar%10);
	if(pump == 10)
	{
		pump = 0;
	}

	/* calculate second check digit */
	wright = 0;
	if((strlen(source)%2) == 0)
	{
		for(i = 0; i < strlen(source); i+=2)
		{
			un[wright] = source[i];
			wright ++;
		}
	}
	else
	{
		for(i = 1; i < strlen(source); i+=2)
		{
			un[wright] = source[i];
			wright ++;
		}
	}
	un[wright] = itoc(pump);
	wright++;
	un[wright] = '\0';

	dau = atoi(un);
	dau *= 2;

	sprintf(tri,"%d",dau);

	pedwar = 0;
	for(i = 0; i < strlen(tri); i++)
	{
		pedwar += ctoi(tri[i]);
	}


	if((strlen(source)%2) == 0)
	{
		for(i = 1; i < strlen(source); i+=2)
		{
			pedwar += ctoi(source[i]);
		}
	}
	else
	{
		for(i = 0; i < strlen(source); i+=2)
		{
			pedwar += ctoi(source[i]);
		}
	}

	chwech = (10 - pedwar%10);
	if(chwech == 10)
	{
		chwech = 0;
	}

	/* Draw check digits */
	printf("MSI check digits '%c%c'\n", itoc(pump), itoc(chwech));
	msi_plessey_draw(dest, itoc(pump));
	msi_plessey_draw(dest, itoc(chwech));

	/* Stop character */
	concat (dest, "121");
}
