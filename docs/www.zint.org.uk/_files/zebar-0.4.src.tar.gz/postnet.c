/* postnet.c - Handles PostNet and RM4SCC */

/*  Zebar - A barcode generating program using SDL
    Copyright (C) 2006 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <stdio.h>

void concat(char dest[], char source[]);
int ctoi(char source);

void postnet_draw(char source, char dest[])
{
	switch(source)
	{
		/* In this table L is long as S is short */
		case '0': concat(dest, "LLSSS"); break;
		case '1': concat(dest, "SSSLL"); break;
		case '2': concat(dest, "SSLSL"); break;
		case '3': concat(dest, "SSLLS"); break;
		case '4': concat(dest, "SLSSL"); break;
		case '5': concat(dest, "SLSLS"); break;
		case '6': concat(dest, "SLLSS"); break;
		case '7': concat(dest, "LSSSL"); break;
		case '8': concat(dest, "LSSLS"); break;
		case '9': concat(dest, "LSLSS"); break;
	}
}

void postnet(char source[], char dest[])
{
	unsigned int i, sum, check_digit;

	sum = 0;

	/* start character */
	concat (dest, "L");

	for (i=0; i < strlen(source); i++)
	{
		postnet_draw(source[i], dest);
		sum += ctoi(source[i]);
	}

	check_digit = 10 - (sum%10);
	printf("PostNet check digit '%d'\n", check_digit);
	postnet_draw(source[i], dest);

	/* stop character */
	concat (dest, "L");
}

void post_plot(int *stack_row, int *matrix_width, char pattern_matrix[], char argument[])
{
	char height_pattern[200];
	unsigned int loopey;
	int writer;
	strcpy(height_pattern, "");

	postnet(argument, height_pattern);

	writer = 0;
	for(loopey = 0; loopey < strlen(height_pattern); loopey++)
	{
		if(height_pattern[loopey] == 'L')
		{
			pattern_matrix[writer] = '1';
		}
		pattern_matrix[writer + 1000] = '1';
		writer += 2;
	}
	(*stack_row) = 2;
	(*matrix_width) = writer - 1;
}

void rm4scc_draw(char source, char dest[])
{
	switch(source)
	{
		case '0': concat(dest, "0033"); break;
		case '1': concat(dest, "0123"); break;
		case '2': concat(dest, "0132"); break;
		case '3': concat(dest, "1023"); break;
		case '4': concat(dest, "1032"); break;
		case '5': concat(dest, "1122"); break;
		case '6': concat(dest, "0213"); break;
		case '7': concat(dest, "0303"); break;
		case '8': concat(dest, "0312"); break;
		case '9': concat(dest, "1203"); break;
		case 'A': concat(dest, "1212"); break;
		case 'B': concat(dest, "1302"); break;
		case 'C': concat(dest, "0231"); break;
		case 'D': concat(dest, "0321"); break;
		case 'E': concat(dest, "0330"); break;
		case 'F': concat(dest, "1221"); break;
		case 'G': concat(dest, "1230"); break;
		case 'H': concat(dest, "1320"); break;
		case 'I': concat(dest, "2013"); break;
		case 'J': concat(dest, "2103"); break;
		case 'K': concat(dest, "2112"); break;
		case 'L': concat(dest, "3003"); break;
		case 'M': concat(dest, "3012"); break;
		case 'N': concat(dest, "3102"); break;
		case 'O': concat(dest, "2031"); break;
		case 'P': concat(dest, "2121"); break;
		case 'Q': concat(dest, "2130"); break;
		case 'R': concat(dest, "3021"); break;
		case 'S': concat(dest, "3030"); break;
		case 'T': concat(dest, "3120"); break;
		case 'U': concat(dest, "2211"); break;
		case 'V': concat(dest, "2301"); break;
		case 'W': concat(dest, "2310"); break;
		case 'X': concat(dest, "3201"); break;
		case 'Y': concat(dest, "3210"); break;
		case 'Z': concat(dest, "3300"); break;
	}
}

void rm4scc(char source[], char dest[])
{
	unsigned int i, top, bottom, row, column;

	/* start character */
	concat (dest, "2");

	top = 0;
	bottom = 0;

	for (i=0; i < strlen(source); i++)
	{
		rm4scc_draw(source[i], dest);
		switch(source[i])
		{
			case '0': top += 1; bottom += 1; break;
			case '1': top += 1; bottom += 2; break;
			case '2': top += 1; bottom += 3; break;
			case '3': top += 1; bottom += 4; break;
			case '4': top += 1; bottom += 5; break;
			case '5': top += 1; bottom += 0; break;
			case '6': top += 2; bottom += 1; break;
			case '7': top += 2; bottom += 2; break;
			case '8': top += 2; bottom += 3; break;
			case '9': top += 2; bottom += 4; break;
			case 'A': top += 2; bottom += 5; break;
			case 'B': top += 2; bottom += 0; break;
			case 'C': top += 3; bottom += 1; break;
			case 'D': top += 3; bottom += 2; break;
			case 'E': top += 3; bottom += 3; break;
			case 'F': top += 3; bottom += 4; break;
			case 'G': top += 3; bottom += 5; break;
			case 'H': top += 3; bottom += 0; break;
			case 'I': top += 4; bottom += 1; break;
			case 'J': top += 4; bottom += 2; break;
			case 'K': top += 4; bottom += 3; break;
			case 'L': top += 4; bottom += 4; break;
			case 'M': top += 4; bottom += 5; break;
			case 'N': top += 4; bottom += 0; break;
			case 'O': top += 5; bottom += 1; break;
			case 'P': top += 5; bottom += 2; break;
			case 'Q': top += 5; bottom += 3; break;
			case 'R': top += 5; bottom += 4; break;
			case 'S': top += 5; bottom += 5; break;
			case 'T': top += 5; bottom += 0; break;
			case 'U': top += 0; bottom += 1; break;
			case 'V': top += 0; bottom += 2; break;
			case 'W': top += 0; bottom += 3; break;
			case 'X': top += 0; bottom += 4; break;
			case 'Y': top += 0; bottom += 5; break;
			case 'Z': top += 0; bottom += 0; break;
		}
	}

	row = top % 6;
	column = bottom % 6;

	printf("RM4SCC check digit '");

	/* Calculate the check digit */
	switch(row)
	{
		case 1:
			switch(column)
			{
				case 1: rm4scc_draw('0', dest); printf("0"); break;
				case 2: rm4scc_draw('1', dest); printf("1"); break;
				case 3: rm4scc_draw('2', dest); printf("2"); break;
				case 4: rm4scc_draw('3', dest); printf("3"); break;
				case 5: rm4scc_draw('4', dest); printf("4"); break;
				case 0: rm4scc_draw('5', dest); printf("5"); break;
			}
			break;
		case 2:
			switch(column)
			{
				case 1: rm4scc_draw('6', dest); printf("6"); break;
				case 2: rm4scc_draw('7', dest); printf("7"); break;
				case 3: rm4scc_draw('8', dest); printf("8"); break;
				case 4: rm4scc_draw('9', dest); printf("9"); break;
				case 5: rm4scc_draw('A', dest); printf("A"); break;
				case 0: rm4scc_draw('B', dest); printf("B"); break;
			}
			break;
		case 3:
			switch(column)
			{
				case 1: rm4scc_draw('C', dest); printf("C"); break;
				case 2: rm4scc_draw('D', dest); printf("D"); break;
				case 3: rm4scc_draw('E', dest); printf("E"); break;
				case 4: rm4scc_draw('F', dest); printf("F"); break;
				case 5: rm4scc_draw('G', dest); printf("G"); break;
				case 0: rm4scc_draw('H', dest); printf("H"); break;
			}
			break;
		case 4:
			switch(column)
			{
				case 1: rm4scc_draw('I', dest); printf("I"); break;
				case 2: rm4scc_draw('J', dest); printf("J"); break;
				case 3: rm4scc_draw('K', dest); printf("K"); break;
				case 4: rm4scc_draw('L', dest); printf("L"); break;
				case 5: rm4scc_draw('M', dest); printf("M"); break;
				case 0: rm4scc_draw('N', dest); printf("N"); break;
			}
			break;
		case 5:
			switch(column)
			{
				case 1: rm4scc_draw('O', dest); printf("O"); break;
				case 2: rm4scc_draw('P', dest); printf("P"); break;
				case 3: rm4scc_draw('Q', dest); printf("Q"); break;
				case 4: rm4scc_draw('R', dest); printf("R"); break;
				case 5: rm4scc_draw('S', dest); printf("S"); break;
				case 0: rm4scc_draw('T', dest); printf("T"); break;
			}
			break;
		case 0:
			switch(column)
			{
				case 1: rm4scc_draw('U', dest); printf("U"); break;
				case 2: rm4scc_draw('V', dest); printf("V"); break;
				case 3: rm4scc_draw('W', dest); printf("W"); break;
				case 4: rm4scc_draw('X', dest); printf("X"); break;
				case 5: rm4scc_draw('Y', dest); printf("Y"); break;
				case 0: rm4scc_draw('Z', dest); printf("Z"); break;
			}
			break;
	}

	printf("'\n");
	/* stop character */
	concat (dest, "3");
}

void royal_plot(int *stack_row, int *matrix_width, char pattern_matrix[], char argument[])
{
	/* Puts RM4SCC into the data matrix */
	char height_pattern[200];
	unsigned int loopey;
	int writer;
	strcpy(height_pattern, "");

	rm4scc(argument, height_pattern);

	writer = 0;
	for(loopey = 0; loopey < strlen(height_pattern); loopey++)
	{
		if((height_pattern[loopey] == '2') || (height_pattern[loopey] == '3'))
		{
			pattern_matrix[writer] = '1';
			pattern_matrix[writer + 1000] = '1';
		}
		pattern_matrix[writer + 2000] = '1';
		if((height_pattern[loopey] == '1') || (height_pattern[loopey] == '3'))
		{
			pattern_matrix[writer + 3000] = '1';
			pattern_matrix[writer + 4000] = '1';
		}
		writer += 2;
	}
	(*stack_row) = 5;
	(*matrix_width) = writer - 1;
}

