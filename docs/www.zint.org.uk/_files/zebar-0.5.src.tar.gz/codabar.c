/* codabar.c - Handles Codabar (AKA NW-7) */

/*  Zebar - A barcode generating program using SDL
    Copyright (C) 2006 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

void concat(char dest[], char source[]);

void codabar(char source[], char dest[])
{ /* The Codabar system consisting of simple substitution */

	unsigned int i;

	/* Error checking */
	if(source[0] == 'a') source[0] = 'A';
	if(source[0] == 'b') source[0] = 'B';
	if(source[0] == 'c') source[0] = 'C';
	if(source[0] == 'd') source[0] = 'D';
	if(source[strlen(source) - 1] == 'a') source[strlen(source) - 1] = 'A';
	if(source[strlen(source) - 1] == 'b') source[strlen(source) - 1] = 'B';
	if(source[strlen(source) - 1] == 'c') source[strlen(source) - 1] = 'C';
	if(source[strlen(source) - 1] == 'd') source[strlen(source) - 1] = 'D';

	for(i = 1; i < (strlen(source) - 2); i++)
	{
		if(!(((source[i] >= 48) && (source[i] <=57)) || (((source[i] == '-') ||
		(source[i] == '$')) || ((source[i] == ':') || (source[i] == '/'))) ||
		((source[i] == '.') || (source[i] == '+'))))
		{
			printf("zebar: Invalid Codabar\n");
			exit(0);
		}
	}

	if(((source[0] != 'A') && (source[0] != 'B')) &&
	((source[0] != 'C') && (source[0] != 'D')))
	{
		printf("zebar: Invalid Codabar\n");
		exit(0);
	}

	if(((source[strlen(source) - 1] != 'A') && (source[strlen(source) - 1] != 'B')) &&
	((source[strlen(source) - 1] != 'C') && (source[strlen(source) - 1] != 'D')))
	{
		printf("zebar: Invalid Codabar\n");
		exit(0);
	}

	for(i = 0; i <= strlen(source); i++)
	{

		switch(source[i])
		{
			case '0': concat (dest, "11111221"); break;
			case '1': concat (dest, "11112211"); break;
			case '2': concat (dest, "11121121"); break;
			case '3': concat (dest, "22111111"); break;
			case '4': concat (dest, "11211211"); break;
			case '5': concat (dest, "21111211"); break;
			case '6': concat (dest, "12111121"); break;
			case '7': concat (dest, "12112111"); break;
			case '8': concat (dest, "12211111"); break;
			case '9': concat (dest, "21121111"); break;
			case '-': concat (dest, "11122111"); break;
			case '$': concat (dest, "11221111"); break;
			case ':': concat (dest, "21111212"); break;
			case '/': concat (dest, "21211121"); break;
			case '.': concat (dest, "21212111"); break;
			case '+': concat (dest, "11212121"); break;
			case 'A': concat (dest, "11221211"); break;
			case 'B': concat (dest, "12121121"); break;
			case 'C': concat (dest, "11121221"); break;
			case 'D': concat (dest, "11122211"); break;
		}
	}
}
