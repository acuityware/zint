/* telepen.c - Handles Telepen */

/*  Zebar - A barcode generating program using SDL
    Copyright (C) 2006 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <stdio.h>

void concat(char dest[], char source[]);
int ctoi(char source);

void telepen_draw(char source, char dest[])
{
	switch(source)
	{
		case 0: concat (dest, "1111111111111111"); break;
		case 1: concat (dest, "1131313111"); break;
		case 2: concat (dest, "33313111"); break;
		case 3: concat (dest, "1111313131"); break;
		case 4: concat (dest, "3111313111"); break;
		case 5: concat (dest, "11333131"); break;
		case 6: concat (dest, "13133131"); break;
		case 7: concat (dest, "111111313111"); break;
		case 8: concat (dest, "31333111"); break;
		case 9: concat (dest, "1131113131"); break;
		case 10: concat (dest, "33113131"); break;
		case 11: concat (dest, "1111333111"); break;
		case 12: concat (dest, "3111113131"); break;
		case 13: concat (dest, "1113133111"); break;
		case 14: concat (dest, "1311133111"); break;
		case 15: concat (dest, "111111113131"); break;
		case 16: concat (dest, "3131113111"); break;
		case 17: concat (dest, "11313331"); break;
		case 18: concat (dest, "333331"); break;
		case 19: concat (dest, "111131113111"); break;
		case 20: concat (dest, "31113331"); break;
		case 21: concat (dest, "1133113111"); break;
		case 22: concat (dest, "1313113111"); break;
		case 23: concat (dest, "1111113331"); break;
		case 24: concat (dest, "31131331"); break;
		case 25: concat (dest, "113111113111"); break;
		case 26: concat (dest, "3311113111"); break;
		case 27: concat (dest, "1111131331"); break;
		case 28: concat (dest, "311111113111"); break;
		case 29: concat (dest, "1113111331"); break;
		case 30: concat (dest, "1311111331"); break;
		case 31: concat (dest, "11111111113111"); break;
		case ' ': concat (dest, "31313311"); break;
		case '!': concat (dest, "1131311131"); break;
		case '\"': concat (dest, "33311131"); break;
		case '#': concat (dest, "1111313311"); break;
		case '$': concat (dest, "3111311131"); break;
		case '%': concat (dest, "11333311"); break;
		case '&': concat (dest, "13133311"); break;
		case '\'': concat (dest, "111111311131"); break;
		case '(': concat (dest, "31331131"); break;
		case ')': concat (dest, "1131113311"); break;
		case '*': concat (dest, "33113311"); break;
		case '+': concat (dest, "1111331131"); break;
		case ',': concat (dest, "3111113311"); break;
		case '-': concat (dest, "1113131131"); break;
		case '.': concat (dest, "1311131131"); break;
		case '/': concat (dest, "111111113311"); break;
		case '0': concat (dest, "3131111131"); break;
		case '1': concat (dest, "1131131311"); break;
		case '2': concat (dest, "33131311"); break;
		case '3': concat (dest, "111131111131"); break;
		case '4': concat (dest, "3111131311"); break;
		case '5': concat (dest, "1133111131"); break;
		case '6': concat (dest, "1313111131"); break;
		case '7': concat (dest, "111111131311"); break;
		case '8': concat (dest, "3113111311"); break;
		case '9': concat (dest, "113111111131"); break;
		case ':': concat (dest, "3311111131"); break;
		case ';': concat (dest, "111113111311"); break;
		case '<': concat (dest, "311111111131"); break;
		case '=': concat (dest, "111311111311"); break;
		case '>': concat (dest, "131111111311"); break;
		case '?': concat (dest, "11111111111131"); break;
		case '@': concat (dest, "3131311111"); break;
		case 'A': concat (dest, "11313133"); break;
		case 'B': concat (dest, "333133"); break;
		case 'C': concat (dest, "111131311111"); break;
		case 'D': concat (dest, "31113133"); break;
		case 'E': concat (dest, "1133311111"); break;
		case 'F': concat (dest, "1313311111"); break;
		case 'G': concat (dest, "1111113133"); break;
		case 'H': concat (dest, "313333"); break;
		case 'I': concat (dest, "113111311111"); break;
		case 'J': concat (dest, "3311311111"); break;
		case 'K': concat (dest, "11113333"); break;
		case 'L': concat (dest, "311111311111"); break;
		case 'M': concat (dest, "11131333"); break;
		case 'N': concat (dest, "13111333"); break;
		case 'O': concat (dest, "11111111311111"); break;
		case 'P': concat (dest, "31311133"); break;
		case 'Q': concat (dest, "1131331111"); break;
		case 'R': concat (dest, "33331111"); break;
		case 'S': concat (dest, "1111311133"); break;
		case 'T': concat (dest, "3111331111"); break;
		case 'U': concat (dest, "11331133"); break;
		case 'V': concat (dest, "13131133"); break;
		case 'W': concat (dest, "111111331111"); break;
		case 'X': concat (dest, "3113131111"); break;
		case 'Y': concat (dest, "1131111133"); break;
		case 'Z': concat (dest, "33111133"); break;
		case '[': concat (dest, "111113131111"); break;
		case '\\': concat (dest, "3111111133"); break;
		case ']': concat (dest, "111311131111"); break;
		case '^': concat (dest, "131111131111"); break;
		case '_': concat (dest, "111111111133"); break;
		case '`': concat (dest, "31311313"); break;
		case 'a': concat (dest, "113131111111"); break;
		case 'b': concat (dest, "3331111111"); break;
		case 'c': concat (dest, "1111311313"); break;
		case 'd': concat (dest, "311131111111"); break;
		case 'e': concat (dest, "11331313"); break;
		case 'f': concat (dest, "13131313"); break;
		case 'g': concat (dest, "11111131111111"); break;
		case 'h': concat (dest, "3133111111"); break;
		case 'i': concat (dest, "1131111313"); break;
		case 'j': concat (dest, "33111313"); break;
		case 'k': concat (dest, "111133111111"); break;
		case 'l': concat (dest, "3111111313"); break;
		case 'm': concat (dest, "111313111111"); break;
		case 'n': concat (dest, "131113111111"); break;
		case 'o': concat (dest, "111111111313"); break;
		case 'p': concat (dest, "313111111111"); break;
		case 'q': concat (dest, "1131131113"); break;
		case 'r': concat (dest, "33131113"); break;
		case 's': concat (dest, "11113111111111"); break;
		case 't': concat (dest, "3111131113"); break;
		case 'u': concat (dest, "113311111111"); break;
		case 'v': concat (dest, "131311111111"); break;
		case 'w': concat (dest, "111111131113"); break;
		case 'x': concat (dest, "3113111113"); break;
		case 'y': concat (dest, "11311111111111"); break;
		case 'z': concat (dest, "331111111111"); break;
		case '{': concat (dest, "111113111113"); break;
		case '|': concat (dest, "31111111111111"); break;
		case '}': concat (dest, "111311111113"); break;
		case '~': concat (dest, "131111111113"); break;
	}
}

void telepen(char source[], char dest[])
{
	unsigned int i, count, check_digit;

	count = 0;

	/* Start character */
	telepen_draw('_', dest);

	for (i=0; i < strlen(source); i++)
	{
		telepen_draw(source[i], dest);
		count += source[i];
	}

	check_digit = 127 - (count % 127);
	telepen_draw(check_digit, dest);
	printf("TELEPEN check digit %d\n", check_digit);

	/* Stop character */
	telepen_draw('z', dest);
}

void telepen_num(char source[], char dest[])
{
	unsigned int i, count, check_digit, glyph;

	count = 0;

	/* Add a leading zero if required */
	if ((strlen(source)%2) != 0)
	{
		unsigned int length;
		char temp[200];

		length = strlen(source);

		strcpy(temp, source);
		source[0] = '0';

		for(i = 0; i <= length; i++)
		{
			source[i + 1] = temp[i];
		}
	}

	/* Start character */
	telepen_draw('_', dest);

	for (i=0; i < strlen(source); i+=2)
	{
		glyph = (10 * ctoi(source[i])) + ctoi(source[i + 1]);
		glyph += 27;
		telepen_draw(glyph, dest);
		count += glyph;
	}

	check_digit = 127 - (count % 127);
	telepen_draw(check_digit, dest);
	printf("TELEPEN check digit %d\n", check_digit);

	/* Stop character */
	telepen_draw('z', dest);
}
