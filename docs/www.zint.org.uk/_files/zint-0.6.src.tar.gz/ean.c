/* ean.c - Handles EAN-2, 5, 8 and 13 */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include "common.h"

static char *EAN2Parity[4] = {"OO", "OE", "EO", "EE"};
static char *EAN5Parity[10] = {"EEOOO", "EOEOO", "EOOEO", "EOOOE", "OEEOO", "OOEEO", "OOOEE", "OEOEO", "OEOOE", "OOEOE"};
static char *EAN13Parity[10] = {"OOOOO", "OEOEE", "OEEOE", "OEEEO", "EOOEE", "EEOOE", "EEEOO", "EOEOE", "EOEEO", "EEOEO"};
static char *EANEven[10] = {"1123", "1222", "2212", "1141", "2311", "1321", "4111", "2131", "3121", "2113"};
static char *EANOdd[10] = {"3211", "2221", "2122", "1411", "1132", "1231", "1114", "1312", "1213", "3112"};

char upc_check(char source[]);
void upca_draw(char source[], char dest[]);
void upca(char source[], char dest[]);
void upce(char source[], char dest[]);
void isbn(char source[], char dest[]);

/* ********************** EAN-2 AND EAN-5 **************** */

void add_on(char source[], char dest[], int mode)
{
	char parity[6];
	unsigned int i, code_type;

	is_sane(NESET, source);
	if(strlen(source) < 2) {
		fprintf(stderr, "error: EAN-2 input '%s' too short\n", source);
		exit(TRUE); }
	if((strlen(source) > 2) && (strlen(source) < 5)) {
		fprintf(stderr, "error: EAN-5 input '%s' too short\n", source);
		exit(TRUE); }
	if(strlen(source) > 5) {
		fprintf(stderr, "error: EAN-5 input '%s' too long\n", source);
		exit(TRUE); }

	/* If an add-on then append with space */
	if (mode != 0)
	{
		concat(dest, "9");
	}

	/* Start character */
	concat (dest, "112");

	/* Determine EAN2 or EAN5 add-on */
	if(strlen(source) == 2)
	{
		code_type = EAN2;
	}
	else
	{
		code_type = EAN5;
	}

	/* Calculate parity for EAN2 */
	if(code_type == EAN2)
	{
		int code_value, parity_bit;

		code_value = (10 * ctoi(source[0])) + ctoi(source[1]);
		parity_bit = code_value%4;
		strcpy(parity, EAN2Parity[parity_bit]);
		printf("EAN2 parity %d\n", parity_bit);
	}

	if(code_type == EAN5)
	{
		int values[6], parity_sum, parity_bit;

		for(i = 0; i < 6; i++)
		{
			values[i] = ctoi(source[i]);
		}

		parity_sum = (3 * (values[0] + values[2] + values[4]));
		parity_sum += (9 * (values[1] + values[3]));

		parity_bit = parity_sum%10;
		strcpy(parity, EAN5Parity[parity_bit]);
		printf("EAN5 parity %d\n", parity_bit);
	}

	for(i = 0; i < strlen(source); i++)
	{
		switch(parity[i]) {
			case 'E': lookup(NESET, EANEven, source[i], dest); break;
			case 'O': lookup(NESET, EANOdd, source[i], dest); break;
		}

		/* Glyph separator */
		if(i != (strlen(source) - 1))
		{
			concat (dest, "11");
		}
	}
}


/* ************************ EAN-13 ****************** */

char ean_check(char source[])
{ /* Calculate the correct check digit for a EAN-13 barcode */
	int i;
	unsigned int h, count, check_digit;

	count = 0;

	h = strlen(source);
	for (i = h - 1; i >= 0; i--)
	{
		count += ctoi(source[i]);

		if (!((i%2) == 0))
		{
			count += 2 * ctoi(source[i]);
		}
	}
	check_digit = 10 - (count%10);
	if (check_digit == 10) { check_digit = 0; }
	printf("  Check Digit %d\n", check_digit);
	return itoc(check_digit);
}

void ean13(char source[], char dest[])
{
	unsigned int length, i, half_way;
	char parity[6];

	is_sane(NESET, source);

	if((strlen(source) > 2) && (strlen(source) < 5)) {
		fprintf(stderr, "error: EAN-13 input '%s' wrong length\n", source);
		exit(TRUE); }

	printf("EAN-13 Parity %c", source[0]);

	/* Add the appropriate check digit */
	length = strlen(source);
	source[length] = ean_check(source);
	source[length + 1] = '\0';

	/* Get parity for first half of the symbol */
	lookup(NESET, EAN13Parity, source[0], parity);

	/* Now get on with the cipher */
	half_way = 7;

	/* start character */
	concat (dest, "111");

	for(i = 1; i <= strlen(source); i++)
	{
		if (i == half_way)
		{
			/* middle character - separates manufacturer no. from product no. */
			/* also inverses right hand characters */
			concat (dest, "11111");
		}

		if(((i > 1) && (i < 7)) && (parity[i - 2] == 'E'))
		{
			lookup(NESET, EANEven, source[i], dest);
		}
		else
		{
			lookup(NESET, EANOdd, source[i], dest);
		}
	}

	/* stop character */
	concat (dest, "111");
}

void ean8(char source[], char dest[])
{ /* Make an EAN-8 barcode when we haven't been given the check digit */
  /* EAN-8 is basically the same as UPC-A but with fewer digits */
	int length;

	is_sane(NESET, source);
	length = strlen(source);
	if(length != 7)
	{
		fprintf(stderr, "error: EAN-8 wrong length '%s'\n", source);
		exit(TRUE);
	}
	source[length] = upc_check(source);
	printf("EAN8 check digit '%c'\n", upc_check(source));
	source[length + 1] = '\0';
	upca_draw(source, dest);
}

void eanx(int mode, char source[], char dest[])
{
	char first_part[13], second_part[13];
	unsigned int latch, reader, writer, with_addon;
	strcpy(first_part, "");
	strcpy(second_part, "");

	with_addon = FALSE;
	latch = FALSE;
	writer = 0;

	for(reader = 0; reader <= strlen(source); reader++)
	{
		if(source[reader] == '+') { with_addon = TRUE; }
	}

	reader = 0;
	if(with_addon) {
		do {
			if(source[reader] == '+') {
				first_part[writer] = '\0';
				latch = TRUE;
				reader++;
				writer = 0;
			}

			if(latch) {
				second_part[writer] = source[reader];
				reader++;
				writer++;
			} else {
				first_part[writer] = source[reader];
				reader++;
				writer++;
			}
		} while (reader <= strlen(source));
	} else {
		strcpy(first_part, source);
	}

	switch(mode)
	{
		case EAN:
			switch(strlen(first_part))
			{
				case 2: add_on(first_part, dest, 0); break;
				case 5: add_on(first_part, dest, 0); break;
				case 7: ean8(first_part, dest); break;
				case 12: ean13(first_part, dest); break;
				default: fprintf(stderr, "EAN string '%s' wrong length\n", first_part); exit(TRUE); break;
			}
			break;
		case UPCA:
			upca(first_part, dest); break;
		case UPCE:
			upce(first_part, dest); break;
		case ISBN:
			isbn(first_part, dest); break;
	}

	switch(strlen(second_part))
	{
		case 0: break;
		case 2: add_on(second_part, dest, 1); break;
		case 5: add_on(second_part, dest, 1); break;
		default: fprintf(stderr, "EAN ADDON string '%s' wrong length\n", second_part); exit(TRUE); break;
	}
}
