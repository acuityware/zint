/* ukpost.c - Handles Royal Mail 4 State Custom Code */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include "common.h"

#define KRSET "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
static char *RoyalValues[36] = {"11", "12", "13", "14", "15", "10", "21", "22", "23", "24", "25", "20", "31", "32", "33", "34", "35", "30", "41", "42", "43", "44", "45", "40", "51", "52", "53", "54", "55", "50", "01", "02", "03", "04", "05", "00"};

static char *RoyalTable[36] = {"3300", "3210", "3201", "2310", "2301", "2211", "3120", "3030", "3021", "2130", "2121", "2031", "3102", "3012", "3003", "2112", "2103", "2013", "1320", "1230", "1221", "0330", "0321", "0231", "1302", "1212", "1203", "0312", "0303", "0213", "1122", "1032", "1023", "0132", "0123", "0033"};

void rm4scc(char source[], char dest[])
{
	/* Handles the 4 State barcodes used in the UK by Royal Mail */
	unsigned int i;
	int top, bottom, row, column, check_digit;
	char values[3], set_copy[38];
	strcpy(set_copy, KRSET);

	top = 0;
	bottom = 0;

	/* start character */
	concat (dest, "1");

	for (i=0; i < strlen(source); i++) {
		lookup(KRSET, RoyalTable, source[i], dest);
		strcpy(values, RoyalValues[posn(KRSET, source[i])]);
		top += ctoi(values[0]);
		bottom += ctoi(values[1]);
	}

	/* Calculate the check digit */
	row = (top % 6) - 1;
	column = (bottom % 6) - 1;
	if(row == -1) { row = 5; }
	if(column == -1) { column = 5; }
	check_digit = (6 * row) + column;
	concat(dest, RoyalTable[check_digit]);
	printf("RM4SCC check digit '%c'\n", set_copy[check_digit]);

	/* stop character */
	concat (dest, "0");
}

void royal_plot(int *stack_row, struct symbol_struct *symbol, char argument[])
{
	/* Puts RM4SCC into the data matrix */
	char height_pattern[200];
	unsigned int loopey;
	int writer;
	strcpy(height_pattern, "");

	to_upper(argument);
	is_sane(KRSET, argument);
	rm4scc(argument, height_pattern);

	writer = 0;
	for(loopey = 0; loopey < strlen(height_pattern); loopey++)
	{
		if((height_pattern[loopey] == '1') || (height_pattern[loopey] == '0'))
		{
			symbol->encoded_data[0][writer] = '1';
			symbol->encoded_data[1][writer] = '1';
		}
		symbol->encoded_data[2][writer] = '1';
		if((height_pattern[loopey] == '2') || (height_pattern[loopey] == '0'))
		{
			symbol->encoded_data[3][writer] = '1';
			symbol->encoded_data[4][writer] = '1';
		}
		writer += 2;
	}
	(*stack_row) = 5;
	symbol->no_of_rows = 5;
	symbol->max_width = writer - 1;
}
