/* upc.c - Handles UPC-A and UPC-E */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include "common.h"

static char *UPCParity0[10] = {"EEEOOO", "EEOEOO", "EEOOEO", "EEOOOE", "EOEEOO", "EOOEEO", "EOOOEE", "EOEOEO", "EOEOOE", "EOOEOE"};
static char *UPCParity1[10] = {"OOOEEE", "OOEOEE", "OOEEOE", "OOEEEO", "OEOOEE", "OEEOOE", "OEEEOO", "OEOEOE", "OEOEEO", "OEEOEO"};

static char *EANEven[10] = {"1123", "1222", "2212", "1141", "2311", "1321", "4111", "2131", "3121", "2113"};
static char *EANOdd[10] = {"3211", "2221", "2122", "1411", "1132", "1231", "1114", "1312", "1213", "3112"};

char upc_check(char source[])
{ /* Calculate the correct check digit for a UPC barcode */
	unsigned int i, count, check_digit;

	count = 0;

	for (i = 0; i < strlen(source); i++)
	{
		count += ctoi(source[i]);

		if ((i%2) == 0)
		{
			count += 2 * (ctoi(source[i]));
		}
	}

	check_digit = 10 - (count%10);
	if (check_digit == 10) { check_digit = 0; }
	return itoc(check_digit);
}

void upca_draw(char source[], char dest[])
{ /* UPC A is usually used for 12 digit numbers, but this function takes a source of any length */
	unsigned int i, half_way;

	half_way = strlen(source) / 2;

	/* start character */
	concat (dest, "111");

	for(i = 0; i <= strlen(source); i++)
	{
		if (i == half_way)
		{
			/* middle character - separates manufacturer no. from product no. */
			/* also inverses right hand characters */
			concat(dest, "11111");
		}

		lookup(NESET, EANOdd, source[i], dest);
	}

	/* stop character */
	concat (dest, "111");
}

void upca(char source[], char dest[])
{ /* Make a UPC A barcode when we haven't been given the check digit */
	int length;

	is_sane(NESET, source);
	length = strlen(source);
	if(length != 11)
	{
		fprintf(stderr, "error: UPC-A wrong length '%s'\n", source);
		exit(TRUE);
	}
	source[length] = upc_check(source);
	printf("UPCA check digit '%c'\n", upc_check(source));
	source[length + 1] = '\0';
	upca_draw(source, dest);
}

void upce(char source[], char dest[])
{ /* UPC E is a zero-compressed version of UPC A */
	unsigned int i, num_system;
	char emode, equivalent[12], check_digit, parity[8], temp[8];

	is_sane(NESET, source);
	if((strlen(source) != 6) && (strlen(source) != 7))
	{
		fprintf(stderr, "error: UPC-E wrong length '%s'\n", source);
		exit(TRUE);
	}

	/* Two number systems can be used - system 0 and system 1 */

	if(strlen(source) == 7)
	{
		switch(source[0])
		{
			case '0':
				num_system = 0;
				break;
			case '1':
				num_system = 1;
				break;
			default:
				num_system = 0;
					fprintf(stderr, "warning: UPC-E number system %c not supported\n", source[0]);
					fprintf(stderr, "warning: (using system 0 instead)\n");
				break;
		}
		strcpy(temp, source);
		for(i = 1; i <= 7; i++)
		{
			source[i - 1] = temp[i];
		}
	}
	else
		num_system = 0;

	/* Expand the zero-compressed UPCE code to make a UPCA equivalent */

	emode = source[5];
	for(i = 0; i < 11; i++)
	{
		equivalent[i] = '0';
	}
	equivalent[1] = source[0];
	equivalent[2] = source[1];
	equivalent[11] = '\0';

	switch(emode)
	{
		case '0':
		case '1':
		case '2':
			equivalent[3] = emode;
			equivalent[8] = source[2];
			equivalent[9] = source[3];
			equivalent[10] = source[4];
			break;
		case '3':
			equivalent[3] = source[2];
			equivalent[9] = source[3];
			equivalent[10] = source[4];
			break;
		case '4':
			equivalent[3] = source[2];
			equivalent[4] = source[3];
			equivalent[10] = source[4];
			break;
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
			equivalent[3] = source[2];
			equivalent[4] = source[3];
			equivalent[5] = source[4];
			equivalent[10] = emode;
			break;
	}

	/* Get the check digit from the expanded UPCA code */

	check_digit = upc_check(equivalent);

	/* Use the number system and check digit information to choose a parity scheme */
	if(num_system == 1) {
		strcpy(parity, UPCParity1[ctoi(check_digit)]); }
	else {
		strcpy(parity, UPCParity0[ctoi(check_digit)]);
	}

	/* Take all this information and make the barcode pattern */
	printf("UPCE System %d, Check Digit '%c'\n", num_system, check_digit);

	/* start character */
	concat (dest, "111");

	for(i = 0; i <= strlen(source); i++) {
		switch(parity[i]) {
			case 'E': lookup(NESET, EANEven, source[i], dest); break;
			case 'O': lookup(NESET, EANOdd, source[i], dest); break;
		}
	}

	/* stop character */
	concat (dest, "111111");
}
