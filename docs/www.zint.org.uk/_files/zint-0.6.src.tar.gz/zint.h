/* zint.h - Headers for all supported symbologies */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

/* PNG Plotting Routine */

void png_plot(struct symbol_struct *symbol);

/* 1D Barcode Encoders */

void eanx(int mode, char source[], char dest[]); /* EAN system barcodes */
void c39(char source[], char dest[]); /* Code 3 from 9 (or Code 39) */
void ec39(char source[], char dest[]); /* Extended Code 3 from 9 (or Code 39+) */
void codabar(char source[], char dest[]); /* Codabar - a simple substitution cipher */
void two_of_five(char source[], char dest[]); /* Interlaced 2 of 5 */
void itf14(char source[], char dest[]); /* ITF-14 */
void c93(char source[], char dest[]); /* Code 93 - a re-working of Code 39+, generates 2 check digits */
void c128(char source[], char dest[]); /* Code 128 */
void ean128(char source[], char dest[]); /* EAN-128 */
void c128b(char source[], char dest[]); /* Code 128 Subset B */
void code_two_of_five(char source[], char dest []); /* Code 2 of 5 (Non-Interlaced) */
void code_11(char source[], char dest[]); /* Code 11 */
void msi_plessey(char source[], char dest[]); /* MSI Plessey without check digit */
void msi_plessey_mod10(char source[], char dest[]); /* MSI with check as on Barcode Island */
void msi_plessey_mod1010(char source[], char dest[]); /* MSI with two checks as Barcode Island */
void telepen(char source[], char dest[]); /* Telepen ASCII */
void telepen_num(char source[], char dest[]); /* Telepen Numeric */
void plessey(char source[], char dest[]); /* Plessey Code */
void pharma_one(char source[], char dest[]); /* Pharmacode One Track */

/* 2D Barcode Encoders */

void pharma_two(int *stack_row, struct symbol_struct *symbol, char argument[]);
	/* Pharmacode Two Track */
void post_plot(int *stack_row, struct symbol_struct *symbol, char argument[]);
	/* Postnet */
void royal_plot(int *stack_row, struct symbol_struct *symbol, char argument[]);
	/* RM4SCC */
void australia_post(int *stack_row, struct symbol_struct *symbol, char argument[]);
void australia_reply_paid(int *stack_row, struct symbol_struct *symbol, char argument[]);
void australia_routing(int *stack_row, struct symbol_struct *symbol, char argument[]);
void australia_redirection(int *stack_row, struct symbol_struct *symbol, char argument[]);
	/* Australia Post 4-state */
void code16k(int *stack_row, struct symbol_struct *symbol, char argument[]);
	/* Code16k consisting of stacked Code128s */
