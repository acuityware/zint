/* code128.c - Handles Code 128 */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include "common.h"

static char *C128Table[107] = {"212222", "222122", "222221", "121223", "121322", "131222", "122213",
	"122312", "132212", "221213", "221312", "231212", "112232", "122312", "122231", "113222",
	"123122", "123221", "223211", "221132", "221231", "213212", "223112", "312131", "311222",
	"321122", "321221", "312212", "322112", "322211", "212123", "213321", "232121", "111323",
	"131123", "131321", "112313", "132113", "132311", "211313", "231113", "231311", "112133",
	"112331", "132131", "113123", "113321", "133121", "313121", "211331", "231131", "213113",
	"213311", "213131", "311123", "311321", "331121", "312113", "312311", "332111", "314111",
	"221411", "431111", "111224", "111422", "121124", "121421", "141122", "141221", "112214",
	"112412", "122114", "122411", "142112", "142211", "241211", "221114", "413111", "241112",
	"134111", "111242", "121142", "121241", "114212", "124112", "124211", "411212", "421112",
	"421211", "212141", "214121", "412121", "111143", "111341", "131141", "114113", "114311",
	"411113", "411311", "113141", "114131", "311141", "411131", "211412", "211214", "211232",
	"2331112"};

void c128_set_a(char source, char dest[], unsigned int values[], unsigned int *bar_chars)
{ /* Translate Code 128 Set A characters into barcodes */
  /* This set handles all control characters NULL to US */

	concat(dest, C128Table[source + 64]);
	values[(*bar_chars)] = source + 64;
	(*bar_chars)++;
}

void c128_set_b(char source, char dest[], unsigned int values[], unsigned int *bar_chars)
{ /* Translate Code 128 Set B characters into barcodes */
  /* This set handles all characters which are not part of long numbers and not control characters */

	concat(dest, C128Table[source - 32]);
	values[(*bar_chars)] = source - 32;
	(*bar_chars)++;
}

void c128_set_c(char source_a, char source_b, char dest[], unsigned int values[], unsigned int *bar_chars)
{ /* Translate Code 128 Set C characters into barcodes */
  /* This set handles long numbers in a compressed form */
	int weight;

	weight = (10 * ctoi(source_a)) + ctoi(source_b);
	concat(dest, C128Table[weight]);
	values[(*bar_chars)] = weight;
	(*bar_chars)++;
}

void code_128(char source[], char dest[], int mode)
{ /* Handle Code 128 and EAN 128 barcodes */
	unsigned int i, j, k, e_count, values[200], bar_characters, read, total_sum;
	char set[200];

	j = 0;
	e_count = 0;
	bar_characters = 0;

	/* First figure out what code sets to use - there are three: A, B, and C */
	for(i = 0; i < strlen(source); i++)
	{

	/* In the following I have made Zint use code set B whenever there is a choice
	between using A or B. Whilst this doesn't always ensure the shortest and neatest
	barcode, I think that code A is likely to be needed so rarely that this shortcut
	is justified: The vast majority of barcodes will only need to use sets B and C. */

		if(source[i] < 32) {
			/* Everthing from NULL to US must be code set A */
			set[i] = 'A';
			if((e_count % 2) == 1) {
				/* If there are an odd number of numbers (0-9), the last one
				cannot be set C */
				set[i - 1] = 'A';
			}
			e_count = 0;
		}
		if((source[i] > 31) && (source[i] < 48)) {
			/* Everything from SPACE to / can be code set A or B  - Use B */
			set[i] = 'B';
			if((e_count % 2) == 1) {
				set[i - 1] = 'B';
			}
			e_count = 0;
		}
		if((source[i] > 47) && (source[i] < 58)) {
			/* Numbers from 0 to 9 can be code set A, B or C */
			e_count ++;
			if(e_count > 5) {
				/* If there are more than six of them they should be C */
				if(i != (strlen(source) - 1)) {
					for(k = 5; k > 0; k--) {
						set[i - k] = 'C';
					}
					set[i] = 'C';
				}
				else
				{
					/* Ah! But be careful if it's the last character */
					if((e_count % 2) == 1) {
						set[i] = 'B';
					}
					else
					{
						for(k = 5; k > 0; k--) {
							set[i - k] = 'C';
						}
						set[i] = 'C';
					}
				}
			}
			else
			{
				/* Otherwise they can be A or B  - Use B */
				set[i] = 'B';
			}
		}
		if(source[i] > 57) {
			/* Everything from : to _ can be code set A or B - Use B
			Everything from ` to DELETE must be code set B */
			set[i] = 'B';
			if((e_count % 2) == 1) {
				set[i - 1] = 'B';
			}
			e_count = 0;
		}
	}
	set[i] = '\0';

	if(mode == 2) {
		/* The user has specified that code set B be used - but this makes no
		   sense if the characters can only be encoded using set A, so this really means
		   use set B in preference to set C */
		for(i = 0; i < strlen(source); i++) {
			if(set[i] == 'C') { set[i] = 'B'; }
		}
	}

	/* So now we know what start character to use */
	switch(set[0])
	{
		case 'A': /* Start A */
			concat(dest, C128Table[103]);
			values[0] = 103;
			break;
		case 'B': /* Start B */
			concat(dest, C128Table[104]);
			values[0] = 104;
			break;
		case 'C': /* Start C */
			concat(dest, C128Table[105]);
			values[0] = 105;
			break;
	}
	bar_characters++;

	/* If generating an EAN128 barcode add an extra character here */
	if(mode == 1) {
		concat(dest, C128Table[102]);
		values[1] = 102;
		bar_characters++;
	}

	/* Deal with the gritty middle of the barcode ! */
	read = 0;
	do {

		if((read != 0) && (set[read] != set[read - 1]))
		{
			switch(set[read])
			{
				case 'A': concat(dest, C128Table[101]);
					values[bar_characters] = 101;
					bar_characters++;
					break;
				case 'B': concat(dest, C128Table[100]);
					values[bar_characters] = 100;
					bar_characters++;
					break;
				case 'C': concat(dest, C128Table[99]);
					values[bar_characters] = 99;
					bar_characters++;
					break;
			}
		}

		switch(set[read])
		{
			case 'A': c128_set_a(source[read], dest, values, &bar_characters);
				read++;
				break;
			case 'B': c128_set_b(source[read], dest, values, &bar_characters);
				read++;
				break;
			case 'C': c128_set_c(source[read], source[read + 1], dest, values, &bar_characters);
				read += 2;
				break;
		}
	} while (read < strlen(source));

	/* Calculate check digit */
	total_sum = 0;
	for(i = 0; i < bar_characters; i++)
	{
		if(i > 0)
		{
			values[i] *= i;
		}
		total_sum += values[i];
	}

	/* Draw check digit */
	concat(dest, C128Table[total_sum%103]);
	printf("CODE128 Check Digit %d\n", total_sum%103);

	/* Stop character */
	concat(dest, C128Table[106]);
}

void c128(char source[], char dest[])
{
	prescan(source);
	code_128(source, dest, 0);
}

void c128b(char source[], char dest[])
{
	prescan(source);
	code_128(source, dest, 2);
}

void ean128(char source[], char dest[])
{
	prescan(source);
	code_128(source, dest, 1);
}
