/* zint.c - Command line handling routines for Zint */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common.h"
#include "zint.h"

void add_to_stack(int mode, int *stack_row, struct symbol_struct *symbol, char argument[])
{
	char width_pattern[500];
	unsigned int reader, current_width, writer;
	int looper, flip_flop;

	strcpy(width_pattern, "");

	if((*stack_row) == 0) { symbol->symbology_type = ONEDIM; }
	if((*stack_row) > 0) { symbol->symbology_type = STACKED; }

	switch(mode)
	{
		case UPCA: eanx(mode, argument, width_pattern); break;
		case UPCE: eanx(mode, argument, width_pattern); break;
		case EAN: eanx(mode, argument, width_pattern); break;
		case EAN128: ean128(argument, width_pattern); break;
		case CODE39: c39(argument, width_pattern); break;
		case EXCODE39: ec39(argument, width_pattern); break;
		case CODABAR: codabar(argument, width_pattern); break;
		case I2OF5: two_of_five(argument, width_pattern); break;
		case CODE93: c93(argument, width_pattern); break;
		case ISBN: eanx(mode, argument, width_pattern); break;
		case CODE128: c128(argument, width_pattern); break;
		case CODE128B: c128b(argument, width_pattern); break;
		case CODE25: code_two_of_five(argument, width_pattern); break;
		case CODE11: code_11(argument, width_pattern); break;
		case MSI: msi_plessey(argument, width_pattern); break;
		case MSI10: msi_plessey_mod10(argument, width_pattern); break;
		case MSI1010: msi_plessey_mod1010(argument, width_pattern); break;
		case TELEPEN: telepen(argument, width_pattern); break;
		case TELENUM: telepen_num(argument, width_pattern); break;
		case PHARMA: pharma_one(argument, width_pattern); break;
		case PLESSEY: plessey(argument, width_pattern); break;
		case ITF14: itf14(argument, width_pattern); break;
	}

	writer = 0;
	flip_flop = 1;
	for (reader = 0; reader < strlen(width_pattern); reader++) {
		for(looper = 0; looper < ctoi(width_pattern[reader]); looper++) {
			if(flip_flop == 1) {
				symbol->encoded_data[(*stack_row)][writer] = '1';
				writer++; }
			else {
				symbol->encoded_data[(*stack_row)][writer] = '0';
				writer++; }
		}
		if(flip_flop == 0) { flip_flop = 1; } else { flip_flop = 0; }
	}

	current_width = writer;
	if(current_width > symbol->max_width) { symbol->max_width = current_width; }
}

void plot_2d(int mode, int *stack_row, struct symbol_struct *symbol, char argument[])
{
	switch(mode)
	{
		case POSTNET: post_plot(stack_row, symbol, argument);
			symbol->symbology_type = TWOTRACK; break;
		case RM4SCC: royal_plot(stack_row, symbol, argument);
			symbol->symbology_type = FOURSTATE; break;
		case AUSPOST: australia_post(stack_row, symbol, argument);
			symbol->symbology_type = FOURSTATE; break;
		case AUSREPLY: australia_reply_paid(stack_row, symbol, argument);
			symbol->symbology_type = FOURSTATE; break;
		case AUSROUTE: australia_routing(stack_row, symbol, argument);
			symbol->symbology_type = FOURSTATE; break;
		case AUSREDIRECT: australia_redirection(stack_row, symbol, argument);
			symbol->symbology_type = FOURSTATE; break;
		case CODE16K: code16k(stack_row, symbol, argument);
			symbol->symbology_type = SIXTEEN; break;
		case PHARMA2: pharma_two(stack_row, symbol, argument);
			symbol->symbology_type = TWOTRACK; break;
	}
}

void encode(int mode, int *stack_row, struct symbol_struct *symbol, char argument[])
{
	switch(mode)
	{
		case UPCA:
		case EAN:
		case EAN128:
		case UPCE:
		case CODE39:
		case EXCODE39:
		case CODABAR:
		case I2OF5:
		case CODE93:
		case ISBN:
		case CODE128:
		case CODE128B:
		case CODE25:
		case CODE11:
		case MSI:
		case MSI10:
		case MSI1010:
		case TELEPEN:
		case TELENUM:
		case PLESSEY:
		case PHARMA:
		case ITF14:
			if((*stack_row) <= 16) {
				add_to_stack(mode, stack_row, symbol, argument);
				(*stack_row)++;
				symbol->no_of_rows++;
			}
			break;
		default:
			if((*stack_row) == 0) {
				plot_2d(mode, stack_row, symbol, argument);
			}
			break;
	}
}

int main(int argc, char *argv[])
{
	struct symbol_struct symbol;
	int i, mode, stack_row, colnum, seclevel, lock, next;
	unsigned int l, done;
	char infront[10];
	char inback[10];
	unsigned char inputfile[256];

	if(argc == 1) {
		printf("zint v0.7 Copyright Robin Stuart 2007\n");
		printf("see \\doc\\index.html for usage information\n");
		return 0;
	}
	
	done = FALSE;
	stack_row = 0;
	symbol.no_of_rows = 0;
	symbol.max_width = 0;
	for(i = 0; i < 16; i++) { for(l = 0; l <= 1000; l++) { symbol.encoded_data[i][l] = '0'; } }

	/* Set the defaults - these values overwritten if specified by user */
	symbol.bind = FALSE;
	symbol.box = FALSE;
	symbol.border_width = 12;
	symbol.whitespace_width = 30;
	strcpy(symbol.outfile, "out.png");
	strcpy(infront, "000000");
	strcpy(inback, "ffffff");
	symbol.user_height = 0; /* Note: this does not mean a height of 0 pixels but that the
				   height has not been specified by the user (default is 200px) */
	mode = CODE128; 
	seclevel = -1;
	colnum = 0;
	strcpy(inputfile, "");
	lock = FALSE; /* This locks out the computation of additional barcode sequences if
			 the barcode type selected is one which cannot be stacked and if the
			 encoding has already been completed */

	next = 1;
	while (next < argc) {
		i = next;
		done = FALSE;
		if (!strcmp(argv[i], "--upca")) {
			mode = UPCA; done = TRUE;
		}
		if (!strcmp(argv[i], "--ean")) {
			mode = EAN; done = TRUE;
		}
		if (!strcmp(argv[i], "--upce")) {
			mode = UPCE; done = TRUE;
		}
		if (!strcmp(argv[i], "--c39")) {
			mode = CODE39; done = TRUE;
		}
		if (!strcmp(argv[i], "--ec39")) {
			mode = EXCODE39; done = TRUE;
		}
		if (!strcmp(argv[i], "--codabar")) {
			mode = CODABAR; done = TRUE;
		}
		if (!strcmp(argv[i], "--i25")) {
			mode = I2OF5; done = TRUE;
		}
		if (!strcmp(argv[i], "--c93")) {
			mode = CODE93; done = TRUE;
		}
		if (!strcmp(argv[i], "--isbn")) {
			mode = ISBN; done = TRUE;
		}
		if (!strcmp(argv[i], "--c128")) {
			mode = CODE128; done = TRUE;
		}
		if (!strcmp(argv[i], "--ean128")) {
			mode = EAN128; done = TRUE;
		}
		if (!strcmp(argv[i], "--c128b")) {
			mode = CODE128B; done = TRUE;
		}
		if (!strcmp(argv[i], "--c25")) {
			mode = CODE25; done = TRUE;
		}
		if (!strcmp(argv[i], "--c11")) {
			mode = CODE11; done = TRUE;
		}
		if (!strcmp(argv[i], "--msi")) {
			mode = MSI; done = TRUE;
		}
		if (!strcmp(argv[i], "--msi10")) {
			mode = MSI10; done = TRUE;
		}
		if (!strcmp(argv[i], "--msi1010")) {
			mode = MSI1010; done = TRUE;
		}
		if (!strcmp(argv[i], "--telepen")) {
			mode = TELEPEN; done = TRUE;
		}
		if (!strcmp(argv[i], "--telenum")) {
			mode = TELENUM; done = TRUE;
		}
		if (!strcmp(argv[i], "--plessey")) {
			mode = PLESSEY; done = TRUE;
		}
		if (!strcmp(argv[i], "--postnet")) {
			mode = POSTNET; done = TRUE;
		}
		if (!strcmp(argv[i], "--royal")) {
			mode = RM4SCC; done = TRUE;
		}
		if (!strcmp(argv[i], "--auspost")) {
			mode = AUSPOST; done = TRUE;
		}
		if (!strcmp(argv[i], "--auspost_reply")) {
			mode = AUSREPLY; done = TRUE;
		}
		if (!strcmp(argv[i], "--auspost_routing")) {
			mode = AUSROUTE; done = TRUE;
		}
		if (!strcmp(argv[i], "--auspost_redirect")) {
			mode = AUSREDIRECT; done = TRUE;
		}
		if (!strcmp(argv[i], "--code16k")) {
			mode = CODE16K; done = TRUE;
		}
		if (!strcmp(argv[i], "--pharma")) {
			mode = PHARMA; done = TRUE;
		}
		if (!strcmp(argv[i], "--pharma2")) {
			mode = PHARMA2; done = TRUE;
		}
		if (!strcmp(argv[i], "--itf14")) {
			mode = ITF14; done = TRUE;
		}
		if (!strcmp(argv[i], "--pdf417")) {
			mode = PDF417; done = TRUE;
		}
		if (!strcmp(argv[i], "--bind")) {
			symbol.bind = TRUE; done = TRUE;
		}
		if (!strcmp(argv[i], "--box")) {
			symbol.box = TRUE; done = TRUE;
		}
		if (done == TRUE) { next = i + 1; }
		if (!strcmp(argv[i], "-o")) {
			strcpy(symbol.outfile, argv[i + 1]);
			next = i + 2;
			done = TRUE;
		}
		if (!strcmp(argv[i], "-i")) {
			strcpy(inputfile, argv[i + 1]);
			next = i + 2;
			done = TRUE;
		}
		if (!strcmp(argv[i], "--fg")) {
			strcpy(infront, argv[i + 1]);
			next = i + 2;
			done = TRUE;
		}
		if (!strcmp(argv[i], "--bg")) {
			strcpy(inback, argv[i + 1]);
			next = i + 2;
			done = TRUE;
		}
		if (!strcmp(argv[i], "--border")) {
			symbol.border_width = atoi(argv[i + 1]);
			next = i + 2;
			done = TRUE;
		}
		if (!strcmp(argv[i], "--whitesp")) {
			symbol.whitespace_width = atoi(argv[i + 1]);
			next = i + 2;
			done = TRUE;
		}
		if (!strcmp(argv[i], "--height")) {
			symbol.user_height = atoi(argv[i + 1]);
			next = i + 2;
			done = TRUE;
		}
		if (!strcmp(argv[i], "--cols")) {
			colnum = atoi(argv[i + 1]);
			next = i + 2;
			done = TRUE;
		}
		if (!strcmp(argv[i], "--secure")) {
			seclevel = atoi(argv[i + 1]);
			next = i + 2;
			done = TRUE;
		}
		if ((done == FALSE) && (lock == FALSE)) { /* If not a switch then it must be data */
			if(mode != PDF417) {
				/* these symbologies require input at the command prompt */
				encode(mode, &stack_row, &symbol, argv[i]);
				if(mode == CODE16K) { lock = TRUE; }
				if(mode == POSTNET) { lock = TRUE; }
				if(mode == RM4SCC) { lock = TRUE; }
				if(mode == AUSPOST) { lock = TRUE; }
				if(mode == AUSREPLY) { lock = TRUE; }
				if(mode == AUSREDIRECT) { lock = TRUE; }
				if(mode == AUSROUTE) { lock = TRUE; }
			} else {
				/* this symbology can input from a file */
				/* but file input takes priority */
				if(strlen(inputfile) == 0) {
					pdf417enc(seclevel, colnum, &symbol, argv[i], inputfile);
					lock = TRUE;
				}
			}
			next = i + 1;
		}
	}

	if((mode == PDF417) && (lock == FALSE)) {
		/* input from a file is required */
		pdf417enc(seclevel, colnum, &symbol, "", inputfile);
	}
	
	if(symbol.symbology_type == SIXTEEN) { symbol.bind = TRUE; }

	colourtag(infront, symbol.fgcolour); /* usually black */
	colourtag(inback, symbol.bgcolour); /* usually white */

	png_plot(&symbol);

	return 0;
}
