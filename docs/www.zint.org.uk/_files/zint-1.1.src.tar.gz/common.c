/* common.c - Contains functions needed for a number of barcodes */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include "common.h"

#define SSET	"0123456789ABCDEF"

void concat(char dest[], char source[])
{ /* Concatinates dest[] with the contents of source[], copying /0 as well */
	unsigned int i, j;

	j = strlen(dest);
	for(i = 0; i <= strlen(source); i++) {
		dest[i + j] = source[i]; }
}

int ctoi(char source)
{ /* Converts a character 0-9 to its equivalent integer value */
	return (source - '0');
}

char itoc(int source)
{ /* Converts an integer value to its hexadecimal character */
	if ((source >= 0) && (source <= 9)) {
		return ('0' + source); }
	else {
		return ('A' + (source - 10)); }
}

void to_upper(char source[])
{ /* Converts lower case characters to upper case in a string source[] */
	unsigned int i;

	for (i = 0; i < strlen(source); i++) {
		if ((source[i] >= 'a') && (source[i] <= 'z')) {
			source [i] = (source[i] - 'a') + 'A'; }
	}
}

void is_sane(char test_string[], char source[])
{ /* Verifies that a string only uses valid characters */
	unsigned int i, j, latch;

	for(i = 0; i < strlen(source); i++) {
		latch = FALSE;
		for(j = 0; j < strlen(test_string); j++) {
			if (source[i] == test_string[j]) { latch = TRUE; } }
		if (!(latch)) { 
			fprintf(stderr, "error: malformed argument '%s'\n", source);
			exit(TRUE); }
	}
}

int posn(char set_string[], char data)
{ /* Returns the position of data in set_string */
	unsigned int i;

	for(i = 0; i < strlen(set_string); i++) {
		if (data == set_string[i]) { return i; } }
	return 0;
}

void lookup(char set_string[], char *table[], char data, char dest[])
{ /* Replaces huge switch statements for looking up in tables */
	unsigned int i;

	for(i = 0; i < strlen(set_string); i++) {
		if (data == set_string[i]) { concat(dest, table[i]); } }
}

void colourtag(char hex[], unsigned char rgb[])
{
	unsigned int red = 0, green = 0, blue = 0, temp, reader;

	if(strlen(hex) != 6) {
		fprintf(stderr, "malformed colour tag\n");
		exit(TRUE);
	}

	to_upper(hex);
	is_sane(SSET, hex);

	for(reader = 0; reader < 7; reader++) {
		temp = posn(SSET, hex[reader]);
		switch (reader) {
			case 0: red += (16 * temp); break;
			case 1: red += temp; break;
			case 2: green += (16 * temp); break;
			case 3: green += temp; break;
			case 4: blue += (16 * temp); break;
			case 5: blue += temp; break;
		}
	}

	rgb[0] = red;
	rgb[1] = green;
	rgb[2] = blue;
}

void prescan(char input[])
{
	char output[1000];
	int reader = 0;
	int writer = 0;

	do {
		if(input[reader] == '|') {
			switch(input[reader + 1]) {
				case 'h': output[writer] = 1; break; /* SOH (start of heading) */
				case 'S': output[writer] = 2; break; /*  STX (start of text) */
				case 'E': output[writer] = 3; break; /*  ETX (end of text) */
				case 'z': output[writer] = 4; break; /*  EOT (end of transmission) */
				case 'q': output[writer] = 5; break; /*  ENQ (enquiry) */
				case 'k': output[writer] = 6; break; /*  ACK (acknowledge) */
				case 'b': output[writer] = 7; break; /*  BEL (bell) */
				case 'B': output[writer] = 8; break; /*  BS  (backspace) */
				case 't': output[writer] = 9; break; /*  TAB (horizontal tab) */
				case 'n': output[writer] = 10; break; /*  LF  (new line / line feed) */
				case 'v': output[writer] = 11; break; /*  VT  (vertical tab) */
				case 'p': output[writer] = 12; break; /*  FF  (form feed / new page) */
				case 'c': output[writer] = 13; break; /*  CR  (carriage return) */
				case 'o': output[writer] = 14; break; /*  SO  (shift out) */
				case 'i': output[writer] = 15; break; /*  SI  (shift in) */
				case 'L': output[writer] = 16; break; /*  DLE (data link escape) */
				case '1': output[writer] = 17; break; /*  DC1 (device control 1) */
				case '2': output[writer] = 18; break; /*  DC2 (device control 2) */
				case '3': output[writer] = 19; break; /*  DC3 (device control 3) */
				case '4': output[writer] = 20; break; /*  DC4 (device control 4) */
				case 'N': output[writer] = 21; break; /*  NAK (negative acknowledge) */
				case 'I': output[writer] = 22; break; /*  SYN (synchronous idle) */
				case 'T': output[writer] = 23; break; /*  ETB (end of trans. block) */
				case 'x': output[writer] = 24; break; /*  CAN (cancel) */
				case 'm': output[writer] = 25; break; /*  EM  (end of medium) */
				case 's': output[writer] = 26; break; /*  SUB (substitute) */
				case 'e': output[writer] = 27; break; /*  ESC (escape) */
				case 'f': output[writer] = 28; break; /*  FS  (file separator) */
				case 'g': output[writer] = 29; break; /*  GS  (group separator) */
				case 'r': output[writer] = 30; break; /*  RS  (record separator) */
				case 'u': output[writer] = 31; break; /*  US  (unit separator) */
				case 'Q': output[writer] = '!'; break; /* exclamation */
				case 'W': output[writer] = '\"'; break; /* double speech mark */
				case 'K': output[writer] = '\''; break; /* single speech mark */
				case 'U': output[writer] = '*'; break; /* asterisk */
				case 'M': output[writer] = '?'; break; /* question mark */
				case '|': output[writer] = '|'; break; /* bar */
				case 'd': output[writer] = 127; break; /*  DEL (delete) */
			}
			writer++;
			reader += 2;
		} else {
			output[writer] = input[reader];
			writer++;
			reader++;
		}
	} while (reader <= strlen(input));

	for (reader = 0; reader <= strlen(output); reader++) {
		input[reader] = output[reader];
	}
}
