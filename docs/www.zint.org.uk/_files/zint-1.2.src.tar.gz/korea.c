/* korea.c - Handles Korean Postal Authority Code and Flattermarken */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include "common.h"

static char *KoreaTable[10] = {"1313150613", "0713131313", "0417131313", "1506131313",
	"0413171313", "17171313", "1315061313", "0413131713", "13171713", "13171713"};
static char *FlatTable[10] = {"0504", "18", "0117", "0216", "0315", "0414", "0513", "0612", "0711",
	"0810"};

void korea(char source[], char dest[])
{ /* Korean Postal Authority */
  /* This code behaves in the same way as TBarCode - but is not correct because it uses the same
	glyph for numbers 8 and 9 */

	int total, h, loop, check;

	h = strlen(source);
	is_sane(NESET, source);
	if(h != 6) { fprintf(stderr, "Invalid length KPA '%s'\n", source);
		exit(TRUE);
	}

	total = 0;
	for(loop = 0; loop < 6; loop++) {
		total += ctoi(source[loop]);
	}
	check = 10 - (total % 10);

	for(loop = 5; loop >= 0; loop--) {
		lookup(NESET, KoreaTable, source[loop], dest);
	}
	lookup(NESET, KoreaTable, itoc(check), dest);
	printf("KOREA check digit %d\n", check);
}

void flattermarken(char source[], char dest[])
{ /* Flattermarken - Not really a barcode symbology and (in my opinion) probably not much use
	but it's supported by TBarCode so it's supported by Zint! */
	int loop;
	
	is_sane(NESET, source);
	
	for(loop = 0; loop < strlen(source); loop++) {
		lookup(NESET, FlatTable, source[loop], dest);
	}
}
