/* code16k.c - Handles Code 16k stacked symbology */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

/* Some of this code is copied straight from code128.c, it also uses the Code 128 tables */

/* up to 77 characters or 154 numbers */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include "common.h"

static char *C128Table[107] = {"212222", "222122", "222221", "121223", "121322", "131222", "122213",
	"122312", "132212", "221213", "221312", "231212", "112232", "122312", "122231", "113222",
	"123122", "123221", "223211", "221132", "221231", "213212", "223112", "312131", "311222",
	"321122", "321221", "312212", "322112", "322211", "212123", "213321", "232121", "111323",
	"131123", "131321", "112313", "132113", "132311", "211313", "231113", "231311", "112133",
	"112331", "132131", "113123", "113321", "133121", "313121", "211331", "231131", "213113",
	"213311", "213131", "311123", "311321", "331121", "312113", "312311", "332111", "314111",
	"221411", "431111", "111224", "111422", "121124", "121421", "141122", "141221", "112214",
	"112412", "122114", "122411", "142112", "142211", "241211", "221114", "413111", "241112",
	"134111", "111242", "121142", "121241", "114212", "124112", "124211", "411212", "421112",
	"421211", "212141", "214121", "412121", "111143", "111341", "131141", "114113", "114311",
	"411113", "411311", "113141", "114131", "311141", "411131", "211412", "211214", "211232",
	"2331112"};

static char *C16KStart[16] = {"32111", "22211", "21221", "14111", "11321", "12311", "11141", "31121",
	"32111", "22211", "21221", "14111", "11321", "12311", "11141", "31121"};

static char *C16KStop[16] = {"3211", "2221", "2122", "1411", "1132", "1231", "1114", "3112", "1132",
	"1231", "1114", "3112", "3211", "2221", "2122", "1411"};

void c128_set_a(char source, char dest[], unsigned int values[], unsigned int *bar_chars);
void c128_set_b(char source, char dest[], unsigned int values[], unsigned int *bar_chars);
void c128_set_c(char source_a, char source_b, char dest[], unsigned int values[], unsigned int *bar_chars);

void code16k_row(int row_number, int total_rows, char source[], char last_row_mode, char modes[], char dest[], unsigned int values[], unsigned int *bar_characters)
{
	unsigned int reader;
	reader = 0;

	/* Row start character */
	concat(dest, C16KStart[row_number - 1]);

	/* In the mode[] string the following characters are used:
	   A - Use Code Set A
	   B - Use Code Set B
	   C - Use Code Set C
	   P - Padding */

	if(modes[0] != last_row_mode)
	{
		if(row_number == 1)
		{
			/* Adding the 'start symbol' - first character on first row */

			/* "The start symbol is calculated to be 7 times the number of rows-2,
			   plus the mode. [7(r-2)+m]." (from www.gomaro.ch) */

			switch(modes[0])
			{
				case 'A': concat(dest, C128Table[7 * (total_rows - 2)]);
					values[(*bar_characters)] = 7 * (total_rows - 2);
					(*bar_characters)++;
					break;
				case 'B': concat(dest, C128Table[(7 * (total_rows - 2)) + 1]);
					values[(*bar_characters)] = (7 * (total_rows - 2)) + 1;
					(*bar_characters)++;
					break;
				case 'C': concat(dest, C128Table[(7 * (total_rows - 2)) + 2]);
					values[(*bar_characters)] = (7 * (total_rows - 2)) + 2;
					(*bar_characters)++;
					break;
			}
		}
		else
		{
			/* If character set changes at the beginning of a row */
			switch(modes[0])
			{
				case 'A': concat(dest, C128Table[101]);
					values[(*bar_characters)] = 101;
					(*bar_characters)++;
					break;
				case 'B': concat(dest, C128Table[100]);
					values[(*bar_characters)] = 100;
					(*bar_characters)++;
					break;
				case 'C': concat(dest, C128Table[99]);
					values[(*bar_characters)] = 99;
					(*bar_characters)++;
					break;
				case 'P': concat(dest, C128Table[103]);
					/* values[(*bar_characters)] = 103;
					(*bar_characters)++; */
					break;
			}
		}
	}

	do
	{
		/* If mode character set changes in the middle of a row */
		if((reader != 0) && (modes[reader] != modes[reader - 1]))
		{
			switch(modes[reader])
			{
				case 'A': concat(dest, C128Table[101]);
					values[(*bar_characters)] = 101;
					(*bar_characters)++;
					break;
				case 'B': concat(dest, C128Table[100]);
					values[(*bar_characters)] = 100;
					(*bar_characters)++;
					break;
				case 'C': concat(dest, C128Table[99]);
					values[(*bar_characters)] = 99;
					(*bar_characters)++;
					break;
			}
		}

		/* Deals with the actual data */
		switch(modes[reader])
		{
			case 'A': c128_set_a(source[reader], dest, values, bar_characters); reader++; break;
			case 'B': c128_set_b(source[reader], dest, values, bar_characters); reader++; break;
			case 'C': c128_set_c(source[reader], source[reader + 1], dest, values, bar_characters); reader += 2; break;
			case 'P': concat(dest, C128Table[103]);
				values[(*bar_characters)] = 103;
				(*bar_characters)++;
				reader++;
				break;
		}
	}
	while (reader < strlen(modes)); 

	/* Row stop character */
	concat(dest, C16KStop[row_number - 1]);
}

int get_code16k_rows(char mode_pattern[])
{
	/* Calculates how many rows the barcode is going to need */
	unsigned int glyph_count, reader;
	char last_mode;
	int row_count;

	glyph_count = 0;
	reader = 0;
	last_mode = 'D';

	do
	{
		if(last_mode != mode_pattern[reader])
		{
			last_mode = mode_pattern[reader];
			glyph_count++;
		}

		if((mode_pattern[reader] == 'A') || (mode_pattern[reader] == 'B'))
		{
			glyph_count++;
			reader++;
		}
		else
		{
			glyph_count++;
			reader += 2;
		}
	}
	while (reader < strlen(mode_pattern));

	glyph_count+= 2;

	row_count = (glyph_count/5);

	if(glyph_count%5 > 0) { row_count++; }

	return row_count;
}

void code16k_check_patch(int first_check, int second_check, char dest[])
{
	/* Patches the width pattern of the last row with the check digits */
	char insert[14];
	unsigned int reader;
	strcpy(insert, "");

	concat(insert, C128Table[first_check]);
	concat(insert, C128Table[second_check]);

	for(reader = 0; reader < 12; reader++)
	{
		dest[reader + 23] = insert[reader];
	}
}

void code16k(int *stack_row, struct symbol_struct *symbol, char source[])
{
	char data_slice[15], mode_slice[15], width_pattern[100], set[8000], last_mode, last_row_mode;
	int current_row, rows_needed, flip_flop, looper, first_check, second_check;
	unsigned int i, k, e_count, reader, mx_reader, writer;
	unsigned int values[170];
	unsigned int bar_characters;
	strcpy(width_pattern, "");

	prescan(source);
	if(strlen(source) > 157) {
		fprintf(stderr, "error: code16k input too long\n");
		exit(TRUE);
	}

	e_count = 0;
	bar_characters = 0;

	/* First figure out what code sets to use - there are three: A, B, and C */
	for(i = 0; i < strlen(source); i++)
	{

		if(source[i] < 32) {
			/* Everthing from NULL to US must be code set A */
			set[i] = 'A';
			if((e_count % 2) == 1) {
				/* If there are an odd number of numbers (0-9), the last one
				   cannot be set C */
				set[i - 1] = 'A';
			}
			e_count = 0;
		}
		if((source[i] > 31) && (source[i] < 48)) {
			/* Everything from SPACE to / can be code set A or B  - Use B */
			set[i] = 'B';
			if((e_count % 2) == 1) {
				set[i - 1] = 'B';
			}
			e_count = 0;
		}
		if((source[i] > 47) && (source[i] < 58)) {
			/* Numbers from 0 to 9 can be code set A, B or C */
			e_count ++;
			if(e_count > 5) {
				/* If there are more than six of them they should be C */
				if(i != (strlen(source) - 1)) {
					for(k = 5; k > 0; k--) {
						set[i - k] = 'C';
					}
					set[i] = 'C';
				}
				else
				{
					/* Ah! But be careful if it's the last character */
					if((e_count % 2) == 1) {
						set[i] = 'B';
					}
					else
					{
						for(k = 5; k > 0; k--) {
							set[i - k] = 'C';
						}
						set[i] = 'C';
					}
				}
			}
			else
			{
				/* Otherwise they can be A or B  - Use B */
				set[i] = 'B';
			}
		}
		if(source[i] > 57) {
			/* Everything from : to _ can be code set A or B - Use B
			   Everything from ` to DELETE must be code set B */
			set[i] = 'B';
			if((e_count % 2) == 1) {
				set[i - 1] = 'B';
			}
			e_count = 0;
		}
	}
	set[i] = '\0';

	rows_needed = get_code16k_rows(set);
	reader = 0;
	last_mode = 'D'; /* This ensures a character set 'change' on first character */

	for(current_row = 1; current_row <= rows_needed; current_row++)
	{
		/* Cut the data up into slices, one for each row */

		last_row_mode = last_mode;
		strcpy(width_pattern, "");
		strcpy(data_slice, "");
		strcpy(mode_slice, "");
		writer = 0;
		i = 0;
		do
		{
			/* Mode P means padding characters (glyph 103) */
			if(last_mode != 'P')
			{
				if(set[reader] != last_mode)
				{
					last_mode = set[reader];
					i++;
				}
				if((set[reader] == 'A') || (set[reader] == 'B'))
				{
					data_slice[writer] = source[reader];
					mode_slice[writer] = set[reader];
					writer++;
					reader++;
					i++;
				}
				else
				{
					data_slice[writer] = source[reader];
					mode_slice[writer] = set[reader];
					data_slice[writer + 1] = source[reader + 1];
					mode_slice[writer + 1] = set[reader + 1];
					writer+=2;
					reader+=2;
					i++;
				}
				if(set[reader] == '\0')
				{
					last_mode = 'P';
					data_slice[writer] = '\0';
					mode_slice[writer] = '\0';
				}
			}
			else
			{
				i++;
				mode_slice[writer] = 'P';
				writer++;
			}
		}
		while (i < 5);
		data_slice[writer] = '\0';
		mode_slice[writer] = '\0';

		/* Make the slices into width patterns */
		code16k_row(current_row, rows_needed, data_slice, last_row_mode, mode_slice, width_pattern, values, &bar_characters);

		/* If on last row, calculate check digits */
		if(current_row == rows_needed)
		{
			int first_sum, second_sum;

			first_sum = 0;
			second_sum = 0;
			for(i = 0; i < bar_characters - 2; i++)
			{
				first_sum += (i+2) * values[i];
				second_sum += (i+1) * values[i];
			}
			first_check = first_sum % 107;
			second_sum += first_check * (bar_characters - 1);
			second_check = second_sum % 107;
			printf("CODE16K check digits %d %d\n", first_check, second_check);
			code16k_check_patch(first_check, second_check, width_pattern);
		}


		/* Write the information into the data matrix */
		writer = 0;
		flip_flop = 1;
		for (mx_reader = 0; mx_reader < strlen(width_pattern); mx_reader++) {
			for(looper = 0; looper < ctoi(width_pattern[mx_reader]); looper++) {
				if(flip_flop == 1) {
					symbol->encoded_data[current_row - 1][writer] = '1';
					writer++; }
				else {
					symbol->encoded_data[current_row - 1][writer] = '0';
					writer++; }
			}
			if(flip_flop == 0) { flip_flop = 1; } else { flip_flop = 0; }
		}

	}

	symbol->no_of_rows = rows_needed;
	symbol->max_width = 70;
}
