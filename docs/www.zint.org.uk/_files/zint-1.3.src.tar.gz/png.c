/* png.c - Handles output to PNG file */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

/* Any resemblance to the code used by Greg Reolofs' wpng code examples is not
   coincidental. Rather odd use of mainprog_info in this file is due to gradual adaption
   from that code. Read his excellent book "PNG: The Definitive Guide" online at
   http://www.libpng.org/pub/png/book/ */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include "png.h"        /* libpng header; includes zlib.h and setjmp.h */
#include "common.h"

typedef struct mainprog_info_type {
    long width;
    long height;
    FILE *outfile;
    jmp_buf jmpbuf;
} mainprog_info;

static mainprog_info wpng_info;

static void writepng_error_handler(png_structp png_ptr, png_const_charp msg)
{
    mainprog_info  *graphic;

    fprintf(stderr, "writepng libpng error: %s\n", msg);
    fflush(stderr);

    graphic = png_get_error_ptr(png_ptr);
    if (graphic == NULL) {         /* we are completely hosed now */
        fprintf(stderr,
          "writepng severe error:  jmpbuf not recoverable; terminating.\n");
        fflush(stderr);
        exit(99);
    }

    longjmp(graphic->jmpbuf, 1);
}

int png_plot(struct symbol_struct *symbol)
{
	char outname[256];
	unsigned char outdata[6000];
	png_structp  png_ptr;
	png_infop  info_ptr;
	mainprog_info  *graphic;
	graphic = &wpng_info;
        long j;
        unsigned long rowbytes;
	unsigned char *image_data;
	strcpy(outname, symbol->outfile);
	int i, k, offset, row;

	/* calculate graphic width and height */
	graphic->width = (symbol->max_width * 2) + (symbol->border_width * 2) + (symbol->whitespace_width * 2);

	switch(symbol->symbology_type) {
		case ONEDIM: if(symbol->user_height == 0) { graphic->height = 200; } else
				{ graphic->height = symbol->user_height + (symbol->border_width * 2); }
			break;
		case STACKED:
		case TWOTRACK:
		case SIXTEEN: graphic->height = (16 * symbol->no_of_rows) + (2 * symbol->border_width);
			break;
		case FOURSTATE: graphic->height = (4 * symbol->no_of_rows) + (2 * symbol->border_width);
			break;
		case PDF: graphic->height = (6 * symbol->no_of_rows) + (2 * symbol->border_width);
			break;
		case MATRIX: graphic->height = (2 * symbol->no_of_rows) + (2 * symbol->border_width);
			break;
	}

	/* Open output file in binary mode */
	if (!(wpng_info.outfile = fopen(outname, "wb"))) {
		fprintf(stderr, "can't open output file\n");
		exit(1);
	}

	/* Set up error handling routine as proc() above */
	png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, graphic,
		writepng_error_handler, NULL);
	if (!png_ptr) {
		fprintf(stderr, "out of memory\n");
		exit(1);   /* out of memory */
	}

	info_ptr = png_create_info_struct(png_ptr);
	if (!info_ptr) {
		png_destroy_write_struct(&png_ptr, NULL);
		fprintf(stderr, "out of memory\n");
		exit(1);   /* out of memory */
	}

	/* catch jumping here */
	if (setjmp(graphic->jmpbuf)) {
		png_destroy_write_struct(&png_ptr, &info_ptr);
		fprintf(stderr, "libpng error occurred\n");
		exit(1);
	}

	/* open output file with libpng */
	png_init_io(png_ptr, graphic->outfile);

	/* set compression */
	png_set_compression_level(png_ptr, Z_BEST_COMPRESSION);

	/* set Header block */
	png_set_IHDR(png_ptr, info_ptr, graphic->width, graphic->height,
		8, PNG_COLOR_TYPE_RGB, PNG_INTERLACE_NONE,
		PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);

	/* write all chunks up to (but not including) first IDAT */
	png_write_info(png_ptr, info_ptr);

	/* set up the transformations:  for now, just pack low-bit-depth pixels
	   into bytes (one, two or four pixels per byte) */
	png_set_packing(png_ptr);

	/* set rowbytes - depends on picture depth */
	rowbytes = wpng_info.width * 3;

	/* Pixel Plotting */
	offset = symbol->border_width + symbol->whitespace_width;
	for (j = 0;  j < graphic->height;  j++) {

		/* top border */
		if (j < symbol->border_width) {
			if (symbol->box || symbol->bind) {
				for(i = 0; i < (graphic->width * 3); i+=3) {
					outdata[i] = symbol->fgcolour[0];
					outdata[i + 1] = symbol->fgcolour[1];
					outdata[i + 2] = symbol->fgcolour[2];
				}
			} else {
				for(i = 0; i < (graphic->width * 3); i+=3) {
					outdata[i] = symbol->bgcolour[0];
					outdata[i + 1] = symbol->bgcolour[1];
					outdata[i + 2] = symbol->bgcolour[2];
				}
			}
		}

		/* middle section */
		if ((j >= symbol->border_width) && (j < (graphic->height - symbol->border_width))) {
			for(i = 0; i < (graphic->width * 3); i+= 3) {
				k = (i / 3);

				/* left hand border */
				if(k < symbol->border_width) {
					if(symbol->box) {
						outdata[i] = symbol->fgcolour[0];
						outdata[i + 1] = symbol->fgcolour[1];
						outdata[i + 2] = symbol->fgcolour[2];
					} else {
						outdata[i] = symbol->bgcolour[0];
						outdata[i + 1] = symbol->bgcolour[1];
						outdata[i + 2] = symbol->bgcolour[2];
					}
				}

				/* left whitespace */
				if((k >= symbol->border_width) && (k < (symbol->border_width + symbol->whitespace_width))) {
					outdata[i] = symbol->bgcolour[0];
					outdata[i + 1] = symbol->bgcolour[1];
					outdata[i + 2] = symbol->bgcolour[2];
				}

				/* the symbol area */
				if((k >= (symbol->border_width + symbol->whitespace_width)) && (k < (graphic->width - (symbol->border_width + symbol->whitespace_width)))) {
					int row_height;

					row =  (j - symbol->border_width) / ((graphic->height - (symbol->border_width * 2)) / symbol->no_of_rows);
					if(symbol->encoded_data[row][(k - offset) / 2] == '1') {
						outdata[i] = symbol->fgcolour[0];
						outdata[i + 1] = symbol->fgcolour[1];
						outdata[i + 2] = symbol->fgcolour[2];
					} else {
						outdata[i] = symbol->bgcolour[0];
						outdata[i + 1] = symbol->bgcolour[1];
						outdata[i + 2] = symbol->bgcolour[2];
					}

					/* row binding */
					if((symbol->symbology_type == SIXTEEN) || ((symbol->symbology_type == STACKED) && (symbol->bind == TRUE))) {
						row_height = (graphic->height - (2 * symbol->border_width)) / symbol->no_of_rows;
						if (j == (((row * row_height) + symbol->border_width) - 2)) {
							outdata[i] = symbol->fgcolour[0];
							outdata[i + 1] = symbol->fgcolour[1];
							outdata[i + 2] = symbol->fgcolour[2];
						}
						if (j == (((row * row_height) + symbol->border_width) - 1)) {
							outdata[i] = symbol->fgcolour[0];
							outdata[i + 1] = symbol->fgcolour[1];
							outdata[i + 2] = symbol->fgcolour[2];
						}
						if (j == (row * row_height) + symbol->border_width) {
							outdata[i] = symbol->fgcolour[0];
							outdata[i + 1] = symbol->fgcolour[1];
							outdata[i + 2] = symbol->fgcolour[2];
						}
						if (j == (((row * row_height) + symbol->border_width) + 1)) {
							outdata[i] = symbol->fgcolour[0];
							outdata[i + 1] = symbol->fgcolour[1];
							outdata[i + 2] = symbol->fgcolour[2];
						}
					}
				}

				/* right whitespace */
				if((k >= (graphic->width - (symbol->border_width + symbol->whitespace_width))) && (k < (graphic->width - symbol->border_width))) {
					outdata[i] = symbol->bgcolour[0];
					outdata[i + 1] = symbol->bgcolour[1];
					outdata[i + 2] = symbol->bgcolour[2];
				}

				/* right hand border */
				if(k >= (graphic->width - symbol->border_width)) {
					if(symbol->box) {
						outdata[i] = symbol->fgcolour[0];
						outdata[i + 1] = symbol->fgcolour[1];
						outdata[i + 2] = symbol->fgcolour[2];
					} else {
						outdata[i] = symbol->bgcolour[0];
						outdata[i + 1] = symbol->bgcolour[1];
						outdata[i + 2] = symbol->bgcolour[2];
					}
				}
			}
		}

		/* bottom border */
		if (j >= (graphic->height - symbol->border_width)) {
			if (symbol->box || symbol->bind) {
				for(i = 0; i < (graphic->width * 3); i+=3) {
					outdata[i] = symbol->fgcolour[0];
					outdata[i + 1] = symbol->fgcolour[1];
					outdata[i + 2] = symbol->fgcolour[2];
				}
			} else {
				for(i = 0; i < (graphic->width * 3); i+=3) {
					outdata[i] = symbol->bgcolour[0];
					outdata[i + 1] = symbol->bgcolour[1];
					outdata[i + 2] = symbol->bgcolour[2];
				}
			}
		}

		/* write row contents to file */
		image_data = outdata;
		png_write_row(png_ptr, image_data);
	}

	/* End the file */
	png_write_end(png_ptr, NULL);

	/* make sure we have disengaged */
	if (png_ptr && info_ptr) png_destroy_write_struct(&png_ptr, &info_ptr);
	fclose(wpng_info.outfile);

	return 0;
}
